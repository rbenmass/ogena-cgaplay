<?php

		$dir=$_SERVER['DOCUMENT_ROOT']."/scripts/java";
		exec("java -cp \"".$dir."\" ImageRotate > java.log");
		

		exec("java -version 2>jversion.log");
	



		$file=file_get_contents("http://".getenv("HTTP_HOST")."/test/java.log");

		$file=file_get_contents("http://".getenv("HTTP_HOST")."/test/jversion.log");

		if(strpos($file, "version")!=false){
//			echo "1";
			$ex=explode("\n", $file);
			echo "<span style='color:white'>".$ex[0]." &#10004;</span>";
			
		}
		else{
			echo 0;
			
		}
		

?>
