rm ytversion.log
youtube-dl --version >ytversion.log
chmod 777 ytversion.log
