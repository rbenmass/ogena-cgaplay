<?php

	echo  "<span style='color:white'>PHP ".phpversion()." &#10004;</span>";

?>
