<?php

	

		@unlink($_SERVER['DOCUMENT_ROOT']."/test/ytversion.log");


			if(file_exists("/var/www")){
                exec($_SERVER['DOCUMENT_ROOT']."/test/youTube.sh");
				}
				else{
		exec("youTube.bat");
}




                $file=file_get_contents("http://".getenv("HTTP_HOST")."/test/ytversion.log");
		$re=explode(".", $file);

//		echo "dsdsdsd " ;

                if(count($re)>1 ){
//                      echo "1";
                        
                        echo "<span style='color:white'>Youtube-dl (Version) ".$file." &#10004;</span>";

                }
                else{
                        echo 0;

                }



		

?>
