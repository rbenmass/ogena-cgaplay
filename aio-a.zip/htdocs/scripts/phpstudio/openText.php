<?php
$lin="";

$handle = fopen($_SERVER['DOCUMENT_ROOT']."/".$_GET['request'], "r");
if ($handle) {
    while (($line = fgets($handle)) !== false) {
        // process the line read.
    	$lin.=$line;
	}

    fclose($handle);
} else {
    // error opening the file.
} 
$data = explode("<next>", $lin);
echo $data[0];
?>
