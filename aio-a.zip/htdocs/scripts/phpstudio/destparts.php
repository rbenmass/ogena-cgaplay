<?php
	@mkdir($_SERVER['DOCUMENT_ROOT']."/".$_GET['dest']);
	$ee = explode("*", $_GET['parts']);
	
	$f=fopen($_SERVER['DOCUMENT_ROOT']."/log.log", "w");
	
	$rt= scanDir($_SERVER['DOCUMENT_ROOT']."/".$_GET['dest']);
	for($l=0;$l<count($rt);$l++){
	if($rt=="." || $rt[$l]==".." || $_GET['dest']==""){
	}
	else{
	@unlink($_SERVER['DOCUMENT_ROOT']."/".$_GET['dest']."/".$rt[$l]);
	}
	}
	
	 
	$tel=40000000;
	for($i=0;$i<count($ee);$i++){
		$di = scanDir($_SERVER['DOCUMENT_ROOT']."/".$ee[$i]."_");
		for($j=0;$j<count($di);$j++){
		
		if($di[$j]=="." || $di[$j]==".." || ){
		}
		else{
		
	fwrite($f, $_SERVER['DOCUMENT_ROOT']."/".$ee[$i]."_"."/".$di[$j]." ...".$_SERVER['DOCUMENT_ROOT']."/".$_GET['dest']."/Build.".$tel.".jpg");
		copy($_SERVER['DOCUMENT_ROOT']."/".$ee[$i]."_"."/".$di[$j], $_SERVER['DOCUMENT_ROOT']."/".$_GET['dest']."/Build.".$tel.".jpg");
		$tel++;
		}
		}
		
		
	}
		fclose($f);
	@unlink($_SERVER['DOCUMENT_ROOT']."/data/myClip.mp4");
	exec(" ffmpeg -i \"".$_SERVER['DOCUMENT_ROOT']."/".$_GET['dest']."/Build.4%7d.jpg\" data/myClip.mp4");
	
?>
