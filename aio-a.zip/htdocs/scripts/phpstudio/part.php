<?php
date_default_timezone_set('Europe/Amsterdam');


$clipName= str_replace(" ", "_",$_GET['vname']).".".$_GET['vext'];
@unlink("../../data[".$_SERVER['REMOTE_ADDR']."]/lengthSeconds.txt");
@unlink("../../data[".$_SERVER['REMOTE_ADDR']."]/_rawDuration.html");

@mkdir("../../data[".$_SERVER['REMOTE_ADDR']."]/collect");
@mkdir("../../data[".$_SERVER['REMOTE_ADDR']."]/frames");

@mkdir("../../data[".$_SERVER['REMOTE_ADDR']."]/tmp");
@mkdir("../../data[".$_SERVER['REMOTE_ADDR']."]/temp");
@unlink("../../data[".$_SERVER['REMOTE_ADDR']."]/temp/status.html");
$f= @fopen("../../data[".$_SERVER['REMOTE_ADDR']."]/temp/status.html", "w");
@fwrite($f, "0");
@fclose($f);


@mkdir($_SERVER['DOCUMENT_ROOT']."/images/frames");
@mkdir($_SERVER['DOCUMENT_ROOT']."/images/Preview");

	@mkdir($_SERVER['DOCUMENT_ROOT']."/".$_GET['fname']);

if($_GET['fname']!=""){

$fi = scandir($_SERVER['DOCUMENT_ROOT']."/".$_GET['fname'] );
for($u=0;$u<count($fi);$u++){

	if($fi[$u]=="." || $fi[$u]=="..") { }
	else{
		@unlink($_SERVER['DOCUMENT_ROOT']."/".$_GET['fname']."/".$fi[$u] );
	}
}
}




	
	$fileFr = file_get_contents("http://".getenv("HTTP_HOST")."/".$_GET['name'].".txt");
	$start = $_GET['start']*$fileFr;
	$end = $_GET['end']*$fileFr;
	$tt=0;
	
	if($_GET['fname']!=""){
	
	$rf=scanDir($_SERVER['DOCUMENT_ROOT']."/".$_GET['fname']);
	for($t=0;$t<count($rf);$t++){
	if($rt[$t]=="." || $rt[$t]==".."){
	
	}
	else{
	@unlink($_SERVER['DOCUMENT_ROOT']."/".$_GET['fname']."/".$rf[$t]);
	}
	}
	
	}
	
	$star=1;
	
	
	$re=@file_get_contents("http://".getenv("HTTP_HOST")."/data[".$_SERVER['REMOTE_ADDR']."]/pproject.data");


	


	$red=explode("<next>", $re);
	$iii=$_GET['nr'];
	$vol="";
	
	$vol = " -vol ".$_GET['mute'];
	
	@unlink("../../data[".$_SERVER['REMOTE_ADDR']."]/audio_".$iii.".mp3");
	@unlink("../../data[".$_SERVER['REMOTE_ADDR']."]/audio".$iii.".mp3");
	@unlink("../../data[".$_SERVER['REMOTE_ADDR']."]/BSounf".$iii.".mp3");


	@unlink("../../data[".$_SERVER['REMOTE_ADDR']."]/audio".$iii.".wav");








	//BEGIN AUDIO

	$durs=$_GET['end']-$_GET['start']+1;
	$mins=floor($durs/60);
	if($mins>0){
		$tott="00:".$mins.":".($durs-(60*$mins));		
	}
	else{
		$tott="00:00:".$durs;
	}
	
	
	
                $starter=explode(":", $_GET['start']);
        $ssh=$starter[0];
        $ssm=$starter[1];
        $sss=$starter[2];




        $etarter=explode(":", $_GET['end']);
        $esh=$etarter[0];
        $esm=$etarter[1];
        $ess=$etarter[2];



        $begin=(60*60*$ssh)+(60*$ssm)+$sss;
        $end=(60*60*$esh)+(60*$esm)+$ess;

        $verschil=$end-$begin;

        $hh=floor($verschil/(60*60));
        $left=$verschil-($hh*60*60);
        $mm=floor($left/60);
        $ss=$left-($mm*60);

        $sssss=$hh.":".$mm.":".$ss;
	
	
	$rrra=("ffmpeg -ss ".$_GET['start']." -t ".$sssss." -i \"".$_SERVER['DOCUMENT_ROOT']."/".str_replace("1.jpg_", "", str_replace("myMediaTbn", "myMedia", $_GET['fname']))."\"  ".$vol."  -filter_complex atempo=".$_GET['speed']."  ../../data[".$_SERVER['REMOTE_ADDR']."]/audio".$iii.".mp3");
	
	exec($rrra);
		
	
	if(file_exists("../../data[".$_SERVER['REMOTE_ADDR']."]/BSounf".$iii.".wav")){

	exec("ffmpeg -i ../../data[".$_SERVER['REMOTE_ADDR']."]/BSounf".$iii.".wav ../../data[".$_SERVER['REMOTE_ADDR']."]/BSounf".$iii.".mp3");
	@unlink("../../data[".$_SERVER['REMOTE_ADDR']."]/BSounf.wav" );	


exec("ffmpeg -i ../../data[".$_SERVER['REMOTE_ADDR']."]/audio_".$iii.".mp3  -i ../../data[".$_SERVER['REMOTE_ADDR']."]/BSounf".$iii.".mp3  -filter_complex amix=inputs=2 ../../data[".$_SERVER['REMOTE_ADDR']."]/audio".$iii.".mp3");

	}
	else{
	exec("ffmpeg -i ../../data[".$_SERVER['REMOTE_ADDR']."]/audio_".$iii.".mp3  ../../data[".$_SERVER['REMOTE_ADDR']."]/audio".$iii.".mp3");

	}
	//END AUDIO













	
	/*MAKES FILES*/	

	
	//rip Frames.
	
                $starter=explode(":", $_GET['start']);
        $ssh=$starter[0];
        $ssm=$starter[1];
        $sss=$starter[2];




        $etarter=explode(":", $_GET['end']);
        $esh=$etarter[0];
        $esm=$etarter[1];
        $ess=$etarter[2];



        $begin=(60*60*$ssh)+(60*$ssm)+$sss;
        $end=(60*60*$esh)+(60*$esm)+$ess;

        $verschil=$end-$begin;

        $hh=floor($verschil/(60*60));
        $left=$verschil-($hh*60*60);
        $mm=floor($left/60);
        $ss=$left-($mm*60);

        $sssss=$hh.":".$mm.":".$ss;

	$gr="";
	if($_GET['greyscale']>0){
	$gr="format=gray,";
	}	
	

	$rot="";
	if($_GET['rotata']=="0"){
	 $rot=",transpose=1";

	}
	if($_GET['rotate']=="1"){
	  $rot=",transpose=2";

	}
	if($_GET['rotate']=="2"){
	$rot=",transpose=2,transpose=2";
	}


	$an="";
	if($_GET['backward']>0){
	$an=" -an ";
	}

	$rrr=("ffmpeg -ss ".$_GET['start']." -t ".$sssss." -i \"".$_SERVER['DOCUMENT_ROOT']."/".str_replace("1.jpg_", "", str_replace("myMediaTbn", "myMedia", $_GET['fname']))."\"  -qscale:v 1 -vf \"".$gr."fps=".round(25/$_GET['speed']).$rot."\" \"".$_SERVER['DOCUMENT_ROOT']."/".$_GET['fname']."/file%d.jpg\"");

	
	exec($rrr);

	$an="";
	$fs=scandir($_SERVER['DOCUMENT_ROOT']."/".$_GET['fname']."/");
        if($_GET['backward']>0){
        	for($lk=0;$lk<count($fs);$lk++){
			@copy($_SERVER['DOCUMENT_ROOT']."/".$_GET['fname']."/file".(count($fs)-$lk).".jpg", $_SERVER['DOCUMENT_ROOT']."/".$_GET['fname']."/gile".$lk.".jpg");
		}
		for($lk=0;$lk<count($fs);$lk++){
                        @unlink($_SERVER['DOCUMENT_ROOT']."/".$_GET['fname']."/file".$lk.".jpg");
                }
		for($lk=0;$lk<count($fs);$lk++){
                        @copy($_SERVER['DOCUMENT_ROOT']."/".$_GET['fname']."/gile".$lk.".jpg",$_SERVER['DOCUMENT_ROOT']."/".$_GET['fname']."/file".$lk.".jpg");
		}
		
		for($lk=0;$lk<count($fs);$lk++){
                        @unlink($_SERVER['DOCUMENT_ROOT']."/".$_GET['fname']."/gile".$lk.".jpg");
                }

        }



	$fimg=$_SERVER['DOCUMENT_ROOT']."/".$_GET['fname']."/file1.jpg";

	$th =fopen($_SERVER['DOCUMENT_ROOT']."/log.txt", "w");
	fwrite($th, $rrr);
	fclose($th);
	
	
	$tij=0;
	


	$filesl=scanDir($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/frames");
	@copy($fimg, $_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/firstImage.jpg");
	if(count($filesl)>2){
	
@copy($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/frames/".$filesl[(count($filesl)-1)], $_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/lastImage.jpg");
	}
	else{
		@copy($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/firstImage.jpg", $_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/lastImage.jpg");
	}
	
	//xmanxman

	






        $gr="";
        if($_GET['greyscale']>0){
        $gr="format=gray";
        }


        $rot="";
        if($_GET['rotata']=="0"){
         $rot=",transpose=1";

        }
        if($_GET['rotate']=="1"){
          $rot=",transpose=2";

        }
        if($_GET['rotate']=="2"){
        $rot=",transpose=2,transpose=2";
        }


        $an="";
        if($_GET['backward']>0){
        $an=" -an ";
        }

	@unlink($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/lastImagex.jpg" );
  @unlink($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/firstImagex.jpg" );

        $rrr=("ffmpeg  -i \"".$_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/lastImage.jpg\" -vf ".$gr.$rot." \"".$_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/lastImagex.jpg\"");



        $rrr2=("ffmpeg  -i \"".$_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/firstImage.jpg\" -vf ".$gr.$rot." \"".$_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/firstImagex.jpg\"");



	

	if($_GET['greyscale']>0 || $_GET['rotata']=="0" || $_GET['rotata']=="1" || $_GET['rotata']=="2"  ){





	exec($rrr);
	exec($rrr2);
	 copy($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/lastImagex.jpg", $_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/lastImage.jpg");


         copy($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/firstImagex.jpg", $_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/firstImage.jpg");


}



        $filesl=scanDir($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/frames");
        @copy($fimg, $_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/firstImage.jpg");
        if(count($filesl)>2){

@copy($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/frames/".$filesl[(count($filesl)-1)],$_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/lastImage.jpg");
        }
        else{
                @copy($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/firstImage.jpg",$_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/lastImage.jpg");
        }










	
	@copy($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/lastImage.jpg", $_SERVER['DOCUMENT_ROOT']."/images/Preview/Image1.jpg");

	@copy($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/firstImage.jpg", $_SERVER['DOCUMENT_ROOT']."/images/Preview/Image2.jpg");
	@copy($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/firstImage.jpg", $_SERVER['DOCUMENT_ROOT']."/images/Preview/Image3.jpg");
	
	


	if(true){
	list($wi, $he)=getimagesize($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/firstImage.jpg");

	$files=scanDir($_SERVER['DOCUMENT_ROOT']."/images/frames");
	for($ii=0;$ii<count($files);$ii++){
	if($files=="." || $files==".."){
	}
	else{
	unlink($_SERVER['DOCUMENT_ROOT']."/images/frames/".$files[$ii]);
	}
	}
	$not='!';
	file_get_contents("http://".getenv("HTTP_HOST")."/scripts/php/jip-scripts.php?p=Preview".$not.$_GET['effect']."&pp=Preview&width=".$wi."&height=".$he."&lang=&music=&time=&reed=&nrOffSummaryImg=1&frames=21");
	
	
	
	$filef  = scandir($_SERVER['DOCUMENT_ROOT']."/images/frames");

	@unlink('images/frames/__processRequest00Frames.php');
	
	$ho=0;
	$fileb=scandir($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/frames");

$aaf=count($filef)-2;
$aab = count($fileb)-2;


	for($j=0;$j<$aaf;$j++){
	if($filess[$j]=="." || $filess[$j]==".."){
	}
	else{

	@copy($_SERVER['DOCUMENT_ROOT']."/images/frames/".$filess[$j],  $_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/frames/Frames.".(40000000+$ho+$aab).".jpg");
$ho++;

	
	
	}


	
	
	
	
	}
	
	






	}
	







//fSFX

        @mkdir($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/collect");
        $filesSource=scandir($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/frames");

        $aantalReeds = count($filesSource)-2;

        $filess=scandir($_SERVER['DOCUMENT_ROOT']."/images/frames" );
$tttt=0;
        for($j=0;$j<(count($filess)-1);$j++){

if($filess[$j]=="." || $filess[$j]==".."){
}
else{




        if( $_GET['greyscale']>0 || $_GET['rotata']=="0" || $_GET['rotata']=="1" || $_GET['rotata']=="2"  ){



        $rrr="ffmpeg  -i ".$_SERVER['DOCUMENT_ROOT']."/images/frames/".$filess[$j]." -qscale:v 1 -vf \"".$gr.$rot."\" ".
$_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/frames/Frames.".(40000000+$aantalReeds+$tttt).".jpg" ;
        exec($rrr);

}
else{


@copy( $_SERVER['DOCUMENT_ROOT']."/images/frames/".$filess[($j+1)],
$_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/frames/Frames.".(40000000+$aantalReeds+$tttt).".jpg" );
    
}







$tttt++;
}

}


        @mkdir($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/collect");
        $filesSource=scandir($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/frames");
        
	$aantalReeds = count($filesSource)-2;

	$filess=scandir($_SERVER['DOCUMENT_ROOT']."/".$_GET['fname'] );
$tttt=0;
  











      for($j=0;$j<count($filess);$j++){

if($filess[$j]=="." || $filess[$j]==".."){
}
else{

	//here it is






        if(false && $_GET['greyscale']>0 || $_GET['rotata']=="0" || $_GET['rotata']=="1" || $_GET['rotata']=="2"  ){



        $rrr="ffmpeg  -i ".$_SERVER['DOCUMENT_ROOT']."/".$_GET['fname']."/file".$j.".jpg -qscale:v 1 -vf ".$gr.$rot." ".$_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/frames/Frames.".(40000000+$aantalReeds+$tttt).".jpg" ;
	exec($rrr);

}
else{






     @copy( $_SERVER['DOCUMENT_ROOT']."/".$_GET['fname']."/file".$j.".jpg", $_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/frames/Frames.".(40000000+$aantalReeds+$tttt).".jpg" );
        $limg= $_SERVER['DOCUMENT_ROOT']."/".$_GET['fname']."/".$filess[$j];

}
$tttt++;
}

}


	
	$af="";
	$of="";
	$fff=scanDir("../../data[".$_SERVER['REMOTE_ADDR']."]/myMediaAudio");
	
	


                $re=@file_get_contents("http://".getenv("HTTP_HOST")."/data[".$_SERVER['REMOTE_ADDR']."]/projectAudio.data");
       $ff=explode("<next>", $re);


	$rrrr=2;	
	for($j=0;$j<(count($ff));$j++){
	
		if($ff[$j]==""){
		}
		else{

		$af.=" -i ../../".$ff[$j]. " "; 
			
			$of= " -filter_complex amix=inputs=".$rrrr. " ";
	  $rrrr=$rrrr+1;


		}
	
	}
	
	
	


	
	
	@unlink("../../data[".$_SERVER['REMOTE_ADDR']."]/sound.mp3");

 @unlink("../../data[".$_SERVER['REMOTE_ADDR']."]/sound.wav");
	$re=@file_get_contents("http://".getenv("HTTP_HOST")."/data[".$_SERVER['REMOTE_ADDR']."]/pproject.data");
	$red=explode("<next>", $re);
	$iii=count($red)-1;
	$dd="ffmpeg -i \"concat:";
	for($ddo=1;$ddo<=$iii;$ddo++){
	
		if(file_exists("../../data[".$_SERVER['REMOTE_ADDR']."]/audio".$ddo.".mp3")){
		$dd.="../../data[".$_SERVER['REMOTE_ADDR']."]/audio".$ddo.".mp3|";
		}
	
	}
	
	@unlink("../../data[".$_SERVER['REMOTE_ADDR']."]/sound.wav");
	@unlink("../../data[".$_SERVER['REMOTE_ADDR']."]/wave.gif");
	
	$ddt=substr($dd, 0, (strlen($dd)-1))."\" ../../data[".$_SERVER['REMOTE_ADDR']."]/sound.wav";
	exec($ddt);

	
	@unlink("../../data[".$_SERVER['REMOTE_ADDR']."]/".$clipName);
	$javad= $_SERVER['DOCUMENT_ROOT']."/scripts/java";

	

	
		if(file_exists("c:/windows")){	
		
		@unlink("../../data[".$_SERVER['REMOTE_ADDR']."]/_rawDuration.html");
		exec("ffmpeg -i  ../../data[".$_SERVER['REMOTE_ADDR']."]/sound.wav  2>&1   | find \"Duration\"  > ../../data[".$_SERVER['REMOTE_ADDR']."]/_rawDuration.html");
		
		@unlink("../../data[".$_SERVER['REMOTE_ADDR']."]/lenWav.txt");

				$fc="";
		
		$handle = fopen("../../data[".$_SERVER['REMOTE_ADDR']."]/_rawDuration.html", "r");
		if ($handle) {
				while (($line = fgets($handle)) !== false) {
					$fc.=$line;
				}
			} 
		else {
		
		}
		fclose($handle);



                $gf=explode(",", $fc);
                $fi=explode(":", $gf[0]);
                $hr= $fi[1]*60*60;
                $mi= $fi[2]*60;
                $se = $fi[3]+1;
                $tot=$hr+$mi+$se;


		@exec("echo ".$tot." > ../../data[".$_SERVER['REMOTE_ADDR']."]/lenWav.txt");
		@exec("echo ".$tot." > ../../data[".$_SERVER['REMOTE_ADDR']."]/lengthSeconds");


		}
		else{
		@unlink("../../data[".$_SERVER['REMOTE_ADDR']."]/_rawDuration.html");
		exec("ffmpeg -i  ../../data[".$_SERVER['REMOTE_ADDR']."]/sound.wav  2>&1   | grep Duration  | cut -d ' ' -f 4 | sed s/,// > ../../data[".$_SERVER['REMOTE_ADDR']."]/_rawDuration.html");
			
			
		
		$fc=file_get_contents("http://".getenv("HTTP_HOST")."/data[".$_SERVER['REMOTE_ADDR']."]/_rawDuration.html");

  @unlink("../../data[".$_SERVER['REMOTE_ADDR']."]/lenWav.txt");





                $fi=explode(":", $fc);
                $hr= $fi[0]*60*60;
                $mi= $fi[1]*60;
                $se1 = explode('.',$fi[2]);
                $se=0+$se1[0];

                $tot=$hr+$mi+$se;





		@exec("echo ".$tot." > ../../data[".$_SERVER['REMOTE_ADDR']."]/lenWav.txt");		



		@exec("echo ".$tot." > ../../data[".$_SERVER['REMOTE_ADDR']."]/lengthSeconds.txt");

		

		}
	
		
	$files=scanDir($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/collect");
	$ccount=count($files);
	




	$toto = file_get_contents("http://".getenv("HTTP_HOST")."/data[".$_SERVER['REMOTE_ADDR']."]/lenWav.txt");
	@unlink("../../data[".$_SERVER['REMOTE_ADDR']."]/mfps.txt");	
	$fi = fopen("../../data[".$_SERVER['REMOTE_ADDR']."]/mfps.txt", "w");
	fwrite($fi, ($ccount/$toto));
	fclose($fi);

	$fpsss= round($ccount/$toto);



   $fileb=scandir($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/frames");
	$fc = count($fileb);
	$fps = floor($fc/(0+$tot));

if($_GET['nr']==($_GET['maxPart']-0) ){

@unlink(" ../../data[".$_SERVER['REMOTE_ADDR']."]/wave.gif");



       exec("ffmpeg    ".$af." ".$of."  -i ../../data[".$_SERVER['REMOTE_ADDR']."]/sound.wav ../../data[".$_SERVER['REMOTE_ADDR']."]/".$clipName.".wav");



 exec("java -cp ../../scripts/java AudioWaveformCreator ../../data[".$_SERVER['REMOTE_ADDR']."]/".$clipName.".wav ../../data[".$_SERVER['REMOTE_ADDR']."]/wave.gif 245 245 245");

@unlink("../../data[".$_SERVER['REMOTE_ADDR']."]/".$clipName.".wav");

	@unlink($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/nrOfFramesz.html" );

   $filesSource=scandir($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/frames");
$rvn= count($filesSource );





        $rf= @fopen($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/nrOfFramesz.html", "w");
        @fwrite($rf, "".$rvn);
        @fclose($rf);







$filesSource=scandir("../../data[".$_SERVER['REMOTE_ADDR']."]/frames/");
   $rvn= count($filesSource );




        $rf= @fopen($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/frameCount.html", "w");
        @fwrite($rf, "".$rvn);
        @fclose($rf);

		        $rf= @fopen($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/nrOfFramesz.html", "w");
        @fwrite($rf, "".$rvn);
        @fclose($rf);
		
		
		        $rf= @fopen($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/nrOfFrames.html", "w");
        @fwrite($rf, "".$rvn);
        @fclose($rf);






@unlink("../../data[".$_SERVER['REMOTE_ADDR']."]/status.html");

       $mfpps = ceil($rvn/$tot);

	@unlink("../../data[".$_SERVER['REMOTE_ADDR']."]/".$clipName.".avi");

        exec("ffmpeg   -i ../../data[".$_SERVER['REMOTE_ADDR']."]/frames/Frames.4%7d.jpg ".$af." ".$of."   -i ../../data[".$_SERVER['REMOTE_ADDR']."]/sound.wav   -qmin 10 -qmax 42 -preset ultrafast -cpu-used 5 -threads 4  -q:v 1 ../../data[".$_SERVER['REMOTE_ADDR']."]/".$clipName."  2> ../../data[".$_SERVER['REMOTE_ADDR']."]/status.html");


	if(file_exists("c:\windows")){
	

                @unlink("../../data[".$_SERVER['REMOTE_ADDR']."]/_rawDuration.html");
                exec("ffmpeg -i  ../../data[".$_SERVER['REMOTE_ADDR']."]/".$clipName."  2>&1   | find \"Duration\"  >../../data[".$_SERVER['REMOTE_ADDR']."]/_rawDuration.html");

        @unlink("../../data[".$_SERVER['REMOTE_ADDR']."]/lenWav.txt");


 $fc=file_get_contents("http://".getenv("HTTP_HOST")."/data[".$_SERVER['REMOTE_ADDR']."]/_rawDuration.html");



                $gf=explode(",", $fc);
                $fi=explode(":", $gf[0]);
                $hr= $fi[1]*60*60;
                $mi= $fi[2]*60;
                $se = $fi[3]+1;
                $tot=$hr+$mi+$se;

    


	}
	else{





               @unlink("../../data[".$_SERVER['REMOTE_ADDR']."]/_rawDuration.html");
               exec("ffmpeg -i  ../../data[".$_SERVER['REMOTE_ADDR']."]/".$clipName."  2>&1   | grep Duration   | cut -d ' ' -f 4 | sed s/,// >  ../../data[".$_SERVER['REMOTE_ADDR']."]/_rawDuration.html");



                $fc=file_get_contents("http://".getenv("HTTP_HOST")."/data[".$_SERVER['REMOTE_ADDR']."]/_rawDuration.html");

 		 @unlink("../../data[".$_SERVER['REMOTE_ADDR']."]/lenWav.txt");



                $fi=explode(":", $fc);
                $hr= $fi[0]*60*60;
                $mi= $fi[1]*60;
                $se1 = explode('.',$fi[2]);
                $se=0+$se1[0];

                $tot=$hr+$mi+$se;



                @exec("echo ".$tot." > ../../data[".$_SERVER['REMOTE_ADDR']."]/lenWav.txt");






	}

		
		
		


	}
	
?>
