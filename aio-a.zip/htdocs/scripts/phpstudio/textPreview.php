<!--
	Title: Web Based Video Maker / Editor 
	Description: General Purpose Graphics / Animation & Movie Editing
	Author:Lofti & Ridouan Ben Massoud
	Domain: soccer-kids.nl, ogena.net & e-rogen.eu, theoriecentrum.nu
	Date: 20-01-2015
	File: scripts/phpstudio/textPreview.php (Previews Text added on to Video)
-->
<?php
ini_set('default_charset', 'UTF-8');
date_default_timezone_set('Europe/Amsterdam');
set_time_limit(120);
@unlink($_SERVER['DOCUMENT_ROOT']."/text/data[".$_SERVER['REMOTE_ADDR']."]/output.png");
@unlink($_SERVER['DOCUMENT_ROOT']."/text/data[".$_SERVER['REMOTE_ADDR']."]/preview.jpg");
@unlink($_SERVER['DOCUMENT_ROOT']."/text/data[".$_SERVER['REMOTE_ADDR']."]/data.html");
$tt=0;

session_start();
session_name('st');

if($_SESSION['frame']>0){
$_SESSION['frame']=$_SESSION['frame']+1;
$tt=$_SESSION['frame'];
}
else{
$_SESSION['frame']=1;
}

if($_GET['fps']==""){
$fps=25;
}
else{
$fps = $_GET['fps'];
}
$tt=1;
$dataf=file_get_contents("http://".getenv("HTTP_HOST"). "/".$_GET['file']."?frame=".$tt);
echo $dataf;
$data = explode("<next>", $dataf);
@unlink("../../data[".$_SERVER['REMOTE_ADDR']."]/data.html");
@unlink("../../data[".$_SERVER['REMOTE_ADDR']."]/output.png");
$fileHTML=$_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/data.html";
$filhtml = fopen($fileHTML, "w");
$firstImage="http://".getenv("HTTP_HOST")."/data[".$_SERVER['REMOTE_ADDR']."]/frames/Frames.".(40000000+($data[7]*$fps)+ceil($data[8]/2)).".jpg";
list($widt, $heigh)=getimagesize("../../data[".$_SERVER['REMOTE_ADDR']."]/frames/Frames.".(40000000+($data[7]*$fps)+1).".jpg"  );
$the="<table  background='".$firstImage."' width='".$widt."' height='".$heigh."'><tr><td align='".$data[1]."' valign='".$data[2]."' >";




$the="<head><meta charset='UTF-8'></head><table><tr><td  width='".$widt."' height='".$heigh."'  cellspacing='0' cellpadding=0  align='".$data[1]."' valign='".$data[2]."'
  style='background-image:url(".$firstImage.")'  >";
fwrite($filhtml, $the."<font color='#".$data[4].$data[5].$data[6]."' size='".$data[3]."'>".str_replace("\\", "", $data[0])."</td></tr></table>" );
fclose($filhtml);




$javadir = "../../scripts/java/";
$exec= "java -Dfile.encoding=UTF8  -cp ".$javadir . " ImageWrapperHTML ../../data[".$_SERVER['REMOTE_ADDR']."]/data.html ../../data[".$_SERVER['REMOTE_ADDR']."]/preview.jpg ".$heigh;

exec($exec);
echo $exec;
?>
