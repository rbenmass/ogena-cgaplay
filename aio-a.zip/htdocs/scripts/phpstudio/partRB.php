<!--
	Title: Web Based Video Maker / Editor 
	Description: General Purpose Graphics / Animation & Movie Editing
	Author:Ridouan Ben Massoud
	Domain: ogena.net & e-rogen.eu
	Date: 20-01-2015
	File: part.php (Build gradually the Video)
-->
<?php
date_default_timezone_set('Europe/Amsterdam');
$scDrtn=file_get_contents("http://".getenv("HTTP_HOST")."/data[".$_SERVER['REMOTE_ADDR']."]/lenWav.txt");
$frmCnt = count(scandir("../../data[".$_SERVER['REMOTE_ADDR']."]/frames/"));

$fps = 25;

$clipName= str_replace(" ", "_",$_GET['vname']).".".$_GET['vext'];
@unlink("../../data[".$_SERVER['REMOTE_ADDR']."]/temp.mp3");
exec("ffmpeg -i ../../data[".$_SERVER['REMOTE_ADDR']."]/".$clipName." ../../data[".$_SERVER['REMOTE_ADDR']."]/temp.wav");
@unlink("../../data[".$_SERVER['REMOTE_ADDR']."]/".$clipName."");
@unlink("../../data[".$_SERVER['REMOTE_ADDR']."]/".$clipName.".avi");
@unlink("../../data[".$_SERVER['REMOTE_ADDR']."]/status.html");

exec("ffmpeg   -i ../../data[".$_SERVER['REMOTE_ADDR']."]/frames/Frames.4%7d.jpg  -i ../../data[".$_SERVER['REMOTE_ADDR']."]/temp.wav  -qmin 10 -qmax 42 -cpu-used 5 -threads 4    ../../data[".$_SERVER['REMOTE_ADDR']."]/".$clipName."   2> ../../data[".$_SERVER['REMOTE_ADDR']."]/status.html");

@unlink("../../data[".$_SERVER['REMOTE_ADDR']."]/temp.wav");
?>
