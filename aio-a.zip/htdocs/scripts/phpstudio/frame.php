<?php
/*
	Title: Web Based Video Maker / Editor 
	Description: General Purpose Graphics / Animation & Movie Editing
	Author:Lofti & Ridouan Ben Massoud
	Domain: soccer-kids.nl, ogena.net & e-rogen.eu, theoriecentrum.nu
	Date: 20-01-2015
	File: scripts/phpstudio/framne.php (Build gradually the Video)
*/	

session_name('ss');
session_start();
	if( $_POST['username']!=""){
$rawData = $_POST['imgBase64'];
$filteredData = explode(',', $rawData);
$unencoded = base64_decode($filteredData[1]);

$datime = date("Y-m-d-H.i.s", time() ) ; # - 3600*7


// name & open the image file 

if($_SESSION['frame']<1){
$_SESSION['frame']=100000;
}
else{
$_SESSION['frame']=$_SESSION['frame']+1;
}

$fp = fopen($_SERVER['DOCUMENT_ROOT'].'/temp/Picture'.$_SESSION['frame'].'.jpg', 'w');
fwrite($fp, $unencoded);
fclose($fp);




}

?>
