<?php

 $d=@file_get_contents("http://".getenv( 'HTTP_HOST')."/settings[".$_SERVER['REMOTE_ADDR']."]/videoQuality.html"); 
if(strlen($d)>1 || $d!=""){
$f=" -f ".$d;
}
else
{
$f="";
}

exec("youtube-dl  -o ../../".$_GET['save']."z.avi ".$f." ".$_GET['v'] ." > ../../data[".$_SERVER['REMOTE_ADDR']."]/statusdl.html");
exec("ffmpeg -i ../../".$_GET['save']."z.avi  ../../".$_GET['save']);
unlink("../../".$_GET['save']."z.avi" );
?>
