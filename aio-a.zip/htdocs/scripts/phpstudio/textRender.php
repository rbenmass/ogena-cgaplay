<!--
	Title: Web Based Video Maker / Editor 
	Description: General Purpose Graphics / Animation & Movie Editing
	Author:Lofti & Ridouan Ben Massoud
	Domain: soccer-kids.nl, ogena.net & e-rogen.eu, theoriecentrum.nu
	Date: 20-01-2015
	File: scripts/phpstudio/textRender.php (Build gradually the Video)
-->
<?php
ini_set('default_charset', 'UTF-8');
date_default_timezone_set('Europe/Amsterdam');
set_time_limit(180);
@unlink('../../text/output.png');
@unlink('../../text/preview.jpg');
@unlink('../../text/data.html');

$tt=7;


//if($_GET['fps']==""){
$fps=25;
//}
//else{
//$fps = $_GET['fps'];
//}
$dataf=file_get_contents("http://".getenv("HTTP_HOST"). "/".$_GET['file']."?frame=".$tt);
echo $dataf;
$data = explode("<next>", $dataf);
@unlink("../../data[".$_SERVER['REMOTE_ADDR']."]/data.html");
@unlink("../../data[".$_SERVER['REMOTE_ADDR']."]/output.png");
$fileHTML=$_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/data.html";
$filhtml = fopen($fileHTML, "w");
$firstImage="http://".getenv("HTTP_HOST")."/data[".$_SERVER['REMOTE_ADDR']."]/frames/Frames.".(40000000+($data[7]*$fps)+1).".jpg";
list($widt, $heigh)=getimagesize("../../data[".$_SERVER['REMOTE_ADDR']."]/frames/Frames.".(40000000+($data[7]*$fps)+6).".jpg"  );
$the="<head><meta charset='UTF-8'></head><table><tr><td  width='".$widt."' height='".$heigh."'  cellspacing='0' cellpadding=0  align='".$data[1]."' valign='".$data[2]."'  
  style='background-image:url(".$firstImage.")'  >";
fwrite($filhtml, $the."<font color='#".$data[4].$data[5].$data[6]."' size='".$data[3]."'>".str_replace("\\", "", $data[0])."</td></tr></table>" );
fclose($filhtml);
$javadir = "../../scripts/java/";
$exec= "java -Dfile.encoding=UTF8 -cp ".$javadir . " ImageWrapperHTML ../../data[".$_SERVER['REMOTE_ADDR']."]/data.html ../../data[".$_SERVER['REMOTE_ADDR']."]/output.png 1";
exec($exec);

echo $exec;

$length = file_get_contents("http://".getenv("HTTP_HOST")."/scripts/phpstudio/".$heigh);

echo " Lengh: ".$length;


@mkdir("../../data[".$_SERVER['REMOTE_ADDR']."]/temp");


session_start();
session_name('st');
$tt=0;

$theFrameTt =$_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/nrOfFramesz.html";
@unlink($theFrameTt);
$r = fopen($theFrameTt, "w");
fwrite($r, ($data[8]*$fps) );
fclose($r );


for($i=0;$i<($data[8]*$fps);$i+=1){

echo "Hallo";


 $fa= fopen($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/status.html", "w");
fwrite($fa, $i."");
fclose($fa);

$dataf=file_get_contents("http://".getenv("HTTP_HOST"). "/".$_GET['file']."?frame=".$i."&fcount=".($data[8]*$fps));

echo $dataf;
$data = explode("<next>", $dataf);

//text<next>center<next>middle<next>12<next>90<next>0<next>0<next>4<next>2
$fileHTML=$_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/data.html";
@unlink($fileHTML);
$filhtml = fopen($fileHTML, "w");


@unlink("../../data[".$_SERVER['REMOTE_ADDR']."]/_preview.png");




//fwrite($filhtml, "<font color='#".$data[4].$data[5].$data[6]."' size='".$data[3]."'>".str_replace("\\", "", $data[0]));
//fclose($filhtml);

//@unlink("../../data[".$_SERVER['REMOTE_ADDR']."]/data.html");
//@unlink("../../data[".$_SERVER['REMOTE_ADDR']."]/output.png");
@unlink("../../data[".$_SERVER['REMOTE_ADDR']."]/_preview.png");

/*
$exec= "java -cp ".$javadir . " ImageWrapperHTML ../../data[".$_SERVER['REMOTE_ADDR']."]/data.html ../../data[".$_SERVER['REMOTE_ADDR']."]/output.gif 640 480 ".$data[1]. " ".$data[2] ." ../../data[".$_SERVER['REMOTE_ADDR']."]/length.html ".$length ;
exec($exec);
*/




$firstImage="http://".getenv("HTTP_HOST")."/data[".$_SERVER['REMOTE_ADDR']."]/frames/Frames.".(40000000+($data[7]*$fps)+$i).".jpg";







$the="<head><meta charset='UTF-8'></head><table><tr><td  width='".$widt."' height='".$heigh."'  cellspacing='0' cellpadding=0  align='".$data[1]."' valign='".$data[2]."'  style='background-image:url(".$firstImage.")'  >";
fwrite($filhtml, $the."<font color='#".$data[4].$data[5].$data[6]."' size='".$data[3]."'>".str_replace("\\", "", $data[0])."</td></tr></table>" );
fclose($filhtml);








$javadir = "../../scripts/java/";
$exec= "java -Dfile.encoding=UTF8  -cp ".$javadir . " ImageWrapperHTML ../../data[".$_SERVER['REMOTE_ADDR']."]/data.html ../../data[".$_SERVER['REMOTE_ADDR']."]/frames/Frames.".(40000000+($data[7]*$fps)+$i).".jpg ".$heigh." ".$length;


exec($exec );


//$xec= "ffmpeg -i ../../data[".$_SERVER['REMOTE_ADDR']."]/_preview.png  ../../data[".$_SERVER['REMOTE_ADDR']."]/preview.jpg";
//@exec($xec);
//@copy("../../data[".$_SERVER['REMOTE_ADDR']."]/preview.jpg",  "../../data[".$_SERVER['REMOTE_ADDR']."]/frames/Frames.".(40000000+($data[7]*$fps)+$i).".jpg"); 
//@unlink("../../data[".$_SERVER['REMOTE_ADDR']."]/preview.jpg");




echo "Hoi";







}
unlink($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/status.html");




$filesSource=scandir("../../data[".$_SERVER['REMOTE_ADDR']."]/frames/");
   $rvn= count($filesSource );




        $rf= @fopen($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/frameCount.html", "w");
        @fwrite($rf, "".$rvn);
        @fclose($rf);

		        $rf= @fopen($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/nrOfFramesz.html", "w");
        @fwrite($rf, "".$rvn);
        @fclose($rf);
		
		
		        $rf= @fopen($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/nrOfFrames.html", "w");
        @fwrite($rf, "".$rvn);
        @fclose($rf);

?>
