<?php
/*
	Title: Web Based Video Maker / Editor 
	Description: General Purpose Graphics / Animation & Movie Editing
	Author:Lofti & Ridouan Ben Massoud
	Domain: soccer-kids.nl, ogena.net & e-rogen.eu
	Date: 20-01-2015
	File: /scripts/phpstudio/clear.php (Clear Current Project)
*/
session_name('ss');
session_start();
$_SESSION['frame']=100000;

for($j=0;$j<3000;$j++){
$_SESSION['a'.$j]="";
}



$files=scanDir($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/collect");
for($i=0;$i<count($files);$i++){
if($files[$i]=="." || $files[$i]==".."){
}
else{
@unlink($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/collect/".$files[$i]);
}
}




$files=scanDir($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/frames");
for($i=0;$i<count($files);$i++){
if($files[$i]=="." || $files[$i]==".."){
}
else{
@unlink($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/frames/".$files[$i]);
}
}



$files=scanDir($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/myMediaAudio");
for($i=0;$i<count($files);$i++){
	if($files[$i]=="." || $files[$i]==".."){
	}
	else{
		//@unlink($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/myMediaAudio/".$files[$i]);
	}
}

$files=scanDir($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]");
for($i=0;$i<count($files);$i++){
	if($files[$i]=="." || $files[$i]==".."){
	}
	else{
		if(is_dir($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/".$files[$i])){
		}
		else{
			//@unlink($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/".$files[$i]);
		}
	}
}



$files=scanDir($_SERVER['DOCUMENT_ROOT']."/temp");
for($i=0;$i<count($files);$i++){
	if($files[$i]=="." || $files[$i]==".."){
	}
	else{
		@unlink($_SERVER['DOCUMENT_ROOT']."/temp/".$files[$i]);
	}
}

//remove temp audio
$re=@file_get_contents("http://".getenv("HTTP_HOST")."/data[".$_SERVER['REMOTE_ADDR']."]/pproject.data");
$red=explode("<next>", $re);
$iii=count($red)-1;
for($ddo=1;$ddo<=$iii;$ddo++){
	//@unlink($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/audio".$ddo.".mp3");
	//@unlink($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/audio".$ddo.".wav");
	//@unlink($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/BSounf".$ddo.".wav");		
}


//@unlink($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/project.data");

//@unlink($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/project.data");

@unlink($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/myClip.mp4");
@unlink($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/sound.wav");
@unlink($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/sound.mp3");
//@unlink($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/projectAudio.data");


?>
