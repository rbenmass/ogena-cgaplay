<?php

$dir = "c:\program files\apache software foundation\apache2.2\htdocs\scripts\java";
$d=@file_get_contents("http://127.0.0.1/settings[".$_SERVER['REMOTE_ADDR']."]/screenCaptureMS.html"); 
if($d==""){
$d=10000;
}
$randr=rand(100,500);


echo "a";
$tempdir="tempdr".rand(1000,9999);
@mkdir("../../temp/".$tempdir);
exec("java -cp \"".$dir."\" ImageDesktopFrames ../../temp/".$tempdir."/capture".$randr."x ".$d);

$frames=scandir("../../temp/".$tempdir);
$nrFr=count($frames)-2;

$fps=round($nrFr/ceil($d/1000));

exec("ffmpeg -framerate ".$fps." -i ../../temp/".$tempdir."/capture".$randr."x1%7d.jpg -i ../../temp/".$tempdir."/capture".$randr."x.wav  -r 25 ../../data[127.0.0.1]/myMedia/clip".rand(100,900).".avi");



echo "b:".$fps;
?>