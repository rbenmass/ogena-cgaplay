<!--
	Title: Web Based Video Maker / Editor 
	Description: General Purpose Graphics / Animation & Movie Editing
	Author:Lofti & Ridouan Ben Massoud
	Domain: soccer-kids.nl, ogena.net & e-rogen.eu, theoriecentrum.nu
	Date: 20-01-2015
	File: scripts/phpstudio/save.php (Uploading single image frame, video)
-->
<?php

foreach(array('video', 'audio') as $type) {
    if (isset($_FILES["${type}-blob"])) {
   
        
		$fileName = $_POST["${type}-filename"];
        $uploadDirectory = 'uploads/'.$fileName;
        $fileNames[]= $fileName;
        if (!move_uploaded_file($_FILES["${type}-blob"]["tmp_name"], $uploadDirectory)) {
            echo(" problem moving uploaded file");
        }
		
		echo($fileName);
    }
}

$Web="Webcam.".rand(100,900).".mp4";
exec("ffmpeg -i uploads/".$fileNames[0]. " -i uploads/".$fileNames[1] .  "../data[".$_SERVER['REMOTE_ADDR']."]/myMedia/".$Web);
$e=scandir("uploads");
for($i=0;$i<count($e);$i++){
if($e[$i]=="." || $e[$i]==".."){
}
else{
unlink("../uploads/".$e[$i]);
}
}




?>
