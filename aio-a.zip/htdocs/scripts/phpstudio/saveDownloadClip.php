<?php
 /*
	Title: Web Based Video Maker / Editor 
	Description: General Purpose Graphics / Animation & Movie Editing
	Author:Lofti & Ridouan Ben Massoud
	Domain: soccer-kids.nl, ogena.net & e-rogen.eu
	Date: 20-01-2015
	File: /scripts/phpstudio/saveDownloadClip.php (Clip/Video download)
*/

    $file="../../".$_GET['path']."/".$_GET['file'];
    @header('Content-length: ' .  filesize($file));
    @header('Content-type: application/octet-stream');
    @header('Content-Disposition: attachment; filename= "' . $_GET['file'] . '"');

    @readfile($file);



?>
