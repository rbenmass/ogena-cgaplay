<?php

$df = @file_get_contents("http://".getenv("HTTP_HOST")."/data[".$_SERVER['REMOTE_ADDR']."]/projectAudio.data");
$dfr = str_replace($_GET['dat']."<next>", "", $df);
$file = @fopen($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/projectAudio.data", "w");
@fwrite($file, $dfr);
@fclose($file);



?>
