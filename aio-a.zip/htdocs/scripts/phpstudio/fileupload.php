<?php
/*
	Title: Web Based Video Maker / Editor 
	Description: General Purpose Graphics / Animation & Movie Editing
	Author:Lofti & Ridouan Ben Massoud
	Domain: soccer-kids.nl, ogena.net & e-rogen.eu, theoriecentrum.nu
	Date: 20-01-2015
	File: scripts/phpstudio/fileupload.php (Uploading)
*/	
 
$target_path = $_SERVER['DOCUMENT_ROOT']."/data/uploads";
 
$tmp_name = $_FILES['fileToUpload']['tmp_name'];
$size = $_FILES['fileToUpload']['size'];
$name = $_FILES['fileToUpload']['name'];
$name2 = $_GET['filename'];
 
$target_file = $target_path.$name;
 
$complete =$target_path.$name2;
$com = fopen($complete, "ab");
error_log($target_path);
 
    $in = fopen($tmp_name, "rb");
    if ( $in ) {
        while ( $buff = fread( $in, 1048576 ) ) {
            fwrite($com, $buff);
        }   
    }
    fclose($in);
 
fclose($com);
 
?>