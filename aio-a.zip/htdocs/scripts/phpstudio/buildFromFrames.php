<?php

$files=scandir($_SERVER['DOCUMENT_ROOT']."/temp");
$ee=count($files);
$fi=rand(100,900);
exec("ffmpeg -f lavfi -i aevalsrc=0 -t ".$_GET['secsPassed']."  -q:a 9 -acodec libmp3lame ../../temp/xsec.mp3");
exec("ffmpeg -r ".round($ee/$_GET['secsPassed'])." -i ../../temp/Picture1%5d.jpg -i ../../temp/xsec.mp3 ../../data[".$_SERVER['REMOTE_ADDR']."]/myMedia/Weam.".$fi.".mp4");


?>
