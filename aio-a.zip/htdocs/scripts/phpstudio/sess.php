<!--
	Title: Web Based Video Maker / Editor 
	Description: General Purpose Graphics / Animation & Movie Editing
	Author:Lofti & Ridouan Ben Massoud
	Domain: soccer-kids.nl, ogena.net & e-rogen.eu, theoriecentrum.nu
	Date: 20-01-2015
	File: scripts/phpstudio/session.php (Build gradually the Video in  xml file)
-->
<?php
date_default_timezone_set('Europe/Amsterdam');
echo "333ewe.......";

if($_GET['dataFile']=="" ){

echo "http://".getenv("HTTP_HOST")."/data[".$_SERVER['REMOTE_ADDR']."]/projectz.data";
$dat = @file_get_contents("http://".getenv("HTTP_HOST")."/data[".$_SERVER['REMOTE_ADDR']."]/projectz.data");

}
else{
$dat = @file_get_contents("http://".getenv("HTTP_HOST")."/data[".$_SERVER['REMOTE_ADDR']."]/".$_GET['dataFile']);
}

//echo "dat.........".$dat;


if($_GET['insert']!=""){

        $datat="";
        $da = explode("<next>", $dat);
        for($i=0;$i<$_GET['insert'];$i++){
                $datat.=$da[$i]."<next>";
        }
        $datat.=$_GET['data']."<next>";

        for($i=$_GET['insert'];$i<count($da);$i++){
                $datat.=$da[$i]."<next>";
        }


        echo $datat;
        $ff = fopen($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/".$_GET['dataFile'], "w");
        fwrite($ff, str_replace("<next><next>", "<next>", $datat));
        fclose($ff);
}

if($_GET['remove']!=""){
	$res=$dat.$_GET['data']."<next>";
	$res="";
	$the="";
	$datat="";
	$datae=explode("<next>", $dat);
	echo "removing...";	

for($i=0;$i<count($datae);$i++){
		if($i==$_GET['remove']){
		}
		else{
			$datat.=$datae[$i]."<next>";	
		}

	}
	$ff = fopen($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/".$_GET['dataFile'], "w");
	 fwrite($ff, str_replace("<next><next>", "<next>", $datat));

	fclose($ff);
}



if($_GET['update']!=""){

	echo "Updating";
        $res=$dat.$_GET['data']."<next>";
        $res="";
        $the="";
        $datat="";
        $datae=explode("<next>", $dat);
        for($i=0;$i<count($datae);$i++){
                if($i==$_GET['update']){

			$datat.=$_GET['data']."<next>";

                }
                else{
                        $datat.=$datae[$i]."<next>";
                }

        }
        $ff = fopen($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/".$_GET['dataFile'], "w");
        

 fwrite($ff, str_replace("<next><next>", "<next>", $datat));


        fclose($ff);
}




?>
