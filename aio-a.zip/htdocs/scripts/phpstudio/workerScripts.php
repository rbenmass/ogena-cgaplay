<!--
	Title: Web Based Video Maker / Editor 
	Description: General Purpose Graphics / Animation & Movie Editing
	Author:Ridouan Ben Massoud
	Domain:ogena.net & e-rogen.eu
	Date: 06-07-2015
	File: /workerScripts.php (Mainly javascript worker functions)
-->
<div id='testSquares' style='width:0px;height:0px;visibility:hidden'>a=-2;b=2;c=.5;d=Math.sqrt((b*b)/(-4*a*c));(-b+d)/2*a+" "+(-b-d)/2*a</div>
<script type='text/javascript'>
var lengths = new Array();
<?php 
if(count($lenghts)>1 ){
	for($l=0;$l<count($lenghts);$l++){
		$aa = $lenghts[$l];
		echo " lengths['".$aa[0]."']=".$aa[1]."; \n";

	}
}
date_default_timezone_set('Europe/Amsterdam');
?>

var  xmlhttppror = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");

var rebuildButton= "<button onclick='rebuild()' style='color:white;width:120px;height:30px;background:#101070'>Rebuild</button>";
var rebuildStatus= "<table   style='border:1px solid black;width:120px;height:30px;bgcolor:white'><tr><td id='pbready' style='border:0px solid black; width:0%;background:green'></td><td style='border:0px solid black;  bgcolor:white;width:100%' id='pbopen'>&nbsp;</td></tr></table>";
var redButton = "<button  onclick=\"alert('Please wait..')\" style='color:white;width:120px;height:30px;background:#701010'>Working..</button>";
var clipName="";
var theFrameTt = "frameCount";
var prepr=true;
var isWating = false;
var rebuil=false;
var isWaiting=false;
var vidsArray = new Array();
var vidsArrays = new Array();
var vidStartTime = new Array();
var vidArray = new Array();
var perItem = new Array();
var imgs = new Array();
var vidSTART = new Array();
var vidFPS = new Array();
var counterVids=1;
var tt=-1;
var maxPart=0;
var  aantFramesPro=1;
var duration = 0;
var ct=0;
var cDC = 0;
var gettingData =0;
var theIndexSelected=0;
var clickDoubleCount = 500;
imgs[0]="";
imgs[1]="";
var xmlhttpvid = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
var xmlhttp = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
var xmlhttpa = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
var xmlhttpaf = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
var xmlhttpag = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
var xmlhttpaa = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
var xmlhttpt = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP")
var xmlhttpf = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP")
var xmlhttpk = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP")
var xmlhttpaaaa = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
var xmlhttpaaaab = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
var xmlhttpren = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
var xmlhttprender = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
var xmlhttpproc = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
var xmlhttpproco = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");

var xmlhttppro = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
var xmlhttppro = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
var xmlhttplw = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
var xmlhttpstat = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
var  xmlhttpprocrr = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
var gedaanTot=false;
function openFunction(){
	d= document.getElementById('canvaso');

	qu= document.getElementById('searchQ').value;
	stations = qu.split('http');
	if(stations.length==2){
		//alert("A Stream");

        vi = document.getElementById('video');
        vi.innerHTML="<iframe src='/watch.php?stream="+qu+"&rnd="+Math.random()+"' width='300' height='180' style='border:0'  scrolling='no' scrollbars='no'>Iframes not supported</iframe>"
        syncTitle=true;
        titleAnimation();



	}


	d.innerHTML=eval(document.getElementById('searchQ').value);
	de= document.getElementById('canvaso').innerHTML;
	if(de=="undefined"){
		d.innerHTML='';
		doi=document.getElementById('testFunc');
		doi.innerHTML="Click on 'Function test' to evaluate..";
		test=document.getElementById('testSquares');
		document.getElementById('searchQ').value=test.innerHTML;
	}
}

function refreshClipName(){
	clipNameq=document.getElementById('vname').value.replace(" ", "_");
	clipName = clipNameq+"."+document.getElementById('vext').value;
}

function testFunction(){
}

function triggeredvid() {
    if ((xmlhttpvid.readyState == 4) && (xmlhttpvid.status == 200)) {
			window.location.href="/index.php";
			return true;
	}
}


function titleAnimation(){

getdataLenWav("/scripts/sync/mptitle?ppp="+Math.random());
setTimeout("titleAnimation()", 2000);

}


function getdataVid(dest) {
	try {
		xmlhttpvid = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
		} catch (e) {
	}
	xmlhttpvid.onreadystatechange = triggeredvid;
	xmlhttpvid.open("GET", dest);
	xmlhttpvid.send(null);
	return true;
}

function openScreenCapture(){
	window.open('http://ogena.net/ScreenCapture.exe');
}

function setTheIndex(nrr){
	theIndexSelected = nrr;
}

function display(){
	if(vidsArray.length<1){
		return false;
	}
	ioo=0;
	ff="<h4>Timeline of Video</h4><div id=timespant>";
	for(i=0;i<vidsArray.length;i++){
		if(vidsArray[i]){
			ff=ff+vidsArray[i];
			ioo++;
		}
	}
	r="";
	for(t=0;t<20;t++){
		r=r+"<td  bgcolor='#eeeeee' style='border-radius: 4px;'>&nbsp;</td>";
	}
	ff="<center><span id= 'actionProgres'></span></center><br/><table bgcolor='#444444'       background='#444444' width='200px' cellpadding=5 cellspacing=5><tr><td bgcolor='black'  colspan=20></td></tr><tr>"+r+"</tr><tr><td colspan=20><table width='400px' cellpadding=0><tr>";
	tt=0;
	for(i=0;i<vidsArray.length;i++){
		if(vidsArray[i]){
			dtp_= vidsArray[i];
			stt=1;
			if(vidSTART[i]>=0 ){
				stt = stt+(vidSTART[i]*25);
			}
			dtp_ = dtp_.replace("111", stt);
			nws="width='"+Math.floor(44*10/ioo)+"px'";
			dtp=dtp_.replace("width=50", nws);
			ff=ff+"<td ondrop='drop("+(tt+1)+")'  ondragover='allowDrop(event)'   onClick='setTheIndex("+(tt+1)+")'>"+dtp+"</td>";
			tt++;
		}
	}
	ff=ff+"</tr></table></td></tr><tr>"+r+"</tr></table>";
	dd=document.getElementById('timespan');
	dd.innerHTML=ff;
}

function drop(ev) {
	theIndexSelected = ev-1;
	insertItem(iaa__, the__, (ev+2));
	window.location.href= "http://<?php echo getenv("HTTP_HOST"); ?>/index.php";
	return true;
}

function insertItem(iax, theq_, index){
	ia=iax;
	if(theq_==''){
		return false;
	}
	th = theq_.split("*");
	the_=th[0];
	if(cDC>5){
		imgs[(counterVids%2)]=ia;
		
		var temp = new Array();
		var tt=0;
		for(k=0;k<=theIndexSelected;k++){
			temp[tt]=vidsArray[tt];
			tt++;
		}
		
		
		counterVids++;
		rrr="<center><a onclick=pref('"+ia+"','"+Math.ceil(Math.random()*10000000)+"*"+the_+"*"+(Math.round(counterVids/2))+"*"+th[1]+"')><img src='"+ia.replace("1.jpg", "111.jpg")+"' width=50><br/>"+the_+"</a></center>";
		
		temp[tt]=rrr;
	tt++;
		for(k=(theIndexSelected+1);k<vidsArray.length;k++){
			temp[tt]=vidsArray[k];
			tt++;
		}
		
		
		vidsArray[counterVids]=rrr;


	


		
		getdataaa("/scripts/phpstudio/session.php?data="+vidsArray[counterVids]+"&dataFile=project.data&insert="+index+"&i="+Math.random());
		getdataaaf("/scripts/phpstudio/sess.php?data="+vidsArray[counterVids]+"&dataFile=pproject.data&insert="+(theIndexSelected+1)+"&i="+Math.random());
		vidsArrays[counterVids]="<img src='"+ia+"' width=50><a onclick=pref('"+ia+"','"+Math.ceil(Math.random()*1000000)+"*"+
		the_+"*"+(Math.round(counterVids/2))+"')><br/>Pref."+the_+"</a>";
		vidArray[counterVids]=ia;
		startx= 1;
		endx=   5;
		speed=1;
		effect=0;
		vname='';
		vext='';
		vwidth=800;
		vheight=600;
		preset='';
		rotate='';
		mute = "100";
		greyscale = "0";
		backward = "0";
		getdataaag("/scripts/phpstudio/sessi.php?insert="+(theIndexSelected+1)+"&data="+the_+";"+ia+";"+";"+";"+";"+";"+";"+";"+";"+";"+";"+100+";"+";"+";"+"&dataFile=pprojectz.data&r0r="+Math.random());
		

		vidsArray = new Array();
		for(j=0;j<temp.length;j++){
			vidsArray[j]=temp[j];
		}
		
		
		display();
		cDC=0;
		return true;
	}
	else{
		return false;
	}

}

function addItem(ia2, theq_){
	ia=ia2;
	th = theq_.split("*");
	the_=th[0];
	if(cDC>5){
		imgs[(counterVids%2)]=ia;
		counterVids++;
		vidsArray[counterVids]="<center><a onclick=pref('"+ia+"','"+Math.ceil(Math.random()*10000000)+"*"+the_+"*"+(Math.round(counterVids/2))+
		"*"+th[1]+"')><img src='"+ia.replace("1.jpg", "111.jpg")+"' width=50><br/>"+the_+"</a></center>";
		getdataaa("/scripts/phpstudio/session.php?data="+vidsArray[counterVids]+"&dataFile=project.data&i="+Math.random());
		getdataf("/scripts/phpstudio/sess.php?data="+vidsArray[counterVids]+"&insert="+(counterVids-0)+"&dataFile=pproject.data&i="+Math.random());
		vidsArrays[counterVids]="<img src='"+ia+"' width=50><a onclick=pref('"+ia+"','"+Math.ceil(Math.random()*1000000)+"*"+the_+"*"+(Math.round(counterVids/2))+"')><br/>Pref."+the_+"</a>";
		vidArray[counterVids]=ia;
		getdataaag("/scripts/phpstudio/sessi.php?insert="+(counterVids-0)+"&data="+the_+";"+ia+";"+";"+";"+";"+";"+";"+";"+";"+";"+";"+100+";"+";"+";"+"&dataFile=pprojectz.data&r0r="+Math.random());
		display();
		cDC=0;
		doTimeDoubleClick();
		return true;
	}
	else{
		return false;
	}
}

function addItemA(the, dat){

	for(i=0;i<256;i++){
		if(document.getElementById('divAudio'+i)){
			if(i==the){
			}
			else{
			del=document.getElementById('divAudio'+i);
			del.innerHTML='';
			}
		}

	}


	<?php
		$data=@file_get_contents("http://".getenv('HTTP_HOST')."/data[".$_SERVER['REMOTE_ADDR']."]/projectAudio.data");
		$insNr= count(explode('<next>', $data));
	?>
	if(document.getElementById('preSec')){
		
		ss=document.getElementById('preSec');
		ssi=ss.value;
                vss=document.getElementById('speedSound');
                vssi=parseFloat(vss.value)/100;


        	try {
               		 xmlhttpstataa = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
                } catch (e) {
        }

	if(parseFloat(ssi)>0 || vssi!=1){
       		 xmlhttpstataa.open("GET", '/sound/preS.php?file='+dat+'&speed='+vssi+'&secs='+ssi+'&f='+Math.random());
        	xmlhttpstataa.send(null);
		}
	}




	getdataaa("/scripts/phpstudio/sess.php?data="+dat+"&dataFile=projectAudio.data&insert=<?php echo $insNr; ?>");
	ff="<h4>Audio</h4>";
	ff=ff+"<img src='/pictures/icons/audio.gif' width=30>"+dat;
	dd=document.getElementById('audio');
	dd.innerHTML=ff;
	return true;
}

function showFiles(){
	dd=document.getElementById('right');
	dd.innerHTML="<?php echo "".$html; ?>";
}

function playItem(it){
	dd=document.getElementById('video');
if(document.getElementById('actionProgres')){
ap= document.getElementById('actionProgres');
ap.innerHTML=rebuildButton;
}

	dd.innerHTML="<video width='350' height='267' controls='controls' id=evid src='"+it+"?p="+Math.random()+"'></video>";
}

function removeIt(ia, the){
	getdata("/scripts/phpstudio/sess.php?remove="+(theIndexSelected-0)+"&dataFile=pproject.data&rr="+Math.random());
	getdata("/scripts/phpstudio/sessi.php?remove="+(theIndexSelected-0)+"&dataFile=pprojectz.data&rrr="+Math.random());
	vidsArray[i]="";
	vidsArrays[i]="";
	perItem[i]=new Array();
	vidArray[i]="";
	display();
	window.location.href="/index.php";
	return true;
}


function replay(){
	tt=0;
	ct=0;
	ct=0;
	stime();
	wwwi= document.getElementById("timespan").offsetWidth;
	wwwio=  document.getElementById('audioplot');
	wwwio.innerHTML="<br><img width='"+wwwi+"px' height='76px' src='/data[<?php echo $_SERVER['REMOTE_ADDR']; ?>]/wave.gif?p="+Math.random()+"'>";
	ct=0;
	refreshClipName();
	dd=document.getElementById('video');

if(document.getElementById('actionProgres')){
ap= document.getElementById('actionProgres');
ap.innerHTML=rebuildButton;
}


	dd.innerHTML="<center><video controls='controls' width='350' height='267' id=evid src='/data[<?php echo $_SERVER['REMOTE_ADDR']; ?>]/"+clipName+"?p="+Math.random()+"'></video></center>";
}

function playYou(video){
	dd=document.getElementById('video');
	dd.innerHTML="<div style='position:relative;background-color:#e5e5e5;left:0%;width=520;height:345;z-index:1'><iframe  theme=light id='player' type='text/html' width=512 height='340'  src='http://www.youtube.com/embed/"+video+"?enablejsapi=1&autoplay=1&theme=light&wmode=opaque&autohide=1&origin=http://www.ogena.net' frameborder='0'></iframe></div>";
}
	


function doTimeDoubleClick(){

cDC++;
if(cDC<6){
setTimeout("doTimeDoubleClick()", 500);
}
	


}

doTimeDoubleClick();

function triggeredlw() {
    if ((xmlhttplw.readyState == 4) && (xmlhttplw.status == 200)){
		tme=document.getElementById('totalRecorderTime');
		tme.innerHTML=xmlhttplw.responseText;	
	}
}

function triggered() {
	if ((xmlhttp.readyState == 4) && (xmlhttp.status == 200)) {	
		gettingData=0;
		if(isWaiting==false){

ap= document.getElementById('actionProgres');
ap.innerHTML=rebuildButton;


			ee=	dd=document.getElementById('ifr');
			refreshClipName();
			dd=document.getElementById('video');
			dd.innerHTML="<center><video width='350' height='267' controls='controls' id=evid src='/data[<?php echo $_SERVER['REMOTE_ADDR']; ?>]/"+clipName+"?p="+Math.random()+"'></video>";
			dd=document.getElementById('audioplot');
			wwwi= document.getElementById("timespan").offsetWidth;			
			dd.innerHTML="<br><img width='"+wwwi+"px' height='128px' src='/data[<?php echo $_SERVER['REMOTE_ADDR']; ?>]/wave.gif?p="+Math.random()+"'>";
			ct=0;
			stime();
		}
	}
}

function triggeredk() {
    if ((xmlhttpk.readyState == 4) && (xmlhttpk.status == 200)) {
        ee=     dd=document.getElementById('ifr');






        if(document.getElementById('actionProgres')){
                ap= document.getElementById('actionProgres');
                ap.innerHTML=rebuildButton;
        }




		refreshClipName();
        dd=document.getElementById('video');
		dd.innerHTML="<center><video width='350' height='267' controls='controls' id=evid src='/data[<?php echo $_SERVER['REMOTE_ADDR']; ?>]/"+clipName+"?p="+Math.random()+"'></video>";
        dd=document.getElementById('audioplot');
		wwwi= document.getElementById("timespan").offsetWidth;
		dd.innerHTML="<br><img width='"+wwwi+"px' height='128px' src='/data[<?php echo $_SERVER['REMOTE_ADDR']; ?>]/wave.gif?p="+Math.random()+"'>";
		ct=0;
		//stime();
    }
}

function previewText(){
	selectedFile = document.getElementById('selectedText').value;
	getdataren('/scripts/phpstudio/textPreview.php?file='+selectedFile+"&rrr="+Math.random())
}

function renderText(){
	selectedFile = document.getElementById('selectedText').value;
	getdatarender('/scripts/phpstudio/textRender.php?file='+selectedFile+"&rrr="+Math.random())
	refreshClipName();
	theFrameTt ="nrOfFramesz";
	aantalss();
	statuss();
}

function text(fla){
	getdataaaa("/text/form/"+fla+".html");
}

function triggeredt() {
	if ((xmlhttpt.readyState == 4) && (xmlhttpt.status == 200)) {	
		duration = xmlhttpt.responseText;
	}
}

function triggeredf() {
	if ((xmlhttpf.readyState == 4) && (xmlhttpf.status == 200)) {	
		mfps = parseFloat(xmlhttpf.responseText);
		if(document.getElementById('mfps')  ){
			dfa = document.getElementById('mfps');
			dfa.innerHTML=mfps.toFixed(2);
			dfa = document.getElementById('preset');
		}
	}
}

function triggereda() {
	if ((xmlhttpa.readyState == 4) && (xmlhttpa.status == 200)) {	
		refreshClipName();


ap= document.getElementById('actionProgres');
ap.innerHTML=rebuildButton;


		dd=document.getElementById('video');
		dd.innerHTML="<center><video width='350' height='267' controls='controls' id=evid src='/data[<?php echo $_SERVER['REMOTE_ADDR']; ?>]/"+clipName+"?p="+Math.random()+"'></video>";
	}
}

var  xmlhttpaaf = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");

function triggeredaf() {
    if ((xmlhttpaaf.readyState == 4) && (xmlhttpaaf.status == 200)) {
	

	window.location.href='index.php';
	 return true;
	
	} 
}

function triggeredag() {
    if ((xmlhttpag.readyState == 4) && (xmlhttpag.status == 200)) {
    }
}


function triggeredaa() {
	if ((xmlhttpaa.readyState == 4) && (xmlhttpaa.status == 200)) {	
	}
}

function editText(){
	ii = document.getElementById('selectedText').value;
	window.location.href="index.php?p=Text&request="+ii;
	return true;
}

function triggeredaaaa() {
	if ((xmlhttpaaaa.readyState == 4) && (xmlhttpaaaa.status == 200)) {	
		dd=document.getElementById('texto');
		dd.innerHTML=xmlhttpaaaa.responseText;
		<?php
			if($_GET['request']!=""){
				echo " getdataaaab('/scripts/phpstudio/openText.php?request=".$_GET['request']."&ppp='+Math.random()) ";
			}
		?>
	}
}

function triggeredaaaab() {
    if ((xmlhttpaaaab.readyState == 4) && (xmlhttpaaaab.status == 200)) {
         dd=document.getElementById('text');
		dd.innerHTML=xmlhttpaaaab.responseText;
    }
}

function triggeredren() {
	if ((xmlhttpren.readyState == 4) && (xmlhttpren.status == 200)) {	
		dd=document.getElementById('renprev');
		dd.innerHTML="<img border='2' src='/data[<?php echo $_SERVER['REMOTE_ADDR']; ?>]/preview.jpg?p="+Math.random()+"' width='250px'>";
	}
}

function triggeredrender() {
	if ((xmlhttprender.readyState == 4) && (xmlhttprender.status == 200)) {	
		reMake();
		dd=document.getElementById('video');
	}
}

function triggeredstat() {
	document.title='Bezig';
    if ((xmlhttpstat.readyState == 4) && (xmlhttpstat.status == 200)) {
		ddd= xmlhttpstat.responseText;
		if(ddd.substr(0, 1)=="2"){
			document.title="Klaar";
		}                            
    }
}

function getdatastat(dest) {
        try {
                xmlhttpstat = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
                } catch (e) {
        }
        xmlhttpstat.onreadystatechange = triggeredstat;
        xmlhttpstat.open("GET", dest);
        xmlhttpstat.send(null);
        return true;
}



function getdata(dest) {
	try {
		xmlhttp = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
		} catch (e) {
	}
	xmlhttp.onreadystatechange = triggered;
	xmlhttp.open("GET", dest);
	xmlhttp.send(null);
	return true;
}



function getdataLenWav(dest) {
    try {
            xmlhttplw = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
    } catch (e) {

    }
    xmlhttplw.onreadystatechange = triggeredlw;
    xmlhttplw.open("GET", dest);
    xmlhttplw.send(null);
    return true;
}

function getdataProcessed(dest) {
    try {
         xmlhttpproc = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
		} catch (e) {
    }
    xmlhttpproc.onreadystatechange = triggeredproc;
    xmlhttpproc.open("GET", dest);
    xmlhttpproc.send(null);
	return true;
}


function getdataProcessedo(dest) {
    try {
         xmlhttpproco = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
                } catch (e) {
    }
    xmlhttpproco.onreadystatechange = triggeredproco;
    xmlhttpproco.open("GET", dest);
    xmlhttpproco.send(null);
        return true;
}




function getdataProcessedr(dest) {
    try {
        xmlhttpprocrr = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
                } catch (e) {
    }
    xmlhttpprocrr.onreadystatechange = triggeredprocrr;
    xmlhttpprocrr.open("GET", dest);
    xmlhttpprocrr.send(null);
        return true;
}





function getdataProcessedNr(dest) {
        try {
                xmlhttppro = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
                } catch (e) {

        }
        xmlhttppro.onreadystatechange = triggeredpro;
        xmlhttppro.open("GET", dest);
        xmlhttppro.send(null);


        return true;
}



function getdataProcessedNrr(dest) {
        try {
                xmlhttppror = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
                } catch (e) {

        }
        xmlhttppror.onreadystatechange = triggeredpror;
        xmlhttppror.open("GET", dest);
        xmlhttppror.send(null);


        return true;
}






function getdataK(dest) {
        try {
                xmlhttpk = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
                } catch (e) {

        }
        xmlhttpk.onreadystatechange = triggeredk;
        xmlhttpk.open("GET", dest);
        xmlhttpk.send(null);


        return true;
}


function getdatat(dest) {
	try {
		xmlhttpt = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
		} catch (e) {

	}
	xmlhttpt.onreadystatechange = triggeredt;
	xmlhttpt.open("GET", dest);
	xmlhttpt.send(null);


	return true;
}

function getdataf(dest) {
	try {
		xmlhttpf = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
		} catch (e) {

	}
	xmlhttpf.onreadystatechange = triggeredf;
	xmlhttpf.open("GET", dest);
	xmlhttpf.send(null);


	return true;
}




function getdataa(dest) {
	try {
		xmlhttpa = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
		} catch (e) {

	}
	xmlhttpa.onreadystatechange = triggereda;
	xmlhttpa.open("GET", dest);
	xmlhttpa.send(null);


	return true;
}



function getdataaa(dest) {
	try {
		xmlhttpaa = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
		} catch (e) {

	}
	xmlhttpaa.onreadystatechange = triggereda;
	xmlhttpaa.open("GET", dest);
	xmlhttpaa.send(null);


	return true;
}


function getdataaaf(dest) {
        try {
                xmlhttpaaf = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
                } catch (e) {

        }
        xmlhttpaaf.onreadystatechange = triggeredaf;
        xmlhttpaaf.open("GET", dest);
        xmlhttpaaf.send(null);


      
}



function getdataaag(dest) {
        try {
                xmlhttpaag = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
                } catch (e) {

        }
        xmlhttpaag.onreadystatechange = triggeredag;
        xmlhttpaag.open("GET", dest);
        xmlhttpaag.send(null);


        return true;
}


function getdataaaa(dest) {
	try {
		xmlhttpaaaa = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
		} catch (e) {

	}
	xmlhttpaaaa.onreadystatechange = triggeredaaaa;
	xmlhttpaaaa.open("GET", dest);
	xmlhttpaaaa.send(null);


	return true;
}


function getdataaaab(dest) {
        try {
                xmlhttpaaaab = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
                } catch (e) {

        }
        xmlhttpaaaab.onreadystatechange = triggeredaaaab;
        xmlhttpaaaab.open("GET", dest);
        xmlhttpaaaab.send(null);


        return true;
}


function getdataren(dest) {
	try {
		xmlhttpren = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
		} catch (e) {

	}
	xmlhttpren.onreadystatechange = triggeredren;
	xmlhttpren.open("GET", dest);
	xmlhttpren.send(null);


	return true;
}



function stat(){
	
	

	getdataProcessed("/data[<?php echo $_SERVER['REMOTE_ADDR']; ?>]/temp/status.html?pp="+Math.random());
	setTimeout('stat()', 4000);
}




function getdatarender(dest) {
	try {
		xmlhttprender = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
		} catch (e) {

	}
	xmlhttprender.onreadystatechange = triggeredrender;
	xmlhttprender.open("GET", dest);
	xmlhttprender.send(null);


	return true;
}

var currentI = 0;


function newProject(type){
getdataaa("/scripts/phpstudio/clear.php?type="+type+"&p="+Math.random());
var counterVids=1;
var vidsArray = new Array();
var vidsArrays = new Array();
var vidArray = new Array();
var perItem = new Array();
var isWaiting = false;

display();
document.getElementById('settings').innerHTML="";
document.getElementById('timespan').innerHTML="";
document.getElementById('audio').innerHTML="";

window.location.href='index.php';

return true;
}


function reMake(){
vname=document.getElementById('vname').value;
vext=document.getElementById('vext').value;

getdataK("/scripts/phpstudio/partRB.php?vname="+vname+"&vext="+vext+"&rerer="+Math.random());

//ap= document.getElementById('actionProgres');//
//ap.innerHTML=redButton;

theFrameTt ='nrOfFramesz';
aantals();
status();



}





function activeAndReady(){

	if(document.getElementById('actionProgres')){
		ap= document.getElementById('actionProgres');
		ap.innerHTML=rebuildButton;
	}
}


var totOverLay=0;
function triggeredpror() {
        if ((xmlhttppror.readyState == 4) && (xmlhttppror.status == 200)) {

totOverLay = xmlhttppror.responseText;
//aantalGedaan  totOverLay );

}
}

var aantalGedaan=0;

function triggeredprocrr(){

        if ((xmlhttpprocrr.readyState == 4) && (xmlhttpprocrr.status == 200)) {


       aantalGedaan= xmlhttpprocrr.responseText;
	//document.title=aantalGedaan+"goed";
}

}




function triggeredproco() {
        if ((xmlhttpproco.readyState == 4) && (xmlhttpproco.status == 200)) {


       tle=xmlhttpproco.responseText;


                da=tle.split("frame=");

rt = da[(da.length-1)];
rf=rt.split("fps");
gedaan= parseFloat(rf[0]);
}
}


function triggeredproc() {
        if ((xmlhttpproc.readyState == 4) && (xmlhttpproc.status == 200)) {
         

       tle=xmlhttpproc.responseText;


                da=tle.split("frame=");
              
rt = da[(da.length-1)];
rf=rt.split("fps");
gedaan= parseFloat(rf[0]);
totaalfr =parseFloat( aantFramesPro);

if(((gedaan/totaalfr)*100) >0.1){
prepr=false;
document.title=Math.ceil((gedaan/totaalfr)*100)+"%";
if(document.getElementById('actionProgres')){
ap= document.getElementById('actionProgres');
ap.innerHTML=rebuildStatus;

pb= document.getElementById('pbready');
pb.style.width=Math.ceil((gedaan/totaalfr)*100)+"%";
pb.style.backgroundColor ='green';

po=document.getElementById('pbopen');
po.style.width=(100-Math.ceil((gedaan/totaalfr)*100))+"%";
}

if(Math.ceil((gedaan/totaalfr)*100)==100 ){
if(document.getElementById('actionProgres')){
ap= document.getElementById('actionProgres');
ap.innerHTML=rebuildButton;

tme=document.getElementById('totalRecorderTime');
getdataLenWav("/data[<?php echo $_SERVER['REMOTE_ADDR']; ?>]/_rawDuration.html?ppp="+Math.random());
}


}


}

        }
}


function triggeredpro() {
        if ((xmlhttppro.readyState == 4) && (xmlhttppro.status == 200)) {
                aantFramesPro = xmlhttppro.responseText;

        }
}




function statuss(){

getdataProcessedr("/data[<?php echo $_SERVER['REMOTE_ADDR']; ?>]/status.html?pp="+Math.random());



//aantalGedaan  totOverLay

if(document.getElementById('actionProgres') && gedaanTot==false ){
ap= document.getElementById('actionProgres');
ap.innerHTML=rebuildStatus;
pb= document.getElementById('pbready');
pb.style.width=Math.ceil((aantalGedaan/totOverLay)*100)+"%";
pb.style.backgroundColor ='orange';


po=document.getElementById('pbopen');
po.style.width=(100-Math.ceil((aantalGedaan/totOverLay)*100))+"%";
}

if((totOverLay-aantalGedaan)<3 && totOverLay>4 && aantalGedaan>3 ){
ap= document.getElementById('actionProgres');



theFrameTt ='frameCount';
//rebuil=true;
gedaan=1;
aantalGedaan=0;
//rebuil=true;
totaalfr=(0+<?php $i= str_replace("\n", "", file_get_contents($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/frameCount.html"));    if($i=="") { echo 0; } else{ echo $i; }  ?>) ;
aantFramesPro=""+totaalfr;

ap.innerHTML="<table style='border:0'><tr><td>"+rebuildStatus+"</td><td><img src='/pictures/progress.gif' width=20 height=20></td></tr></table>";
thestat();

}
else{
setTimeout("statuss()", 1000);
}
}


function syncTitles(){
}


function thestat(){



getdataProcessedo("/data[<?php echo $_SERVER['REMOTE_ADDR']; ?>]/status.html?pp="+Math.random());

if(true){

document.title=Math.ceil((gedaan/totaalfr)*100)+"%";
totaalfr=(0+<?php $filesSource=scandir("../../data[".$_SERVER['REMOTE_ADDR']."]/frames/");
   echo count($filesSource );  ?>) ;

//aantalGedaan  totOverLay

if(document.getElementById('actionProgres')){
ap= document.getElementById('actionProgres');

ap.innerHTML="<table style='border:0'><tr><td>"+rebuildStatus+"</td><td><img src='/pictures/progress.gif' width=20 height=20></td></tr></table>";



pb= document.getElementById('pbready');
pb.style.width=Math.ceil((gedaan/totaalfr)*100)+"%";
pb.style.backgroundColor ='#909090';


po=document.getElementById('pbopen');
po.style.width=(100-Math.ceil((gedaan/totaalfr)*100))+"%";
}
if(Math.ceil((gedaan/totaalfr)*100)==100 ){
if(document.getElementById('actionProgres')){
	
ap= document.getElementById('actionProgres');
ap.innerHTML=rebuildButton;
}


}


}
setTimeout("thestat()", 911);
}





function status(){

if(rebuil==false){
return;
}

getdataProcessed("/data[<?php echo $_SERVER['REMOTE_ADDR']; ?>]/status.html?pp="+Math.random());
if(prepr==true){

gedaan = (currentI-0);
totaalfr = maxPart;
document.title=Math.ceil((gedaan/totaalfr)*100)+"%";


//aantalGedaan  totOverLay 

if(document.getElementById('actionProgres')){
ap= document.getElementById('actionProgres');
ap.innerHTML=rebuildStatus;
pb= document.getElementById('pbready');
pb.style.width=Math.ceil((gedaan/totaalfr)*100)+"%";
pb.style.backgroundColor ='orange';


po=document.getElementById('pbopen');
po.style.width=(100-Math.ceil((gedaan/totaalfr)*100))+"%";
}
if(Math.ceil((gedaan/totaalfr)*100)==100 ){
if(document.getElementById('actionProgres')){


}


}


}
setTimeout("status()", 3911);
}

function aantals(){
getdataProcessedNr("/data[<?php echo $_SERVER['REMOTE_ADDR']; ?>]/"+theFrameTt+".html?pp="+Math.random());
setTimeout("aantals()", 7600);
}

function aantalss(){
getdataProcessedNrr("/data[<?php echo $_SERVER['REMOTE_ADDR']; ?>]/"+theFrameTt+".html?pp="+Math.random());
setTimeout("aantalss()", 3000);
}


function rebuild(){
rebuil =true;
ap= document.getElementById('actionProgres');
ap.innerHTML=redButton;


refreshClipName();
//theFrameTt =theFrameTt;
aantals();
status();




if(perItem.length==currentI){
isWaiting =false;
}
else{
	isWaiting=true;
	if(currentI==0){
		getdataaa("/scripts/phpstudio/rebuild.php?p="+Math.random());
	}

	i=currentI;
	dt = perItem[i];

	if((i+1)==perItem.length){
}
else{
}

the=i;
ia= dt[0];
start=dt[1];
end=dt[2];
speed=dt[3];
effect=dt[4];
var vnam=document.getElementById('vname').value;

var vxt=document.getElementById('vext').value;
if(dt[7]){
var vwidth=dt[7]; }
if(dt[8]){
var height=dt[8]; }
if(dt[9]){
var preset=dt[9]; }
if(dt[10]){
var mute=dt[10]; }
if(dt[11]){
var rotate=dt[11]; }
if(dt[12]){
var greyscale=dt[12]; }
if(dt[13]){
var backward=dt[13]; }

if(gettingData==0){
dura=start;
durah=Math.floor(dura/(60*60));
duram=Math.floor(  (dura-(durah*60*60)) /60);
duras= dura-(60*60*durah)-(duram*60);
_start=durah+":"+duram+":"+duras;

dura=end;
durah=Math.floor(dura/(60*60));
duram=Math.floor(  (dura-(durah*60*60)) /60);
duras= dura-(60*60*durah)-(duram*60);
_end=durah+":"+duram+":"+duras;

getdata("/scripts/phpstudio/part.php?start="+_start+"&end="+_end+"&nr="+(i+1)+"&maxPart="+maxPart+"&speed="+speed+"&name="+ia+"&fname="+ia+"_"+"&vname="+vnam.replace(" ", "_")+"&vext="+vxt+"&vwidth="+vwidth+"&vheight="+vheight+"&preset="+preset+"&img1="+ia+"&img2="+imgs[1]+"&mute="+mute+"&effect="+effect+"&rotate="+rotate+"&greyscale="+greyscale+"&backward="+backward+"&&rd="+Math.random());
gettingData=1;
currentI = currentI+1;
}


setTimeout("rebuild()",1000);


}



}

function updateIt(ia, the){



start_=document.getElementById('start').value;
end_=document.getElementById('end').value;

star=start_.split(":");
startx= (parseFloat(star[0])*60*60)+(60*parseFloat(star[1]))+parseFloat(star[2]);

enad=end_.split(":");
endx=   (parseFloat(enad[0])*60*60)+(60*parseFloat(enad[1]))+parseFloat(enad[2]);
  var spd = document.getElementById("speed");
  sped = spd.options[spd.selectedIndex].value;
  var fct = document.getElementById("effect");
 var effect = fct.options[fct.selectedIndex].value;
vnam=document.getElementById('vname').value;



var ve=document.getElementById('vext');
var vex = ve.options[ve.selectedIndex].value;

vwdt=document.getElementById('vwidth').value;
vhght=document.getElementById('vheight').value;
prst=document.getElementById('preset').value;
  var rtt = document.getElementById('rotate');
  rotte = rtt.options[rtt.selectedIndex].value;

var mut = "100";
 if(document.getElementById('mute').checked==true){
mut="0";
}
var grscl = "0";
 if(document.getElementById('greyscale').checked==true){
grscl="1";
}


bckwrd = "0";
 if(document.getElementById('backward').checked==true){
bckwrd="1";
}



perItem[the] =  new  Array(ia, start, end, sped, effect, vnam, vex, vwdt, vhght, prst, mut, rotte);

getdataaaf("/scripts/phpstudio/sessi.php?update="+(theIndexSelected+0)+"&data="+(theIndexSelected-1)+";"+ia+";"+startx+";"+endx+";"+sped+";"+effect+";"+vnam+";"+vex+";"+vwdt+";"+vhght+";"+prst+";"+mut+";"+rotte+";"+grscl+";"+bckwrd+";&dataFile=pprojectz.data&ia="+ia+"&strt="+start_+"&startx="+startx+"&r0r="+Math.random());

dd=document.getElementById('settings');
dd.innerHTML="";






}


function pref(ia, the_){

df = the_.split("*");
the= df[0];
dura =df[1];
nro =df[2];

<?php

		$data="<select  id=effect name=effect><option value='80' selected>Select...</option>";

			$fc="";
			$handle = fopen($_SERVER['DOCUMENT_ROOT']."/scripts/php/jip-scripts.php", "r");
			if ($handle) {
				while (($line = fgets($handle)) !== false) {
					$fc.=$line;
				}
			} else {
		
			} 
			$dfg = explode("tr ==", $fc);
			
			$ed = 4 + str_replace("\n", "", file_get_contents("http://".getenv("HTTP_HOST")."/scripts/sync/tff.txt"));


			for($i=1;$i<count($dfg);$i++){
				$next = $dfg[$i];
				$dosc=true;
				$tl=0;
				while($dosc==true){
				$ch=$next[$tl];
				
				if($ch==')'){
				$dosc=false;
				}
				$tl++;
				
				}
				$stt = strpos($next, "scripts/");
				
				$stte = strpos($next, "?");
				$eff=substr($next, ($stt+8), ($stte-$stt-12));
				
				if(strlen($eff)<25){
				
				$data.="<option value='".str_replace(" ", "",substr($next, 1, ($tl-2)))."'>".$eff."</option>";
				}
			}
			
			
			
			
			fclose($handle);
			$data.="</select>";
?>




dd=document.getElementById('settings');

durah=Math.floor(dura/(60*60));
duram=Math.floor(  (dura-(durah*60*60)) /60);
duras= dura-(60*60*durah)-(duram*60);

if(durah<=9){

}

dd.innerHTML="<h4>Settings</h4><button name='remove' onclick=removeIt('"+ia+"','"+the+"')>Delete </button> <button  style='background:blue;color:white' onclick=buildSound('"+ia+"','"+currentI+"')>Sound </button> Start after <input type='text' value='0:0:0' size=5 id=start> End At Sec. <input type='text' size=5 id=end value='"+durah+":"+duram+":"+duras+"'> <select id=speed><option value='.25'>1/4 x Speed</option><option value='.5'>1/2 x Speed</option><option value='1' selected>1/1 x Speed</option><option value='2'>2 x Speed</option><option value='4'>4 x Speed</option></select><br><br>Effect <?php echo $data; ?><input type='checkbox' name=mute id='mute' value='mute'>Mute  <b> Rotate </b><select name='rotate' id=rotate><option value='2'>180 Degrees</option><option value='-1' selected></option><option  value='0'>Left</option><option value='1'>Right</option></select> <input type='checkbox' name=greyscale id=greyscale>Grey Scale   <input type='checkbox' name=backward id=backward>Reverse  <button name='remove' onclick=updateIt('"+ia+"','"+the+"')>Update</button><br>	";



}


function openRecord(){
window.location.href="/index.php?p=Record&nr="+currentI;
return true;
}

function buildSound(ia, the){


start_=document.getElementById('start').value;
end_=document.getElementById('end').value;
star=start_.split(":");
start= ((parseFloat(star[0])*60*60)+(60*parseFloat(star[1]))+parseFloat(star[2]));
enad=end_.split(":");
end=   ((parseFloat(enad[0])*60*60)+(60*parseFloat(enad[1]))+parseFloat(enad[2]));
window.location.href="index.php?theSelectedIndex="+theIndexSelected+"&time="+(end - start  );
}


function openRecordV(){
	window.location.href="index.php?theSelectedIndex=-1&time=-1";
	return true;
}

function stP(){
	getdatat("/data[<?php echo $_SERVER['REMOTE_ADDR']; ?>]/lengthSeconds.txt?p="+Math.random());
	setTimeout("stP()", 5000);
}

function getPosX(el) {
    return el.offsetLeft;
}

function getPosY(el) {
    return el.offsetTop;
}

function getOffset( el ) {
    var _x = 0;
    var _y = 0;
    while( el && !isNaN( el.offsetLeft ) && !isNaN( el.offsetTop ) ) {
        _x += el.offsetLeft - el.scrollLeft;
        _y += el.offsetTop - el.scrollTop;
        el = el.offsetParent;
    }
    return { top: _y, left: _x };
}
var duration_ =1000000;
function stime(){

if(tt>0 && tt< duration_){
duration_=parseFloat(duration);
wwwi= document.getElementById("timespan").offsetWidth;

x=  getOffset( document.getElementById('spp') ).left; 
y=  getOffset( document.getElementById('spp') ).top; 
ct+=(wwwi/duration_);
sp = document.getElementById('spp');




}
tt++;
setTimeout("stime()", 1000);

}


stP();


</script>
