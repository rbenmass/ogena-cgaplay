<?php
set_time_limit(160); 

$dir =getcwd(). "/java";  
set_time_limit(0); 
@copy($_GET['i2'], $_GET['i1_']);
@copy($_GET['i1'], $_GET['i2_']);

 

 
$func="";


$parts=1; 
for($i=0;$i<$parts;$i++){

	
	$func.="".rand(20,70)."*cos(".(1/rand(25, 150))."*(x+".(1/rand(1,50))."))";



if(rand(0,10)>5){

				if(rand(0,10)>=5){
				$func.="+(0.13+x*".(1/rand(1, 12)).")";
			}
			else{
			$func.="-(0.13+x*".(1/rand(1, 12)).")";
			}			

			}
			else{
			
			
							if(rand(0,10)>=5){
				$func.="+(x*x*".(1/rand(300, 600)).")";
			}
			else{
			$func.="-(x*x*".(1/rand(300, 600)).")";
			}	
			
			
			}

	//	}
}

$func.="";


  exec("java -cp \"".$dir."\" ImageFunctionEval  \"".$_GET['i1_']. "\" ". "\"".$_GET['i2_']."\" ".$_GET['frames']." \"".$_GET['fn']."\" \"".$func."\" ". "0 0 ".$_GET['width']." ".$_GET['height']   );


 







?>
