<?php
set_time_limit(160); 

$dir =getcwd(). "/java";  
set_time_limit(0); 
@copy($_GET['i1'], $_GET['i1_']);
@copy($_GET['i2'], $_GET['i2_']);




 



$xw = 4+rand(5,10);
$yh = 4+rand(5,10);


  exec(" java -cp \"".$dir."\" ImageOpening  \"".$_GET['i1_']. "\" ". "\"".$_GET['i2_']."\" ".($_GET['frames'])." \"".$_GET['fn']."\" 0 ". "0 0 ".$_GET['width']." ".$_GET['height']  );








?>
