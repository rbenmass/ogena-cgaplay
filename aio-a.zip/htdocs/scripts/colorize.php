<?php
set_time_limit(160); 

$dir =getcwd(). "/java";  
set_time_limit(0); 
 exec(" java -cp \"".$dir."\" ToolsImage \"".$_GET['i2']. "\" ". "\"".$_GET['i1_']."\"" );
 exec(" java -cp \"".$dir."\" ToolsImage \"".$_GET['i1']. "\" ". "\"".$_GET['i2_']."\"" );





if($_GET["dir"]=="_"){
  exec (" java  -cp \"".$dir."\" ImageColorize \"".$_GET['i1_']. "\" ".$_GET['aantal']." "." \"".$_GET['fn']."\" + 0 1 +  ".$_GET['wi']." ".$_GET['he']. "  + ". 0 );
  exec (" java  -cp \"".$dir."\" ImageColorize \"".$_GET['i2_']. "\" ".$_GET['aantal']." "." \"".$_GET['fn']."\" + 0 1 +  ".$_GET['wi']." ".$_GET['he']. "  - " .$_GET['aantal']);

 
 
 
 }
else
{

 
}








?>
