<?php


$dir =getcwd(). "/java";  
set_time_limit(0); 
copy($_GET['i1'], $_GET['i1_']);

copy($_GET['i2'], $_GET['i2_']);





 exec(" java -Xmx1024m -cp \"".$dir."\" ImageSlide \"".$_GET['i1_']. "\" ". "\"".$_GET['i2_']."\" "."\"".$_GET['fn']."\" 1 1 ".$_GET['aantal']. " ". $_GET['width']. " ".$_GET['height']   );
 exec(" java -Xmx1024m -cp \"".$dir."\" ImageFramesZoom \"".$_GET['fn']. "\" ".$_GET['width']." ".$_GET['height']." \"".$_GET['fn']."\"  ".$_GET['aantal']." - 1 1 1 1 1 1 1 1000 ".$_GET['tr10']." ".$_GET['mtmain']);




?>
