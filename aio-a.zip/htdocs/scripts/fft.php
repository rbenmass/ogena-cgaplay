<?php
set_time_limit(160); 

$dir =getcwd(). "/java";  
set_time_limit(0); 
$_GET['i11_'] = $_GET['i1_'];
@copy($_GET['i1'], $_GET['i1_'].".jpg");
@copy($_GET['i1'], $_GET['i2_'].".jpg");
@copy($_GET['i1'], $_GET['i1__'].".jpg");
@copy($_GET['i1'], $_GET['i2__']);

$_GET['i1_']=$_GET['i1_'].".jpg";
$_GET['i2_']=$_GET['i2_'].".jpg";
$_GET['i1__']=$_GET['i1__'].".jpg";




if($_GET["dir"]=="_"){
  exec(" java -Xmx512m -cp \"".$dir."\" ImageGaussian \"".$_GET['i1_']. "\" 1  \"".$_GET['fn']."_1001.jpg\" "."-"." 0 1 0 ".$_GET['width']. " ".$_GET['height'] ." 2");
 exec(" java -cp \"".$dir."\" ImageGaussian \"".$_GET['i2_']. "\" 1  \"".$_GET['fn']."__1001.jpg\" "."-"." 0 1 0 ".$_GET['width']. " ".$_GET['height'] ." 1");
 
 
 exec(" java -Xmx512m -cp \"".$dir."\" ImageCombine \"".$_GET['fn']. "_1001.jpg\" ". "\"".$_GET['fn']."__1001.jpg\" ".$_GET['aantal']." \"".$_GET['fn']."\" 0 ". "0 0 ".$_GET['width']." ".$_GET['height']   );

  exec(" java -Xmx512m -cp \"".$dir."\" ImageGaussian \"".$_GET['i1_']. "\" 1  \"".$_GET['fn']."___1001.jpg\" "."-"." 0 1 0 ".$_GET['width']. " ".$_GET['height']. " 0");
 
 exec(" java -Xmx512m -cp \"".$dir."\" ImageCombine \"".$_GET['fn']. "___1001.jpg\" ". "\"".$_GET['fn']."__1001.jpg\" ".$_GET['aantal']." \"".$_GET['fn']."\" 1 ".$_GET['aantal']. " 0 ".$_GET['width']." ".$_GET['height']   );
 exec(" java -cp \"".$dir."\" ImageFFT \"".$_GET['i1__']. "\" 1  \"".$_GET['fn'].".1001.jpg\" "."-"." 0 1 0 ".$_GET['width']. " ".$_GET['height'] ." 2");


 
 
 
 //exec(" java -Xmx1024m -cp \"".$dir."\" ImageFramesZoom \"".$_GET['fn']. "\" ".$_GET['width']." ".$_GET['height']." \"".$_GET['fn']."\"  ".($_GET['aantal']*2)." - 1 1 1 1 1 1 1 1000 ".$_GET['tr10']." ".$_GET['mtmain']);

 }







?>
