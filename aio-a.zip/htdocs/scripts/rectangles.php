<?php
set_time_limit(160); 

$dir =getcwd(). "/java";  
set_time_limit(0); 
@copy($_GET['i2'], $_GET['i1_']);
@copy($_GET['i1'], $_GET['i2_']);



 


$o = rand(0,100);
if($o>50){

$path ="";
for($i=0;$i<3;$i++)
{
$inx = rand(0, 150);
$iny = rand(0, 100);

$path = $path. " ".$inx." ".$iny; 

}

$path = $path. " 0  0"; 



}


  exec(" java -cp \"".$dir."\" ImageRectangles  \"".$_GET['i1_']. "\" ". "\"".$_GET['i2_']."\" ".$_GET['frames']." \"".$_GET['fn']."\" 0 ". "0 0 ".$_GET['width']." ".$_GET['height']   );
exec(" java -cp \"".$dir."\" ImageFramesZoom \"".$_GET['fn']. "\" ".$_GET['width']." ".$_GET['height']." \"".$_GET['fn']."\"  ".$_GET['frames']." - 1 1 1 1 1 1 1 1000 ".$_GET['tr10']." ".$_GET['mtmain']);

 







?>
