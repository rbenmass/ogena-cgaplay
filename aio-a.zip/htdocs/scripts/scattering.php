<?php


$dir =getcwd(). "/java";  
set_time_limit(0); 
copy($_GET['i1'], $_GET['i1_']);

copy($_GET['i2'], $_GET['i2_']);





$nrofex = rand(36, 40);
$fn="someGif".$nrofex.".gif";


if($_GET['dir']=="_"){
 exec(" java  -cp \"".$dir."\" ImageExplode \"".$_GET['i1_']. "\" \"".$_GET['i2_']."\" ".$nrofex." ".$_GET['aantal']." \"".$fn."\" "." \"".$_GET['fn']."\"". " - ".$_GET['start']." ".$_GET['width']. " ".$_GET['height']  );


}
else{
 exec(" java  -cp \"".$dir."\" ImageExplode \"".$_GET['i1_']. "\" \"".$_GET['i2_']."\" ".$nrofex." ".$_GET['aantal']." \"".$fn."\" "." \"".$_GET['fn']."\"". "  + ".$_GET['start']." ".$_GET['width']. " ".$_GET['height']  );


}



?>
