<?php
set_time_limit(160); 

$dir =getcwd(). "/java";  
set_time_limit(0); 
 exec(" java -cp \"".$dir."\" ToolsImage \"".$_GET['i1']. "\" ". "\"".$_GET['i1_']."\"" );
 exec(" java -cp \"".$dir."\" ToolsImage \"".$_GET['i2']. "\" ". "\"".$_GET['i2_']."\"" );




for($i=0;$i<=($_GET['aantal']/2);$i++){
 
exec (" java  -cp \"".$dir."\" ImageSaturn \"".$_GET['i1_']. "\" "." \"".$_GET['fn'].".".(1000+$i).".jpg\"  ".$_GET['wi']." ".$_GET['he']. "  ". (2*$_GET['aantal']-(4*$i)) );
}

for($i=($_GET['aantal']/2);$i>=0;$i--){

exec (" java  -cp \"".$dir."\" ImageSaturn \"".$_GET['i2_']. "\" "." \"".$_GET['fn'].".".(($_GET['aantal']/2)+1000+($_GET['aantal']/2)-$i).".jpg\"  ".$_GET['wi']." ".$_GET['he']. "  ". (2*$_GET['aantal']-(4*$i)) );

}






?>

