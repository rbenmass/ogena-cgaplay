<?php
set_time_limit(160); 

$dir =getcwd(). "/java";  
set_time_limit(0); 
@copy($_GET['i2'], $_GET['i1_']);
@copy($_GET['i1'], $_GET['i2_']);
@copy($_GET['i2'], $_GET['i1__']);
@copy($_GET['i1'], $_GET['i2__']);







  exec(" java  -cp \"".$dir."\" ImageGaussian \"".$_GET['i1_']. "\" 1  \"".$_GET['fn']."_\" "."-"." 0 1 0 ".$_GET['width']. " ".$_GET['height']);
  exec(" java  -cp \"".$dir."\" ImageGaussian \"".$_GET['i2_']. "\" 1  \"".$_GET['fn']."__\" "."-"." 0 1 0 ".$_GET['width']. " ".$_GET['height']);
  
 exec(" java  -cp \"".$dir."\" ImageCombine \"".$_GET['i1__']. "\" ". "\"".$_GET['fn']."_.1000.jpg\" ".$_GET['aantal']." \"".$_GET['fn']."\" 0 ". "0 0 ".$_GET['width']." ".$_GET['height']   );

 exec(" java  -cp \"".$dir."\" ImageCombine \"".$_GET['fn']. "__.1000.jpg\" ". "\"".$_GET['i2__']."\" ".$_GET['aantal']." \"".$_GET['fn']."\" 1 ".$_GET['aantal']. " 0 ".$_GET['width']." ".$_GET['height']   );


 

 







?>
