<?php

$dir =getcwd(). "/java";  
copy($_GET['i1'], $_GET['i1_']);

copy($_GET['i2'], $_GET['i2_']);




$o = rand(0,100);
if($o>50){

$path ="";
for($i=0;$i<3;$i++)
{
$inx = rand(0, 150);
$iny = rand(0, 100);

$path = $path. " ".$inx." ".$iny; 

}

$path = $path. " 0  0"; 



}

if($_GET['dir']=="_"){
  exec ("java  -cp \"".$dir."\" ImageToNoise \"".$_GET['i1_']. "\" ".$_GET['aantal']." \"".$_GET['fn']."\" - ".$_GET['start'] ." ".$_GET['width']. " ".$_GET['height']  );
}
else{
  exec("java  -cp \"".$dir."\" ImageToNoise \"".$_GET['i1_']. "\" ".$_GET['aantal']." \"".$_GET['fn']."\" + ".$_GET['start'] ." ".$_GET['width']. " ".$_GET['height']   );



 
}



?>
