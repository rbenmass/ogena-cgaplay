<?php


$dir =getcwd(). "/java";  
set_time_limit(0); 
copy($_GET['i2'], $_GET['i1_']);

copy($_GET['i3'], $_GET['i2_']);

copy($_GET['i1'], $_GET['i3_']);



 exec(" java -cp \"".$dir."\" ImageDrieDWindow \"".$_GET['i1_']. "\" ". "\"".$_GET['i2_']."\" ". "\"".$_GET['i3_']."\" ".($_GET['aantal']-1) ." \"".$_GET['fn']."\"  ". " ". $_GET['width']. " ".$_GET['height']   );
 exec(" java  -cp \"".$dir."\" ImageFramesZoom \"".$_GET['fn']. "\" ".$_GET['width']." ".$_GET['height']." \"".$_GET['fn']."\"  ".$_GET['aantal']." - 1 1 1 1 1 1 1 1000 ".$_GET['tr10']." ".$_GET['mtmain']);




?>
