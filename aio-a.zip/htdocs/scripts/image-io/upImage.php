<?php
		$cho="";
		$ii=0;
		
		$srv = $_GET['src'];
		if(strpos($srv, ".jpg")==false){
		$srv = $srv.".jpg";
		}
		
		$files = scanDir($_SERVER['DOCUMENT_ROOT']."/images/Preview");
		for($i=0;$i<count($files);$i++){
		
			if($files[$i]=="." || $files[$i]==".."){
			}
			else{
				$cho.="/images/Preview/".$files[$i]."#";

				if($srv=="/images/Preview/".$files[$i]){
					$ext = explode("_", $files[$i]);
					$thch = str_replace($ext[2], $_GET['effe'], $files[$i]);
					if(strpos($thch, ".jpg")==false){
							$thch = $thch.".jpg";
					}
					
					rename($_SERVER['DOCUMENT_ROOT']."/images/Preview/".$files[$i], $_SERVER['DOCUMENT_ROOT']."/images/Preview/".$thch);
				}

				if($_GET['index']==$ii){
				//unlink($_SERVER['DOCUMENT_ROOT']."/images/Preview/".$files[$i]);
				}


				$ii++;
			}
		
		}
		if($cho!=""){
		//echo $cho;
		}


?>
