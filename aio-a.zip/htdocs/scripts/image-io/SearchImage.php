<?php







$search_=str_replace(" ", "_", $_GET['search']);

$search= str_replace(" ", "_", $_GET['search']);

	

	

	



$ok=false;







$localr= @scandir("../../images/".str_replace(",", "", str_replace(",", "",str_replace("#", "", str_replace("/", "",str_replace("&", "", str_replace("!", "", str_replace("?", "", str_replace(")", "", str_replace("(", "", str_replace("'", "", str_replace(" ", "_",$search))))))))))));





if(count($localr)>4 || $_GET['search']=="Preview" ){

	if(count($localr)>0){

		for($i=0;$i<count($localr);$i++){

			if($localr[$i]=="." || $localr[$i]==".."){

			}

			else{

				

				

							list($width, $height, $type, $attr) = getimagesize("../../images/".str_replace(",", "", str_replace(",", "",str_replace("#", "", str_replace("/", "",str_replace("&", "", str_replace("!", "", str_replace("?", "", str_replace(")", "", str_replace("(", "", str_replace("'", "", str_replace(" ", "_",$search)))))))))))."/".$localr[$i] );

				

				if($width>0 &&  $height>0){

				$local[]=$localr[$i];

				}

				else{

					unlink("../../images/".str_replace(",", "", str_replace(",", "",str_replace("#", "", str_replace("/", "",str_replace("&", "", str_replace("!", "", str_replace("?", "", str_replace(")", "", str_replace("(", "", str_replace("'", "", str_replace(" ", "_",$search)))))))))))."/".$localr[$i] );

				}

				

				

				

			}



		}



	}

//session_na);

//echo $_SESSION[$_GET['search']];

	

	if($_GET['start']<1 ){

		$_GET['start']=1;

	}

	else{

		$_GET['start']=$_GET['start']+1;

	}



	if($_GET['start'] >= count($local)){



		$ind=$_GET['start']%count($local);

	}

	else{

		$ind=$_GET['start'];

	}



$fecho= "/images/".str_replace("#", "", str_replace(",", "",str_replace("#", "", str_replace("%", "",str_replace("&", "", str_replace("!", "", str_replace("?", "",str_replace(")", "", str_replace("(", "",str_replace("'", "", str_replace(" ", "_", urldecode($_GET['search']))))))))))))."/".$local[$ind];









list($width, $height, $type, $attr) = getimagesize("http://".getenv("HTTP_HOST").$fecho );

				

				if($width>0 &&  $height>0){

echo "http://".getenv("HTTP_HOST").$fecho;

$ok=true;

				}







}

if($ok==false)

{

$fdata=$_SERVER['DOCUMENT_ROOT']."/images/".str_replace(' ','-', $_GET['search'].'.txt');
$f=@file_get_contents($fdata);
if($f==""){

$fout='';

$url="http://www.bing.com/images/search?q=".urlencode($_GET['search'])."&count=100&qft=".urlencode("+filterui:imagesize-large");

$data=file_get_contents($url);



$nextFil="";

$rr=explode("<div class=\"item\">", $data);

$execc="";



$fila=@file_get_contents("image;123;dream;stock;photo");

$fil=explode(";", $fila);



for($r=2;$r<(count($rr)/1);$r++){

		$arf=explode("<a class=\"thumb\" target=\"_blank\" href=\"", $rr[$r]);

	

	

        $nf=explode("\"", $arf[1]);

        $nextFile=$nf[0];

	$nextFil[]=$nextFile;
	$fout=$fout.$nextFile."<br>";



}



$fg=fopen($fdata, 'w');
fwrite($fg, $fout);	
fclose($fg);
}


$f=file_get_contents($fdata);
$nextFi=explode('<br>', $f);

echo $nextFi[rand(0, (count($nextFi)-1))];



}







?>
