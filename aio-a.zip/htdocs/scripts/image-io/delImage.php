<?php
		$cho="";
		$ii=0;
		$files = scanDir($_SERVER['DOCUMENT_ROOT']."/images/Preview");
		for($i=0;$i<count($files);$i++){
		
			if($files[$i]=="." || $files[$i]==".."){
			}
			else{
				$cho.="/images/Preview/".$files[$i]."#";

				if($_GET['index']==$ii){
				unlink($_SERVER['DOCUMENT_ROOT']."/images/Preview/".$files[$i]);
				}


				$ii++;
			}
		
		}
		if($cho!=""){
		//echo $cho;
		}


?>
