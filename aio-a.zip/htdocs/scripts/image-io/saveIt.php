<?php
header('Access-Control-Allow-Origin: *');
set_time_limit(2);
$dir=$_SERVER['DOCUMENT_ROOT']."/scripts/java";
@copy($_GET['src'], $_GET['dest']);

//exec("java -cp \"".$dir."\" ToolsImage ".$_GET['src']. " ".$_GET['dest']. " ".$_GET['width']. " ".$_GET['height']);

?>
