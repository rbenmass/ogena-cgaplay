<?php


@mkdir($_SERVER['DOCUMENT_ROOT']."/images/".str_replace(" ", "_", $_GET['search']));
 
$url="http://www.bing.com/images/search?q=".urlencode($_GET['search'])."&qft=".urlencode("+filterui:imagesize-large");
$data=file_get_contents($url);
$nextFil="";
$rr=explode("<div class=\"item\">", $data);
$execc="";
$fila=file_get_contents("keywords.filter");
$fil=explode(";", $fila);

for($r=2;$r<(count($rr)/1);$r++){
		$arf=explode("<a class=\"thumb\" target=\"_blank\" href=\"", $rr[$r]);
        $nf=explode("\"", $arf[1]);
        $nextFile=$nf[0];
	$nextFil[]=$nextFile;
}
$url="http://www.bing.com/images/search?q=".urlencode($_GET['search'])."&first=".(1+50)."&FORM=HDRSC2";
$data=file_get_contents($url);
$rr=explode("<div class=\"item\">", $data);
$data=file_get_contents($url);
$nextFil="";
$rr=explode("<div class=\"item\">", $data);
$execc="";

for($r=2;$r<(count($rr)/1);$r++){
		$arf=explode("<a class=\"thumb\" target=\"_blank\" href=\"", $rr[$r]);
        $nf=explode("\"", $arf[1]);
        $nextFile=$nf[0];
	echo $nextFile ."*#*";

}
 $uploaddir = $_SERVER['DOCUMENT_ROOT']."/images/Preview/"; 
$ud=scanDir($uploaddir);
 $dd=count($ud);
$nr=11110+$dd-2;
$max=$nr;
 for($j=0;$j<count($ud);$j++){
	
	if($ud[$j]=='.' || $ud[$j]=='..'){
	}
	else {
		$nf=$ud[$j];
		$udd=explode("_", $nf);
		$next = $udd[1];
		if($next>$max){
			$max=$next;
		}
	}
 }
 $max=$max+1;
$nr=$max;

for($t=0;$t<count($nextFil);$t++){
	if($_GET['tr']>=-1){
		$uploadfile = $uploaddir."image_".$nr."_".$_GET['tr'].".jpg";
	}
	else{
$uploadfile = $uploaddir."image_".$nr."_-1.jpg";
	}
copy($nextFil[$t],$uploadfile );
$nr++;
}
?>
