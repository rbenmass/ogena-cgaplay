<?php
if($_GET['search']!=""){
	@mkdir($_SERVER['DOCUMENT_ROOT']."/images/".str_replace(" ", "_", $_GET['search']));
	if(file_exists("/var/wwww")){
		$execr=" php save.php ";
	}
	else{
		$execr="c:/php/php.exe save.php ";
	}
$ppp=0;

	$chs = array();
	
	$hits=0;

	for($j=1;$j<=9;$j++){
	
	$url="http://www.bing.com/images/search?q=".urlencode($_GET['search']." ")."&first=".($j*29)."&count=28";
	$data=file_get_contents($url);

	$nextFil="";
	$rr=explode("<div class=\"item\">", $data);
	$execc="";

	$fila=file_get_contents("image;123;dream;stock;photo");
	$fil=explode(";", $fila);

	
	for($r=2;$r<(count($rr)/1);$r++){
		$arf=explode("<a class=\"thumb\" target=\"_blank\" href=\"", $rr[$r]);	


		$meta=explode("<div class=\"fileInfo\">", $rr[$r]);
		$rechts=$meta[1];
		$dol=explode("jpeg ", $rechts);
		$dl=$dol[1];
		$kb = explode(" kB", $dl);
		$size=$kb[0];

		if($size>=20 & $size <=66 ){

if($hits<=25){
		$nf=explode("\"", $arf[1]);
		$nextFile=$nf[0];
		$ppp=$ppp+1;
		$hits=$hits+1;

		//echo $size."..j:".$j."<BR>";
//		copy($nextFile, $_SERVER['DOCUMENT_ROOT']."/images/".str_replace(" ", "_", $_GET['search'])."/Ima".$ppp.".jpg");
//

		$ssr[]=$nextFile;
		$targets[]=$_SERVER['DOCUMENT_ROOT']."/images/".str_replace(" ", "_", $_GET['search'])."/Ima".$ppp.".jpg";
}
	}

		
		//copy($nextFile, $_SERVER['DOCUMENT_ROOT']."/images/".str_replace(" ", "_", $_GET['search'])."/Ima".$ppp.".jpg");
	}

}

$tc=count($targets);
$chs = array();
$cmh = curl_multi_init();
for ($t = 0; $t < $tc; $t++)
{
    $chs[$t] = curl_init();
    curl_setopt($chs[$t], CURLOPT_URL, $ssr[$t]);
    curl_setopt($chs[$t], CURLOPT_RETURNTRANSFER, 1);
    curl_multi_add_handle($cmh, $chs[$t]);    
}

$running=null;
do {
    curl_multi_exec($cmh, $running);
} while ($running > 0);

for ($t = 0; $t < $tc; $t++)
{
    $path_to_file = $targets[$t];
    file_put_contents($path_to_file, curl_multi_getcontent($chs[$t]));
    curl_multi_remove_handle($cmh, $chs[$t]);
    curl_close($chs[$t]	);
}
curl_multi_close($cmh);

$di=$_SERVER['DOCUMENT_ROOT']."/images/".str_replace(" ", "_", $_GET['search'])."";
$files=scandir($di);
for($i=0;$i<count($files);$i++){
	if($files[$i]=="." || $files[$i]==".."){
	}
	else{
		$size=filesize($di."/".$files[$i]);
		if($size==0){
			unlink($di."/".$files[$i]);
		}	 
	}




}














}

function par($src, $dest){
	$t="ax".rand(0,100000);
	$ex=  "xmlhttp".$t." = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject('Microsoft.XMLHTTP');         xmlhttp".$t.".open('GET', 'http://".getenv("HTTP_HOST")."/scripts/image-io/saveIt.php?src=".$src."&dest=".$dest."');        xmlhttp".$t.".send(null); ";

	$s=str_replace("<", "", $ex);
	$t=str_replace(">", "", $s);
	echo $t;	


}

?>
