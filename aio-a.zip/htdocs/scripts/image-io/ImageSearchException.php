<?php


$search= $_GET['search'];

$f=1;

echo "";
$start=rand(1,5);
$search=$_GET['search'];

$url = "http://ajax.googleapis.com/ajax/services/search/images?" . "v=1.0&imgsz=medium&q=".urlencode($search)."&userip=".rand(10,200).".".rand(10,200).".".rand(10,200).".".rand(10,200)."&rsz=6&start=".$start;



 $body = file_get_contents($url);



$json = json_decode($body, true);

$rr=rand(0,5);
$imurl= $json["responseData"]["results"][$rr]["url"];





echo $imurl;




?>
