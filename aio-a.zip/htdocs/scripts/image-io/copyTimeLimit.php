<?php
ini_set('max_execution_time', 1); 
set_time_limit(1);

@copy($_GET['src'], $_GET['dest']);
?>
