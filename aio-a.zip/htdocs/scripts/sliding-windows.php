<?php
set_time_limit(160); 

$dir =getcwd(). "/java";  
set_time_limit(0); 
@copy($_GET['i2'], $_GET['i1_']);
@copy($_GET['i1'], $_GET['i2_']);



$sm=0;
$fill = "";
if($_GET['imgss']>0){

for($i=0;$i<(0.8*$_GET['imgss']);$i++){


$fill=$fill."\"".$_SERVER['DOCUMENT_ROOT']."/images/summary".$i.".jpg\" "; 

}


}
 



$xw = 4+rand(5,10);
$yh = 4+rand(5,10);


  exec(" java -cp \"".$dir."\" ImageWindowSlide  \"".$_GET['i1_']. "\" ". "\"".$_GET['i2_']."\" ".$_GET['frames']." \"".$_GET['fn']."\" 0 ". "0 0 ".$_GET['width']." ".$_GET['height']. " ".$fill   );








?>
