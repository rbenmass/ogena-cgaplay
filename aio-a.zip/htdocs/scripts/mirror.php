<?php


$dir =getcwd(). "/java";  
set_time_limit(0); 
copy($_GET['i1'], $_GET['i1_']);
copy($_GET['i2'], $_GET['i2_']);
copy($_GET['i1_'], $_GET['i1_'].".jpg");
copy($_GET['i2_'], $_GET['i2_'].".jpg");



$rr=rand(0,2);

 exec  (" java -cp \"".$dir."\" ImageMirror \"".$_GET['i1_']. "\" \"". $_GET['i1_'].".jpg\""." ". $rr );

 exec(" java -cp \"".$dir."\" ImageCombine \"".$_GET['i1_']. "\" ". "\"".$_GET['i1_'].".jpg\" ".$_GET['aantal']." \"".$_GET['fn']."\" 0 ". "0 0 ".$_GET['width']." ".$_GET['height']   );

 exec  (" java -cp \"".$dir."\" ImageMirror \"".$_GET['i2_']. "\" \"". $_GET['i2_'].".jpg\""." ". $rr );

 exec(" java -cp \"".$dir."\" ImageCombine \"".$_GET['i2_']. "\" ". "\"".$_GET['i2_'].".jpg\" ".$_GET['aantal']." \"".$_GET['fn']."\" - ".$_GET['aantal']. " 0 ".$_GET['width']." ".$_GET['height']   );






?>
