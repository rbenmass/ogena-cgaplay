<?php


$dir =getcwd(). "/java";  
set_time_limit(0); 
copy($_GET['i1'], $_GET['i1_']);
copy($_GET['i2'], $_GET['i2_']);
copy($_GET['i3'], $_GET['i3_']);
copy($_GET['i1'], $_GET['i1__']);
copy($_GET['i2'], $_GET['i2__']);
copy($_GET['i3'], $_GET['i3__']);




$rr=rand(0,1);

 exec  (" java -cp \"".$dir."\" ImageRound \"".$_GET['i1_']. "\"  \"".$_GET['i3__']. "\" \"". $_GET['i1__']."\""." ".$_GET['width']." ".$_GET['height']." 0 " );

 exec(" java -cp \"".$dir."\" ImageCombine \"".$_GET['i1_']. "\" ". "\"".$_GET['i1__']."\" ".$_GET['aantal']." \"".$_GET['fn']."\" 0 ". "0 0 ".$_GET['width']." ".$_GET['height']   );

 exec  (" java -cp \"".$dir."\" ImageRound \"".$_GET['i2_']. "\"  \"".$_GET['i3__']. "\" \"". $_GET['i2__']."\""." "." ".$_GET['width']." ".$_GET['height']." 1" );

 exec(" java -cp \"".$dir."\" ImageCombine \"".$_GET['i2_']. "\" ". "\"".$_GET['i2__']."\" ".$_GET['aantal']." \"".$_GET['fn']."\" - ".$_GET['aantal']. " 0 ".$_GET['width']." ".$_GET['height']   );






?>
