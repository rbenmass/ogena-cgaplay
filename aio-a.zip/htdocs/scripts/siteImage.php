<?php

if(file_exists($_SERVER['DOCUMENT_ROOT'].'/'.$_GET['fileName'])){

echo "<img src='http://".getenv("HTTP_HOST")."/".$_GET['fileName']."' width=400 height=400 >";

}
else{

exec("xvfb-run --server-args=\"-screen 0, 1280x1200x24\" cutycapt --url=".$_GET['url']." --out=".$_SERVER['DOCUMENT_ROOT']."/".$_GET['fileName']);
echo "<img src='http://".getenv("HTTP_HOST")."/".$_GET['fileName']."' width=400 height=400 >";

}

?>

