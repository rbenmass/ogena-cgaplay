<?php


$dir =getcwd(). "/java";  
set_time_limit(0); 
@copy($_GET['i1'], $_GET['i3_']);

@copy($_GET['i2'], $_GET['i1_']);

@copy($_GET['i3'], $_GET['i4_']);

@copy($_GET['i4'], $_GET['i2_']);






if($_GET['dir']=="_"){

 exec(" java -cp \"".$dir."\" ImageToSpiral \"".$_GET['i1_']. "\" "." \"".$_GET['i2_']."\""." ". ($_GET['aantal']-1)." \"".$_GET['fn']."\" + ".$_GET['start']." ". $_GET['width']. " ".$_GET['height']   ." & java  -cp \"".$dir."\" ImageToSpiral \"".$_GET['i3_']. "\" "." \"".$_GET['i4_']."\""." ".($_GET['aantal'])." \"".$_GET['fn']."\" - 0 ". $_GET['width']. " ".$_GET['height']   );


 exec("java -cp \"".$dir."\" ImageFramesZoom \"".$_GET['fn']. "\" ".$_GET['width']." ".$_GET['height']." \"".$_GET['fn']."\"  ".($_GET['aantal']*2)." - 1 1 1 1 1 1 1 1000 ".$_GET['tr10']." ".$_GET['mtmain']);

}




?>
