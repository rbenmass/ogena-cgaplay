<?php


$dir =getcwd(). "/java";  
set_time_limit(0); 
 exec(" java -cp \"".$dir."\" ToolsImage \"".$_GET['i2']. "\" ". "\"".$_GET['i1_']."\"" );
 exec(" java -cp \"".$dir."\" ToolsImage \"".$_GET['i1']. "\" ". "\"".$_GET['i2_']."\"" );



 exec  (" java  -cp \"".$dir."\" ImageDifferential \"".$_GET['i1_']. "\" ".($_GET['aantal'])." "." \"".$_GET['gn']."\" + 0 1 +  ".$_GET['width']." ".$_GET['height']. " 1" );

 exec  (" java  -cp \"".$dir."\" ImageDifferential \"".$_GET['i2_']. "\" ".($_GET['aantal'])." "." \"".$_GET['cgn']."\" + 0 1 +  ".$_GET['width']." ".$_GET['height']. " 1" );

exec(" java -cp \"".$dir."\" ImageBlurFromTo \"".$_GET['gn']. "\" ".($_GET['aantal']+4)." "." \"".$_GET['hn']."\" "."+"." 0 0 ".$_GET['width'] . " ".$_GET['height']." 30 30   1 "  );

exec(" java -cp \"".$dir."\" ImageBlurFromTo \"".$_GET['cgn']. "\" ".($_GET['aantal']+4)." "." \"".$_GET['hhn']."\" "."+"." 0 0 ".$_GET['width'] . " ".$_GET['height']." 30 30   1 "  );


  exec (" java  -cp \"".$dir."\" ImageAdd \"".$_GET['hn'].".1001.jpg\" ". "\"".$_GET['i1_']."\" ".$_GET['aantal']." \"".$_GET['fn']."\" 0 ". "0 0 ".$_GET['width']." ".$_GET['height']  . " 1 " );

  exec (" java  -cp \"".$dir."\" ImageAdd \"".$_GET['hhn'].".1001.jpg\" ". "\"".$_GET['i2_']."\" ".$_GET['aantal']." \"".$_GET['fn']."\" 0 ".$_GET['aantal']. " -1 ".$_GET['width']." ".$_GET['height']  . " 1 " );


?>
