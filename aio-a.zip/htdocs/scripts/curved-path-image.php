<?php


$dir =getcwd(). "/java";  

copy($_GET['i1'], $_GET['i1_']);

copy($_GET['i2'], $_GET['i2_']);



$o = rand(0,100);


$path ="";
for($i=0;$i<4;$i++)
{
$inx = rand(1, $_GET['width']);
$iny = rand(1, $_GET['height']);

$path = $path. " ".$inx." ".$iny; 

}

$path = $path. " 0 0"; 



			$xx=rand(1, $_GET['width']);
			$yy = rand(1, $_GET['height']);

 exec(" java -Xmx512m -cp \"".$dir."\" ImageToImageToCenter \"".$_GET['i1_']. "\" ". "\"".$_GET['i2_']."\" ".$_GET['aantal']." \"".$_GET['fn']."\" 0 ". "0 0 ".$_GET['aantal'] . " ".$_GET['width']." ".$_GET['height']." ".$path  );



 exec(" java -Xmx1024m -cp \"".$dir."\" ImageFramesZoom \"".$_GET['fn']. "\" ".$_GET['width']." ".$_GET['height']." \"".$_GET['fn']."\"  ".$_GET['aantal']." - 1 1 1 1 1 1 1 1000 ".$_GET['tr10']." ".$_GET['mtmain']);

?>
