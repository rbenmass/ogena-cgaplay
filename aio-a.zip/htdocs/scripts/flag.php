<?php



 


$dir =getcwd(). "/java";  
set_time_limit(0); 
@copy($_GET['i1'], $_GET['i1_']);

@copy($_GET['i2'], $_GET['i2_']);





$sd=intval($_GET['aantal']*2*4/2);
$exece="";
//for($j=0;$j<(3/4*$sd);$j++){
 $exece=" java  -cp \"".$dir."\" ImageTransform \"".$_GET['i1_']. "\" ".$sd. " ".$_GET['wi']." ".$_GET['he']. " \"".$_GET['fn']."\"  10  10   ";


//}
exec($exece);

?>
