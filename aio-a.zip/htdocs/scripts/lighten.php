<?php
set_time_limit(160); 

$dir =getcwd(). "/java";  
set_time_limit(0); 
copy($_GET['i1'], $_GET['i1_']);
copy($_GET['i2'], $_GET['i2_']);





if($_GET['dr']==0){

if($_GET["dir"]=="_"){
  exec (" java -Xmx1024m -cp \"".$dir."\" ImageLighten \"".$_GET['i1_']. "\" ".($_GET['aantal'])." "." \"".$_GET['fn']."\" + 0 1 +  ".$_GET['wi']." ".$_GET['he']. " 1" );
}
else
{
  exec(" java -Xmx1024m -cp \"".$dir."\" ImageLighten \"".$_GET['i1_']. "\" ".($_GET['aantal'])." "." \"".$_GET['fn']."\" + 0 1 - ".$_GET['wi']." ".$_GET['he']. " ".($_GET['startp']-1));
  
   exec("java  -cp \"".$dir."\" ImageFramesZoom \"".$_GET['fn']. "\" ".$_GET['wi']." ".$_GET['he']." \"".$_GET['fn']."\"  ".($_GET['startp']*2)." - 1 1 1 1 1 1 1 1000 ".$_GET['tr10']." ".$_GET['mtmain']);

  
}

}

if($_GET['dr']==1){

if($_GET["dir"]=="_"){
  exec (" java -Xmx512m -cp \"".$dir."\" ImageLighten \"".$_GET['i1_']. "\" ".($_GET['aantal'])." "." \"".$_GET['fn']."\" - 0 1 +  ".$_GET['wi']." ".$_GET['he']. " 1" );
}
else
{
  exec(" java -Xmx512m -cp \"".$dir."\" ImageLighten \"".$_GET['i1_']. "\" ".($_GET['aantal'])." "." \"".$_GET['fn']."\" - 0 1 - ".$_GET['wi']." ".$_GET['he']. " ".($_GET['startp']-1));
    exec("java  -cp \"".$dir."\" ImageFramesZoom \"".$_GET['fn']. "\" ".$_GET['wi']." ".$_GET['he']." \"".$_GET['fn']."\"  ".($_GET['startp']*2)." - 1 1 1 1 1 1 1 1000 ".$_GET['tr10']." ".$_GET['mtmain']);
 
}

}









?>
