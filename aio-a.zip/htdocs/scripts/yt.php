<?php

                        $di = scandir("/var/www/html/images/clipframes");
                        $cc=count($di);
                        $ro=1;
                        for($i=0;$i<count($di);$i++){
                        $ro++;
                        if($i>100 && $i<500 ){
        copy("/var/www/html/images/clipframes/".$di[$i],"/var/www/html/images/000frames".substr(str_replace(" ", "_", str_replace(":", "_", str_replace(";", "_", $argv[1]))), 0, min(20, strlen($argv[1]))). ".".(100000+$ro+444).".jpg");

                        }



                }

?>
