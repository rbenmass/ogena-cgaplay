<?php

if(!file_exists($_SERVER['DOCUMENT_ROOT']."/frameszoom.txt") ){


$start=rand(800, 1200);
$duration = rand(50,150);

$files=scanDir( $_SERVER['DOCUMENT_ROOT']."/".$_GET['dirClip']);
$nr = count($files);
$orgFps= $nr/$_GET['duration'];
$destFps = $_GET['frameRate'];

for($i=$start; $i<$start+$duration;$i++){
@copy("\"".$_SERVER['DOCUMENT_ROOT']."/".$_GET['dirClip']."/myFrames".(int)($i*$orgFps/$destFps ).".jpg\"", "\"".$_SERVER['DOCUMENT_ROOT']. "/".$_GET['framesName'].($_GET['startFrames']+$i.".jpg\""));
}


if(file_exists("c:\windows")){
@exec("__processRequest00Frames.bat");
@exec("__processRequestSound.bat");
}
else{
@exec($_SERVER['DOCUMENT_ROOT']."/images/frames/__processRequest00Frames.sh");
}

}
else{

exec("echo 1 > ".$_SERVER['DOCUMENT_ROOT']."/frameszoom.txt");
}
?>
true
