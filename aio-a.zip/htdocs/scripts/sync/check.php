<?php

$files=scanDir($_SERVER["DOCUMENT_ROOT"]."/images/frames");
$ok=0;

for($i=0;$i<count($files);$i++){
	$fn = $files[$i];
	if(strlen($fn)>6 ){
		$s = substr($fn, 0, 2);
		if($s=="q0"){
		$ok=1;
		}
	}
}
echo $ok;
?>