<?php
error_reporting(E_ALL ^E_NOTICE);
 function getMp3StreamTitle($steam)
    {
		
		if(count(explode(".pls", $steam))>1 || count(explode(".asx", $steam))>1){
			$urd = file_get_contents($steam);
		if(count(explode(".pls", $steam))>1){
			//echo $urd."<br><br>";
			//die();
		$da=explode("\n", $urd);
			$uk=explode("File1=", $da[1]);
					$steam_url = $uk[1];

		}
		else{
			
		$da=explode("<ref href=\"", $urd);
			$uk=explode("\"", $da[1]);
					$steam_url = $uk[0];
			
		}

		}
		if(count(explode(".m3u", $steam))>1){
			$urd = file_get_contents($steam);

		$da=explode("\n", $urd);
					$steam_url = $da[0];

			
		}
		
		if(isset($_GET['server'])){
			
			echo $steam_url;
			die();
		}
		
		
        $result = false;
        $icy_metaint = -1;
        $needle = 'StreamTitle=';
        $ua = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36';

        $opts = array(
            'http' => array(
                'method' => 'GET',
                'header' => 'Icy-MetaData: 1',
                'user_agent' => $ua
            )
        );

		
     $default = stream_context_set_default($opts);

        $stream = @fopen($steam_url, 'r');

        if($stream && ($meta_data = stream_get_meta_data($stream)) && isset($meta_data['wrapper_data'])){
            foreach ($meta_data['wrapper_data'] as $header){
			//		echo "...".strtolower($header);
                if (strpos(strtolower($header), 'icy-metaint') !== false){
                    $tmp = explode(":", $header);
                    $icy_metaint = trim($tmp[1]);
                    break;
                }
            }
        }
$dat="";
        if($icy_metaint != -1)
        {
            $buffer = stream_get_contents($stream, 300, $icy_metaint);

			$ec=explode("StreamTitle=", $buffer);
			$rr=explode(';', $ec[1]);

		    $r=substr($rr[0], 1);
			$rr=strtolower(substr($r, 0, -1));
			//echo "dddddddd".$rr;
			

			$g = explode("-", $rr);
			$y=0;

				$n0 = explode(" ft", $g[$y]);
				$d0 = $n0[0];
				$n1 = explode("(", $d0);
				$d1=$n1[0];
				$n2 = explode('$', $d1);
				$d2=$n2[0];
				$n3 = explode('@', $d2);
				$d3=$n3[0];
				$n4 = explode('?', $d3);
				$d4=$n4[0];
				$n5= explode('&', $d4);
				$d5=$n5[0];
				$n6= explode('#', $d5);
				$d6=$n6[0];
				$n7= explode('/', $d6);


				$xx0=$n7[0];
						
			$y=1;
		

				
			
				$n0 = explode(" ft", $g[$y]);
				$d0 = $n0[0];
				$n1 = explode("(", $d0);
				$d1=$n1[0];
				$n2 = explode('$', $d1);
				$d2=$n2[0];
				$n3 = explode('@', $d2);
				$d3=$n3[0];
				$n4 = explode('?', $d3);
				$d4=$n4[0];
				$n5= explode('&', $d4);
				$d5=$n5[0];
				$n6= explode('#', $d5);
				$d6=$n6[0];
				$n7= explode('/', $d6);


				$yy0=$n7[0];

			return str_replace("!", " ", str_replace("\"", "", str_replace("'", "" ,str_replace('.', '', $xx0." - ".$yy0))));
			//unlink("streamTitle.txt");a
			//$file=fopen("streamTitle.txt", "w");
			//fwrite($file, $rr);
			//fclose($file);
			
			
			
        }

        if($stream)
            fclose($stream);                

        //return $result;
    }
	
	echo getMp3StreamTitle($_GET['stream']);
?>
