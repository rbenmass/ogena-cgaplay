<?php
set_time_limit(0);

exec($_SERVER['DOCUMENT_ROOT']."/images/build.bat");
exec($_SERVER['DOCUMENT_ROOT']."/images/build.sh");


?>
