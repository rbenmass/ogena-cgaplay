<?php
exec("echo CLS > \"c:/program files/apache software foundation/apache2.2/htdocs/scripts/sync/temp.bat\"");
exec("echo CLS > \"c:/program files/apache software foundation/apache2.2/htdocs/scripts/sync/tempsnd.bat\"");
exec("taskkill /f /im iexplore.exe");
@unlink("c:\Program")
?>
