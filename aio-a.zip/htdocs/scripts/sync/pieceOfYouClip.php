<?php

$start=rand(300, 500);
$duration = rand(50,150);

$files=scanDir( $_SERVER['DOCUMENT_ROOT']."/images/".$_GET['dirClip']);
$nr = count($files);
$orgFps= $nr/$_GET['duration'];
$destFps = $_GET['frameRate'];


for($i=$start; $i<($start+$duration);$i++){
 @copy($_SERVER['DOCUMENT_ROOT']."/images/".$_GET['dirClip']."/myFrames".(int)($i*$orgFps/$destFps ).".jpg", $_SERVER['DOCUMENT_ROOT']. "/".$_GET['framesName'].($_GET['startFrames']+$start+$i).".jpg");
}



?>