<?php
@unlink("../../javaimagephp.jpg");
exec("reset.bat");



?>