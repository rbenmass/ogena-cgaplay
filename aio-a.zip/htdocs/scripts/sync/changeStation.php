<?php


$file=fopen($_SERVER['DOCUMENT_ROOT']."/scripts/sync/temp.bat", "w");
fwrite($file, "taskkill /IM vlc.exe \n
cd \"c:/program files/VideoLan/VLC/\"\n
start /min vlc.exe ".$_GET['station']. "\n");
//fwrite ($file, " del \"".$_SERVER['DOCUMENT_ROOT']."/scripts/sync/temp.bat\""); 
fwrite($file, " echo cls >  \"".$_SERVER['DOCUMENT_ROOT']."/scripts/sync/temp.bat\"");
fclose($file);



 

?>