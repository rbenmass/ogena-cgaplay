<?php
header('Access-Control-Allow-Origin: *');  
error_reporting(E_ALL ^E_NOTICE);
 function getMp3StreamTitleStation($steam)
    {
		return file_get_contents("http://".getenv("HTTP_HOST")."/scripts/sync/streamInfo.php?stream=".$steam."&server=true&v=".rand(10000,999999999));
	}
 function getMp3StreamTitle($steam)
    {
				return file_get_contents("http://".getenv("HTTP_HOST")."/scripts/sync/streamInfo.php?stream=".$steam."&v=".rand(10000,999999999));
    }
echo "Version cgaplay:".file_get_contents("http://".getenv("HTTP_HOST")."/Info/Release");
$url=$_GET['url'];
if($url==""){
$url=$argv[1];
}
if(file_exists("c:/windows")){
}
else{
}

$r=getMp3StreamTitle($_GET['url']);
if(strlen($r)>5){

$fil = fopen("station.txt", "w");
fwrite($fil,  getMp3StreamTitleStation($_GET['url']));
fclose($fil);


$fil = fopen("titler.txt", "w");
fwrite($fil, $r);
fclose($fil);

echo $r;

$fil = fopen("title.txt", "w");
$r=getMp3StreamTitle($_GET['url']);
fwrite($fil, $r);
fclose($fil);

}

?>