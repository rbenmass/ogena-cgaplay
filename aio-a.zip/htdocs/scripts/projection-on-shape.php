<?php


$dir =getcwd(). "/java";  
set_time_limit(0); 
copy($_GET['i2'], $_GET['i1_']);

copy($_GET['i1'], $_GET['i2_']);







 exec(" java  -cp \"".$dir."\" ImageProject \"".$_GET['i1_']. "\" ". "\"".$_GET['i2_']."\" ".$_GET['aantal']." ".$_GET['width']." ".$_GET['height']." \"".$_GET['fn']."\" + 0 0 ".$_GET['projection']  );





?>
