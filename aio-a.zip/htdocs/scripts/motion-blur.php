<?php
set_time_limit(160); 

$dir =getcwd(). "/java";  
set_time_limit(0); 
copy($_GET['i1'], $_GET['i1_']);

copy($_GET['i2'], $_GET['i2_']);







if($_GET["dir"]=="_"){
  exec(" java -cp \"".$dir."\" ImageBlur \"".$_GET['i1_']. "\" ".$_GET['aantal']." "." \"".$_GET['fn']."\" "."+"." 0 0 ".$_GET['wi'] . " ".$_GET['he']." ". $_GET['wix']. " ".$_GET['hex']." 0 & java -cp \"".$dir."\" ImageBlur \"".$_GET['i2_']. "\" ".$_GET['aantal']." "." \"".$_GET['fn']."\" "."-"." 0 0 ".$_GET['wi'] . " ".$_GET['he']." ". $_GET['wix']. " ".$_GET['hex']." ".$_GET['aantal'] ."& ");

  exec(" java -Xmx1024m -cp \"".$dir."\" ImageFramesZoom \"".$_GET['fn']. "\" ".$_GET['wi']." ".$_GET['he']." \"".$_GET['fn']."\"  ".($_GET['aantal']*2)." - 1 1 1 1 1 1 1 1000 ".$_GET['tr10']." ".$_GET['mtmain']);

 }








?>
