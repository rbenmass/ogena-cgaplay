<?php


$dir =getcwd(). "/java";  

set_time_limit(0); 
 exec(" java -cp \"".$dir."\" ToolsImage \"".$_GET['i1']. "\" ". "\"".$_GET['i1_']."\"" );
 exec(" java -cp \"".$dir."\" ToolsImage \"".$_GET['i2']. "\" ". "\"".$_GET['i2_']."\"" );





 exec("java -cp \"".$dir."\" ImageBezierCurveAnimation \"".$_GET['i1_']. "\" ". "\"".$_GET['i2_']."\" "." 12 ".$_GET['width']. " ".$_GET['height'] ." " ."\"".$_GET['fn']."\""." ".$_GET['frames']." ".$_GET['msk']    );




?>
