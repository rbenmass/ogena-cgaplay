<?php
set_time_limit(160); 

$dir =getcwd(). "/java";  
set_time_limit(0); 
@copy($_GET['i2'], $_GET['i2_']);
@copy($_GET['i1'], $_GET['i1_']);



 




  exec("java -cp \"".$dir."\" ImageEar  \"".$_GET['i1_']. "\" ". "\"".$_GET['i2_']."\" "." \"".$_GET['fn']."\" ".$_GET['width']." ".$_GET['height'] ." 1 ".$_GET['aantal']  );







?>
