<?php
set_time_limit(0); 

$dir =getcwd(). "/java";  

copy($_GET['i1'], $_GET['i1_']);

copy($_GET['i2'], $_GET['i2_']);






exec("java  -cp \"".$dir."\" ImageRotate \"".$_GET['i1_']. "\" ".$_GET['aantal']." \"".$_GET['fn']."\" + ". $_GET['width']. " ".$_GET['height']   );




?>
