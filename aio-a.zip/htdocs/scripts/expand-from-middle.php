<?php


$dir =getcwd(). "/java";  
set_time_limit(0); 
 exec(" java -cp \"".$dir."\" ToolsImage \"".$_GET['i1']. "\" ". "\"".$_GET['i1_']."\"" );
 exec(" java -cp \"".$dir."\" ToolsImage \"".$_GET['i2']. "\" ". "\"".$_GET['i2_']."\"" );





$o = rand(0,100);
if($o>50){

$path ="";
for($i=0;$i<3;$i++)
{
$inx = rand(0, 150);
$iny = rand(0, 100);

$path = $path. " ".$inx." ".$iny; 

}

$path = $path. " 0  0"; 


}


$nrofex = rand(40, 80);
$fn="someGif".$nrofex.".gif";

 exec(" java -Xmx1024m -cp \"".$dir."\" ImageGrowSplit \"".$_GET['i1_']. "\" \"".$_GET['i2_']."\" \"".$_GET['fn']."\"" ." ".$_GET['aantal']. " 1 1 1 " .$_GET['aantal']." ".$_GET['width']. " ".$_GET['height'] );


 exec(" java -Xmx1024m -cp \"".$dir."\" ImageFramesZoom \"".$_GET['fn']. "\" ".$_GET['width']." ".$_GET['height']." \"".$_GET['fn']."\"  ".$_GET['aantal']." - 1 1 1 1 1 1 1 1000 ".$_GET['tr10']." ".$_GET['mtmain']);

?>
