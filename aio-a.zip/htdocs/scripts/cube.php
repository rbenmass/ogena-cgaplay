<?php


$dir =getcwd(). "/java";  
set_time_limit(0); 
copy($_GET['i1'], $_GET['i1_']);
copy($_GET['i3'], $_GET['i2_']);
copy($_GET['i2'], $_GET['i3_']);


exec(" java  -cp \"".$dir."\" ImageDrieD \"".$_GET['i1_']. "\" ". "\"".$_GET['i2_']."\" ". "\"".$_GET['i3_']."\" ".$_GET['aantal'] ." \"".$_GET['fn']."\"  ". " ". $_GET['width']. " ".$_GET['height']   );



?>
