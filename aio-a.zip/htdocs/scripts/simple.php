<?php


$dir =getcwd(). "/java";  
set_time_limit(0); 
copy($_GET['i1'], $_GET['i2_']);
copy($_GET['i2'], $_GET['i1_']);








 

$ct= rand(0, 5);

 exec  (" java  -cp \"".$dir."\" ImageBasicMath \"".$_GET['i1_']. "\"  \"".$_GET['i2_']."\"   \"".$_GET['fn']."_.jpg\"  ".$_GET['width']." ".$_GET['height']. " ".$ct );

 exec(" java  -cp \"".$dir."\" ImageCombine \"".$_GET['i1_']. "\" ". "\"".$_GET['fn']."_.jpg\" ".$_GET['aantal']." \"".$_GET['fn']."\" 0 ". "0 0 ".$_GET['width']." ".$_GET['height']   );
 
 exec(" java  -cp \"".$dir."\" ImageCombine \"".$_GET['fn']. "_.jpg\" ". "\"".$_GET['i2_']."\" ".$_GET['aantal']." \"".$_GET['fn']."\" 1 ".$_GET['aantal']. " 0 0 ".$_GET['width']." ".$_GET['height']   );
 

 
 
 
 

?>
