<?php


$dir =getcwd(). "/java";  
set_time_limit(0); 
copy($_GET['i2'], $_GET['i1_']);
copy($_GET['i1'], $_GET['i2_']);
copy($_GET['i1'], $_GET['i2_']."_.jpg");





 exec  (" java -cp \"".$dir."\" ImageInverse \"".$_GET['i1_']. "\" ".(int)(4/2)." "." \"".$_GET['i2_']."\" + 0 1 +  ".$_GET['width']." ".$_GET['height']. " 1" );

 exec(" java -cp \"".$dir."\" ImageCombine \"".$_GET['i1_']. "\" ". "\"".$_GET['i2_']."\" ".intval($_GET['aantal']/2)." \"".$_GET['fn']."\" 0 ". "0 0 ".$_GET['width']." ".$_GET['height']   );

 exec  (" java  -cp \"".$dir."\" ImageInverse \"".$_GET['i2_']. "_.jpg\" ".(int)(4/2)." "." \"".$_GET['i2_']."__.jpg\" + 0 1 +  ".$_GET['width']." ".$_GET['height']. " 1" );
 exec(" java -cp \"".$dir."\" ImageCombine \"".$_GET['i2_']. "_.jpg\" ". "\"".$_GET['i2_']."__.jpg\" ".intval($_GET['aantal']/2)." \"".$_GET['fn']."\" - ".intval($_GET['aantal']/2). " 0 ".$_GET['width']." ".$_GET['height']   );






?>
