<?php


$dir =getcwd(). "/java";  

copy($_GET['i1'], $_GET['i1_']);

copy($_GET['i2'], $_GET['i2_']);









if($_GET['dir']=="_"){
 echo exec ("java -cp \"".$dir."\" ImageMoveToNoise \"".$_GET['i1_']. "\" ".$_GET['aantal']." \"".$_GET['fn']."\" - ".$_GET['start'] ." ".$_GET['width']. " ".$_GET['height']. " ".$_GET['ud']  );
}
else{
 echo exec("java -cp \"".$dir."\" ImageMoveToNoise \"".$_GET['i1_']. "\" ".$_GET['aantal']." \"".$_GET['fn']."\" + ".$_GET['start'] ." ".$_GET['width']. " ".$_GET['height']. " ".$_GET['ud']   );

 }


?>
