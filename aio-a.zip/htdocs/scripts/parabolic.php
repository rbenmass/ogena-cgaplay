<?php


$dir =getcwd(). "/java";  
set_time_limit(0); 
@copy($_GET['i1'], $_GET['i1_']);

@copy($_GET['i2'], $_GET['i2_']);




$o = rand(0,100);


$path ="";
for($i=0;$i<3;$i++)
{
$inx = rand(1, $_GET['width']);
$iny = rand(1, $_GET['height']);

$path = $path. " ".$inx." ".$iny; 

}

$path = $path. " 0 0"; 



			$xx=rand(1, $_GET['width']);
			$yy = rand(1, $_GET['height']);

 exec(" java -cp \"".$dir."\" ImageParabolicCenter \"".$_GET['i1_']. "\" ". "\"".$_GET['i2_']."\" ".$_GET['aantal']." \"".$_GET['fn']."\" 0 ". "0 0 ".$_GET['aantal'] . " ".$_GET['width']." ".$_GET['height'] );


 exec(" java -cp \"".$dir."\" ImageFramesZoom \"".$_GET['fn']. "\" ".$_GET['width']." ".$_GET['height']." \"".$_GET['fn']."\"  ".$_GET['aantal']." - 1 1 1 1 1 1 1 1000 ".$_GET['tr10']." ".$_GET['mtmain']);


?>
