<?php

//echo "Hallo getcwd:".getcwd();
$dir =getcwd(). "/java";  

copy($_GET['i2'], $_GET['i1_']);

copy($_GET['i1'], $_GET['i2_']);





$o = rand(0,100);
if($o>50){

$path ="";
for($i=0;$i<3;$i++)
{
$inx = rand(0, 150);
$iny = rand(0, 100);

$path = $path. " ".$inx." ".$iny; 

}

$path = $path. " 0  0"; 


}



 if($_GET['dir']=="-"){
 exec ("java -Xmx1024m -cp \"".$dir."\" ImageDifuse \"".$_GET['i1_']. "\" ".$_GET['frames']." \"".$_GET['fn']."\" + ".$_GET['width']." ".$_GET['height']  . " 0  & java -Xmx1024m -cp \"".$dir."\" ImageDifuse \"".$_GET['i2_']. "\" ".$_GET['frames']." \"".$_GET['fn']."\" - ".$_GET['width']." ".$_GET['height']  ." ".$_GET['frames']." "  );

  exec(" java -Xmx1024m -cp \"".$dir."\" ImageFramesZoom \"".$_GET['fn']. "\" ".$_GET['width']." ".$_GET['height']." \"".$_GET['fn']."\"  ".$_GET['aantal']." - 1 1 1 1 1 1 1 1000 ".$_GET['tr10']." ".$_GET['mtmain']);

 }
 


?>
