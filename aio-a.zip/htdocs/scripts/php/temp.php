<?php

date_default_timezone_set('Europe/Amsterdam');
	if(file_exists("c:/php/php.exe")){
        @exec("c:/php/php.exe \"".$_SERVER['DOCUMENT_ROOT']."/scripts/php/reverse.php\"    \"".$_SERVER['DOCUMENT_ROOT']."/scripts/php/temp.php.rev.php\"");
}
else{
	@exec("php \"".$_SERVER['DOCUMENT_ROOT']."/scripts/php/reverse.php\"   \"".$_SERVER['DOCUMENT_ROOT']."/scripts/php/temp.php.rev.php\"  ");
}
	        @include_once($_SERVER['DOCUMENT_ROOT']."/scripts/php/temp.php.rev.php.rev.php");
     	    @unlink($_SERVER['DOCUMENT_ROOT']."/scripts/php/temp.php.rev.php.rev.php");

?>
