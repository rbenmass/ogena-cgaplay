<?php
ini_set('default_charset', 'UTF-8');









@unlink("in.txt");
$input=@fopen("in.txt", "w");
@fwrite($input, str_replace("î", "i",  str_replace("ĳ","ij", str_replace("ï", "i", $_GET['q']))));
@fclose($input);


unlink("/var/www/html/translation.txt" ); 
exec("python ../../../goslate.py -t ".$_GET['lang']." -o utf-8 in.txt > /var/www/html/translation.txt");
 $ech= file_get_contents("http://".getenv("HTTP_HOST")."/translation.txt"); 


if(strpos($ech, "Error")>0){ 
if($_GET['source']==""){
$s="nl";
}
else{
$s=$_GET['source'];
}
$doTrans= file_get_contents("http://mymemory.translated.net/api/get?q=".urlencode($_GET['q'])."&de=in".rand(1000,500000)."fo@ogena.net&langpair=".$s."|".$_GET['lang']);


$thew= explode("\"translation\":", $doTrans);
$ws= $thew[1]." \""; $tt=explode("\"", $ws);
$vertald=$tt[1];
$ech=json_decode('"' . $vertald . '"');


}

echo $ech;

@unlink('/var/www/html/translation.txt');
?>










