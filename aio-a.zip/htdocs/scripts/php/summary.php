<?php
set_time_limit(180);
	$_SESSION['drt']=0;
$_SESSION['sawo']=1;
	$ubsq = explode(";", $_GET['p']);
	for($loq=0;$loq<count($ubsq);$loq++){
	$smq=0;
	$imqq= explode(":",$ubsq[$loq] );
	if(count($imqq)>1){
	$immq[]=$imqq[0];
	}
	else{
	$immq[]=$ubsq[$loq];
	}
	}
	$dddg=0;
	$rnf = ($_GET['nrPrevImage']*1.5);
		for($tgq=0;$tgq<$rnf;$tgq++ ){
$gkl=(count($ubsq)-1 );
$somran=rand(0, $gkl); 
$egg= $_SESSION['sawo'];
		$nextImge= file_get_contents('http://' . getenv("HTTP_HOST") . '/scripts/image-io/SearchImage.php?search=' . urlencode($immq[  $somran]) . '&imgsz=large&aantal=2&wd=' . (1024*768) . '&start=' . $egg);
			
			
			
			$rf =	$_SESSION['drt'];
			
							list($width, $height, $type, $attr) = @getimagesize($nextImge);
				if($width>1 && $height>1){
			@copy($nextImge, $_SERVER['DOCUMENT_ROOT']."/images/summary".$rf.".jpg");
			$_SESSION['drt']=$_SESSION['drt']+1;
			$_SESSION['sawo']=$_SESSION['sawo']+2;
			}


		
			
			
			
			
		}
			$_SESSION['drt']=0;
			$_SESSION['sawo']=1;
?>