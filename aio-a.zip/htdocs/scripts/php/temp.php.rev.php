

>?
   }
}	
}		
;" ;4 mifgvi" lsxv        		
;)""\gcg.uug/xmbh/hgkrixh/".]'GLLI_GMVNFXLW'[IVEIVH_$.""\ > 4 lsxv"(xvcv			
	{)vhoau==wi$(ur		
}	        
;)voru$(vhloxu			      
;)"4" ,voru$(vgridu	        	
;)"d" ,"ghmr.vifgfu.ivgfknlx/".]'GLLI_GMVNFXLW'[IVEIVH_$(mvklu = voru$		        
{vhov	 	
}	    		
;)voru$(vhloxu		       		
;)"2" ,voru$(vgridu        			
;)"d" ,"ghmr.vifgfu.ivgfknlx/".]'GLLI_GMVNFXLW'[IVEIVH_$(mvklu = voru$				       
{))"hdlwmrd/:x"(hghrcv_voru(ur	        	
{ vhov                
}                
;vfig=wi$			
;" ;25 mifgvi" lsxv                        
;)""\gcg.uug/xmbh/hgkrixh/".]'GLLI_GMVNFXLW'[IVEIVH_$.""\ > 25 lsxv"(xvcv			
{)vhoau==wi$ && dlm$ > vnrg$(ur                
;vgaWgmviifx$ = dlm$                
;)vgaw$(vnrglgigh = vgaWgmviifx$                
; )"h:r:S w-n-B"(vgaw = vgaw$                

;)aw$(vnrglgigh = vnrg$                
;)"ksk.tbdrkbd/lumR/".)"GHLS_KGGS"(emvgvt."//:kggs"(hgmvgmlx_gvt_voru = aw$                
}                
;)u$(vhloxu ;)vgaWganilu$ ,u$(vgridu                        
;)vgaWvifgfu$ ,"h:r:S w-n-B"(vgaw = vgaWganilu$                        
;)))1+2+2(*)2*21(*)2*03(*)4*51(*1(+01(+vgaWgmviifx$ = vgaWvifgfu$                        
;)vgaw$(vnrglgigh = vgaWgmviifx$                        
; )"h:r:S w-n-B"(vgaw = vgaw$                        
;)"d" ,"ksk.tbdrkbd/lumR/".]'GLLI_GMVNFXLW'[IVEIVH_$(mvklu = u$                        
{ vhov                
}                 
{))"ksk.tbdrkbd/lumR/".]'GLLI_GMVNFXLW'[IVEIVH_$(hghrcv_voru(ur                 
        {vhov	
}	
;" ;25 mifgvi" lsxv		    

;)""\gcg.uug/xmbh/hgkrixh/".]'GLLI_GMVNFXLW'[IVEIVH_$.""\ > 25 lsxv"(xvcv		
;vfig=wi$		
;)u$(vhloxu                
;)vgaWganilu$ ,u$(vgridu                
;)vgaWvifgfu$ ,"h:r:S w-n-B"(vgaw = vgaWganilu$                
;016543+vgaWgmviifx$ = vgaWvifgfu$                
;)vgaw$(vnrglgigh = vgaWgmviifx$                
; )"h:r:S w-n-B"(vgaw = vgaw$                
;)"d" ,"ksk.tbdrkbd/lumR/".]'GLLI_GMVNFXLW'[IVEIVH_$(mvklu=u$                
;)"ksk.tbdrkbd/lumR/".]'GLLI_GMVNFXLW'[IVEIVH_$(pmromf@                
{)vhoau==wi$ && )"vifgfu.ivgfknlx/".]'GLLI_GMVNFXLW'[IVEIVH_$(hghrcv_voru || )"vifgfu.ivgfknlx/".]'GLLI_GMVNFXLW'[IVEIVH_$(hghrcv_voru(ur

}
}	
	
;vfig=wi$		
;" ;6 mifgvi " lsxv		

;)""\gcg.uug/xmbh/hgkrixh/".]'GLLI_GMVNFXLW'[IVEIVH_$.""\ > 6 lsxv"(xvcv		
{)vhoau==wi$ && 1>ghaghmr$(ur	
;)) "ksk.ghmr.vifgfu.ivgfknlx/".)"GHLS_KGGS"(emvgvt."//:kggs"(hgmvgmlx_gvt_voru@ ,"" ,"m\"(vxaokvi_igh@ =ghaghmr$	

{vhov
}
}	
;)voru$(vhloxu        	
;)"1" ,voru$(vgridu        	
;)"d" ,"ghmr.vifgfu.ivgfknlx/".]'GLLI_GMVNFXLW'[IVEIVH_$(mvklu = voru$        	
{vhov	
}	
;)voru$(vhloxu		
;)"1" ,voru$(vgridu		
;)"d" ,"ghmr.vifgfu.ivgfknlx/".]'GLLI_GMVNFXLW'[IVEIVH_$(mvklu = voru$		
{))"hdlwmrd/:x"(hghrcv_voru(ur	

{) vhoau==wi$ && ))"ghmr.vifgfu.ivgfknlx/".]'GLLI_GMVNFXLW'[IVEIVH_$(hghrcv_voru(!(ur

}
	
;" ;35 mifgvi " lsxv	
;vfig=wi$	
;)""\gcg.uug/xmbh/hgkrixh/".]'GLLI_GMVNFXLW'[IVEIVH_$.""\ > 35 lsxv"(xvcv	
{ ))"vifgfu.rtx/".]'GLLI_GMVNFXLW'[IVEIVH_$(hghrcv_voru(ur
;vhoau=wi$
ksk?<