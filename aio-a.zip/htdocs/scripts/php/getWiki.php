<?php
error_reporting(E_ALL ^ E_NOTICE);
$search=strtolower($_GET['search']);







function getDescription($q, $rs, $extt){

	if(false && file_exists("descr.html")){
		$lines="";
		$file_handle = fopen("descr.html", "r");
while (!feof($file_handle)) {
   $line = fgets($file_handle);
   $lines.=$line;
}
fclose($file_handle);
	return $lines;
	}
	else{

	
	$urt = "http://en.wikipedia.org/wiki/".str_replace(" ", "_", urldecode($q));
	$page = @file_get_contents($urt);

	if(strpos($page, "Wikipedia does not have an article with this exact name")>0 ){

	}
	else{

		

	}







	$url2= "http://search.yahoo.com/search?p=".urlencode($q);
	$datah= file_get_contents($url2);


	$ff=false;
	$rr=explode("<div><span", $datah);
	
	
	for($i=1;$i<count($rr);$i++){

	$rrs=strpos($rr[$i], "</span>" );
	$thes="<span ".substr($rr[$i], 0, $rrs)."<span>";
	
	

	
	
	




	if($extt>0){

	//echo sasashi;
	
	if(strpos($thes, "wikipedia")>0 && $ff==false){
	$ff=true;
	$theu= strip_tags($thes);
	

	$datapp = file_get_contents("http://".$theu);
	

		

	$dps=strpos($datapp, "</div>\n</div>\n<p>");

	$datap = substr($datapp, $dps);


	$page=explode("<p>", $datapp);
	$thies= $page[1];
	$the=strip_tags($thies);
	if(strlen($the)>20){
		$ff= @fopen("descr.html", "w");
	@fwrite($ff, str_replace("\"", "'", $the));
	@fclose($ff);
	}
	return $the;
		


	}
	}
	else{
	}
	}

return str_replace("\"", "'", $the);


	}
	
}

echo getDescription($search." site:wikipedia.org", 9, 1 );

?>