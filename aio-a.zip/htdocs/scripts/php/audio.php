<script src="getUserMedia.min.js"> </script>


		<div  id="videorecorder"  '>



	<video id='viredemovideoele' autostart  <?php if($_GET['time']>0){ echo "style='width:1px;height:1px'"; } else{

echo "style='width:200px;height:130px;position:absolute;left:890px;top:130px;z-index:-1'"; 
}
?>
>
</video> 



			<span style="font-size:20px;" id ="countdown"></span>
		</div>

<div  style='position:absolute;left:0px;top:310px'>
		 &nbsp;  &nbsp; <input id="playback" value=" Play " type="button"  <?php if($_GET['time']>0){ echo "style='visibility:hidden'"; } ?> /><br/><br/>
		 &nbsp;  &nbsp; <input id="clearrecording" value=" Clear "  <?php if($_GET['time']>0){ echo "style='visibility:hidden'"; } ?>  type="button"  /><br/><br/>
		 &nbsp;  &nbsp; <input id="startRecrodBut1" value=" Start " type="button"  <?php if($_GET['time']>0){ echo "style='visibility:hidden'"; } ?>  /><br/><br/>
		 &nbsp;  &nbsp; <input id="stopRecBut1" value=" Stop " type="button"  <?php if($_GET['time']>0){ echo "style='visibility:hidden'"; } ?>  />
		 &nbsp;  &nbsp; <input id="uploadrecord" value="Upload" type="button"   <?php if(true ||$_GET['time']>0){ echo "style='visibility:hidden'"; } ?>  />


		</br>
		<p id="status"></p>
		<video id="recordedvideo"  controls style='width:1px;height:1px'></video>
		<audio id="audiored" controls style='width:150px'></audio>
		<a id="downloadurl">..</a>
		<div id="progressNumber" style="font-size:20px;"></div>
		</div>
		
		<script src="/javascripts/whammy.js" type="text/javascript"></script>
		<script src="/javascripts/recorder.js" type="text/javascript"></script>
		<script src="/javascripts/VIRecorder.js" type="text/javascript"></script>

	  	<script type="text/javascript">


        
        var startRecord = document.getElementById("startRecrodBut1");
        var stopRecord  = document.getElementById("stopRecBut1");
		var countdownElement = document.getElementById("countdown");
		var playBackRecord = document.getElementById("playback");
        var discardRecordng  = document.getElementById("clearrecording");
        var uploadrecording  = document.getElementById("uploadrecord");
        var progressNumber  = document.getElementById("progressNumber");
        var inn=false;
       var rrr=false;
		 
		 var virec = new VIRecorder.initVIRecorder(
			 	{   
				 	recorvideodsize : 0.4, // recorded video dimentions are 0.4 times smaller than the original
			      	webpquality 	: 0.8, // chrome and opera support webp imags, this is about the aulity of a frame
			      	framerate 		: 25,  // recording frame rate 
					videotagid 		: "viredemovideoele", 
			      	videoWidth 		: "340",
			      	videoHeight 	: "240",    		
			 	} ,
		 		function(){
				inn=true;
		 			//success callback. this will fire if browsers supports 
		 		},
			    function(err){
			   		//onerror callback, this will fire if browser does not support
			   		console.log(err.code +" , "+err.name);
				}
		 );


		 startRecord.addEventListener("click" , function(){
			rrr=true;	
		        virec.startCapture(); // this will start recording video and the audio 
		        startCountDown(null);
		 });
			    
		 stopRecord.addEventListener("click" , function(){
		 	/*
		 	stops the recording and after recording is finalized oncaptureFinish call back 
		 	will occur
		 	*/
			    virec.stopCapture(oncaptureFinish); 
	     });

	     playBackRecord.addEventListener("click" , function(){
	     	/*
	     	Clientside playback,
	     	*/
             	virec.play();
         });
        
         discardRecordng.addEventListener("click" , function(){
         	/*
         	Clears the current recorded video + audio allowing 
         	another recording to happen
         	*/
            	virec.clearRecording();
         });

         uploadrecording.addEventListener("click" , function(){
         	/*
         	Uploading the content to the server, here I have sliced the blobs into chunk size 
         	of 1048576 bits so that uploading time will reduce.
         	Gmail uses this same technique when we attach some files to a mail, it slize the file 
         	in the client side and then uploads chunk by chunk
         	*/
			
		
			
            fileName = 'BSounf<?php echo $_GET['theSelectedIndex']; ?>.wav';
			
         		var uploadoptions = {
	         			blobchunksize : 40048576, <?php $rnd=rand(100000, 900000); ?>
	         			requestUrl : "php/fileupload.php",
	         			requestParametername : "filename", 
	         			videoname : "video<?php if($_GET['time']<0){ echo ".".$rnd; }  ?>.webm",
	         			audioname :  fileName
         		};
            	virec.uploadData( uploadoptions , function(totalchunks, currentchunk){
            		/*
            		This function will callback during, each successfull upload of a blob
            		so you can use this to show a progress bar or something
            		*/
            		progressNumber.innerHTML = ((currentchunk/totalchunks)*100);
            		console.log(currentchunk +" OF " +totalchunks);
            	});
         });
		

	//------------------------------- few functions that demo, how to play with the api --------------------------

	var countdowntime = <?php echo $_GET['time']; ?>;
	var functioncalltime = 0;

 	function oncaptureFinish(audioblob, videoblob){
		 	
		 		var audiobase64 = window.URL.createObjectURL(audioblob);
		        var videobase64 = window.URL.createObjectURL(videoblob);
		        document.getElementById('audiored').src = audiobase64;
		        document.getElementById('recordedvideo').src = videobase64; 
		        document.getElementById('downloadurl').style.display = '';
		        document.getElementById('downloadurl').href = videobase64;
		        document.getElementById("uploadrecord").click();
			   //alert("End");
	
	}

	function setCountDownTime(time){
/*
		 countdownElement.innerHTML = time;
        if(time == 0){
            return -1;
        }else{
            return 1;
        }
*/
    }

    
    function startCountDown(interval){
/*
        if(interval == null){
            functioncalltime = countdowntime; 
            setCountDownTime(--functioncalltime); 
            var intervalcount = setInterval( function(){ startCountDown(intervalcount);  }, 1000 );
        }else{
           var val = setCountDownTime(--functioncalltime); 
           if(val == -1){
               clearInterval(interval);
               virec.stopCapture(oncaptureFinish);

			   
           }
        }
*/
    }


		</script>
		
			<script type="text/javascript">
			var inp=false;
			var ep=0;
			function ino(){
			if(inn==true && inp==false && rrr==true){
			inp=true;
			document.getElementById("startRecrodBut1").click();
			inn=false;
			
			}
if(inp==true){
ep+=.1;
 countdownElement.innerHTML = ep;

}
			document.title='Recording ... '+ep+' seconds';
			setTimeout("ino()", 100);
			}
			ino();



			</script>
