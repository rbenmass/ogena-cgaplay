<?php

	echo  count(scandir($_SERVER['DOCUMENT_ROOT']."/images"));

?>
