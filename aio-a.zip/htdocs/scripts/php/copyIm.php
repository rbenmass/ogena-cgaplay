<?php

copy($argv[1], $argv[2]);
	list($w, $h)=getimagesize($argv[1]);
	if($w>0 && $h>0){
		copy($argv[1], $argv[2]);
	}

?>
