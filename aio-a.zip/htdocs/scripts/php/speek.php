<?php

$dat= file_get_contents("http://".getenv("HTTP_HOST")."/images/talk/".$_GET['data']);

$tex=explode(".", $dat);






for($i=0;$i<count($tex);$i++){
	@unlink("google".$i.".mp3");
exec("wget -q -U Mozilla -O google".$i.".mp3 \"http://translate.google.com/translate_tts?ie=UTF-8&total=1&idx=0&textlen=32&client=tw-ob&q=".$tex[$i].".&tl=".$_GET['lang']."\"");
}




@unlink("google.mp3");


$gg="";
for($j=0;$j<(count($tex)-1);$j++){

if(filesize("google".$j.".mp3")>20){
$gg=$gg."google".$j.".mp3|";
}

}
$gb=substr($gg, 0, (strlen($gg)-1));

exec("ffmpeg -i \"concat:".$gb."\" google.mp3");



echo "<audio onended='countdown();'  style='visibility:hidden' width=0 height=1  src='/scripts/php/google.mp3?p=".rand(0,10000000)."' autostart=autoplay autoplay=autoplay></audio>";



?>