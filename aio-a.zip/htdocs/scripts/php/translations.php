<?php
function translate($q, $s, $e){

if($s==$e){
return $q;

}


@copy("http://translate.google.com/translate_a/t?client=t&text=%s&hl=en&sl=%s&tl=%s&ie=UTF-8&oe=UTF-8&multires=1&otf=1&pc=1&trs=1&ssel=3&tsel=6&sc=1&q=".urlencode($q)."&langpair=".$s."|".$e, $_SERVER['DOCUMENT_ROOT']."/".$_SERVER['REMOTE_ADDR'].".translation.txt");
$doTrans=file_get_contents("http://".getenv("HTTP_HOST")."/".$_SERVER['REMOTE_ADDR'].".translation.txt");
@unlink($_SERVER['DOCUMENT_ROOT'].'/'.$_SERVER['REMOTE_ADDR'].".translation.txt");
//$doTrans= //file_get_contents("http://api.mymemory.translated.net/get?q=".urlencode($q)."&de=net.ogena@outlook.com&langpair=".$s."|".$e);
 
$thew= explode(",", $doTrans);
$ws= $thew[0]." ";
$tt=explode("\"", $ws);
return $tt[1];







}
?>