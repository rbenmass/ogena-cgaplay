<?php

for($h=$_GET['start']; $h<($_GET['start']+80);$h++){

@copy($_SERVER['DOCUMENT_ROOT']."/temp/iimage".($h-$_GET['start']).".jpg", $_SERVER['DOCUMENT_ROOT']."/".$_GET['fileName'].".".$h.".jpg");

}



?>
