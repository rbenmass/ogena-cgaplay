<?php

	$fname = "image".rand(10000,200000).".jpg";
	
	//Copy Images from Local Directory
	if(is_dir($_GET['source'])){
	
		$files=scanDir($_GET['source']);
		for($i=0;$i<count($files);$i++){
			if($files[$i]=="." || $files[$i]==".."){
			}
			else{
				if(strpos($files[$i], ".JPG") > 0 ||  strpos($files[$i], ".jpg")>0 || strpos($files[$i], ".gif") > 0 ||  strpos($files[$i], ".GIF")>0){
					$fname = "image".rand(10000,200000).".jpg";
						@copy($_GET['source']."/".$files[$i], $_SERVER['DOCUMENT_ROOT']."/images/".$fname);
							echo "http://".getenv("HTTP_HOST")."/images/".$fname."*#*";
						
				}
			}		
		}	
	}
	else{
		//Copy Single Image from Local Path
		if(file_exists($_GET['source'])){
			copy($_GET['source'], $_SERVER['DOCUMENT_ROOT']."/images/".$fname);
			echo "http://".getenv("HTTP_HOST")."/images/".$fname."*#*"."http://".getenv("HTTP_HOST")."/images/".$fname;
		}
		else{
			//URL Image on Web
			if(strpos($_GET['source'], "jpg")>0){
				copy($_GET['source'], $_SERVER['DOCUMENT_ROOT']."/images/".$fname);
				echo "http://".getenv("HTTP_HOST")."/images/".$fname."*#*"."http://".getenv("HTTP_HOST")."/images/".$fname;
			}
			//Lookup for the Image Description on the Web
			else{			
				echo file_get_contents("http://".getenv("HTTP_HOST")."/scripts/image-io/getImg.php?noTbUrl=yes&page=1&search=".urlencode($_GET['source'])."&tr=".$_GET['tr'] );			
			}

		}		
	
	
	
	}
?>
