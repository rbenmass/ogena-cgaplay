<?php


if($_FILES['userfile']['name']){


 $uploaddir = $_SERVER['DOCUMENT_ROOT']."/images/Preview/"; 
$ud=scanDir($uploaddir);
 $dd=count($ud);
$nr=11110+$dd-2;
$max=$nr;
 for($j=0;$j<count($ud);$j++){
	
	if($ud[$j]=='.' || $ud[$j]=='..'){
	}
	else {
		$nf=$ud[$j];
		$udd=explode("_", $nf);
		$next = $udd[1];
		if($next>$max){
			$max=$next;
		}

	}
 }
 $max=$max+1;
$nr=$max;



$uploadfile = str_replace("_", "", $uploaddir . basename($_FILES['userfile']['name']));
//image_11119_-1_.jpg
$uploadfile = $uploaddir."image_".$nr."_".$_POST['tr'].".jpg";

$output=$_FILES['userfile']['name']."\n"; 
//echo '<pre>';
 if (move_uploaded_file($_FILES['userfile']['tmp_name'], $uploadfile)) {
    chmod($uploadfile, 0777);
echo "";
include_once($_SERVER['DOCUMENT_ROOT'].'/html-scripts/upload.html');

}
else{
echo "Fout;";
}

}
else{

echo "Error";
}
?>
