<?php
date_default_timezone_set('Europe/Amsterdam');
	function changePosition($xy, $pos){
		$x= substr($xy, $pos, 1);
		
	
	$abc="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	$_ab="abcdefghijklmnopqrstuvwxyz";
	$xx0=$x;

	if(strpos($abc, $x)!=false){
		$xx0 = $abc[(25-strpos($abc, $x))];
	
	}
      if(strpos($_ab, $x)!=false){
                $xx0 = $_ab[(25-strpos($_ab, $x))];

        }
	
$xy[$pos]=$xx0;
return $xy;	

	}

	$file=$argv[1];
	if($file==""){
		$file = $_GET['file'];
	}
	
	
	$handle = fopen($file, "r");
	$data="";
	if ($handle) {
	    while (($line = fgets($handle)) !== false) {
        	// process the line read.
		$data=$data.$line;
    		}

	    fclose($handle);
	} else {
	    // error opening the file.

	}
	$reversed="";
	for($i=strlen($data);$i>0;$i--){
		$reversed.= substr($data, ($i-1), 1 );
	} 

	for($i=0;$i<strlen($reversed);$i++){
		$reversed = changePosition($reversed, $i);
	}


	$f= fopen($file.".rev.php", "w");
	fwrite($f, $reversed);
	fclose($f);



?>
