<?php
error_reporting(E_ALL ^ E_NOTICE);
$ch = curl_init('http://www.findsounds.com/ISAPI/search.dll');
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($_GET));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1); 
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$response = curl_exec($ch);

$r=explode("<TABLE>", $response);
//echo $r[2];

$end = explode("</TABLE>", $r[2]);
//echo $end[0];

$items = explode("hit", $end[0]);


 


if($_GET['number']>0){
$nr= $_GET['number'];
}
else{
$nr=4;
}
$k=1;
if($_GET['list']=="yes"){
for($il=1;$il<10;$il++){
$i=$items[$il];
$is=explode(",", $i); 
$ir= (float)str_replace("\"", "", substr($is[(count($is)-1)], 0, (strlen($is[(count($is)-1)])-2)));

$rr= str_replace("\n", "", str_replace("\"", "", $is[4]));
$qr=explode("\n", $rr);
if($ir>0 && $k<= $nr){

$exx=explode(".", $qr[0]);
$ex=$exx[(count($exx)-1)];

if( !($ex=="aiff" || $ex=="aif"  )){

echo $qr[0]."<br>"; 
$k++;
}

}

}


}
else{
$i=$items[rand(1, 9)];
$is=explode(",", $i); 
$rr= str_replace("\n", "", str_replace("\"", "", $is[4]));
$qr=explode("\n", $rr);
echo $qr[0];
}


?>