<?php
/*
	Author: Ridouan Ben Massoud
	File: scripts.php 
	Description: Files manages the amination of calling php functions
	Domain: Hosted at ogena.net
	Date: 9-11-2013
*/
?>
<?php
error_reporting(E_ALL ^E_NOTICE);

if($_GET['stream']!=''){

file_get_contents("http://".getenv("HTTP_HOST")."/scripts/stream.php?url=".urlencode($_GET['stream']));

}

    $ip = "";
	$_GET['reed']="";
$host = getenv("HTTP_HOST");
include_once($_SERVER['DOCUMENT_ROOT']."/scripts/php/effects.php"); 

function fil($val){
set_time_limit(2);
//@file_get_contents("http://ogena.net/passTitle.php?title=".urlencode($val));

}

$startt = microtime(true);

$pppp = $_GET['p'];

function printTitle($val){

$titf= @fopen($_SERVER['DOCUMENT_ROOT'].'/scripts/sync/mptitle.txt', 'w');
@fwrite($titf, $val);
@fclose($titf);

$titf= @fopen($_SERVER['DOCUMENT_ROOT'].'/scripts/sync/mptitle', 'w');
@fwrite($titf, str_replace("0%", "", $_GET['prgrss'])." ".$val);
@fclose($titf);

//fil($val);
$titf= @fopen($_SERVER['DOCUMENT_ROOT'].'/scripts/sync/mptitle.log', 'w');
@fwrite($titf, $_GET['source']);
@fclose($titf);

}
function parseSettings($wrd) {
        $eee=explode("!", $wrd);
        if(count($eee)<2){
                $ar[0]=$wrd;
                $ar[1]=-1;
                $ar[2]=-1;
                $ar[3]= 1;
                return $ar;
        }
        $dp  = strpos($wrd, "!");
        $effecti=-1;
        $durationn=1;
        $dp10 = strpos($wrd, "!");
        $dp20 = strpos($wrd, "@");
        if($dp>0){
                $wordd = substr($wrd, 0, $dp);
        }
        else{
                $dp  = strpos($wrd, "@");
                $wordd = substr($wrd, 0, $dp);
        }
        $rest= substr($wrd, ($dp+1), (strlen($wrd )-$dp ));
        $dpx  = strpos($wrd, "!");
        $items = explode(",", $rest);
        if(count($items)>1){
                $effecti= $items[0];
                $durationn= $items[1];
        }
        else{
                if($dpx>0){
                        $effecti= $items[0];
                }
                if(!($dpx>0)){
                        $durationn= $items[0];
                }
        }
        if(!($dp10>0 || $dp20>0)) {
        $resqa[0]=$wrd;
        }
        else {
        $resqa[0]=$wordd;
        }
        $resqa[1]=$effecti;
        $itm = explode(",", $resqa[1]);
        $rrp= str_replace(" ", "_", $resqa[0]);
        if($_SESSION[$rrp]>=0){
        $tt=$_SESSION[$rrp]%count($itm);
        $resqa[1] = $itm[$tt];
        }
        else{
                $tt=0%count($itm);
        $resqa[1] = $itm[$tt];
        }
        $drat = explode("*", $resqa[1]);
        if(count($drat)>1){
                $resqa[1]=$drat[0];
                $resqa[3]=$drat[1];
        }
        else{
        $resqa[3]=1;
        }

        if(strtolower($resqa[1]=="random" ) || strtolower($resqa[1]=="shuffle" )){
        $resqa[1] = 10*rand(1,$nrTrans);
        }
        else{
        $fo=$resqa[1];
        $resqa[1] = getEffectNumber($fo);
        }
        if($durationn>0){
        $resqa[2]= $durationn;
        }
        else{
        $resqa[2]=1;
        }
return $resqa;
}




 
function playSound($nr, $offset)
{
    $off = "";
    if ($offset > 0) {
        $off = "?offset=" . $offset;
    }
    $pge = file_get_contents("http://www.grsites.com/archive/sounds/category/" . $nr . "/" . $off);
    $i   = explode("<br>&nbsp;<br>&nbsp;<br>", $pge);
    $j   = rand(1, (count($i) - 1));
    if ($j < count($i)) {
        $link = $i[$j];
        $k    = explode("<a href=\"http://static", $link);
        if (count($k) > 1) {
		
            $m     = $k[rand(1, (count($k)-1)) ];
            $n     = explode(">MP3", $m);
            $kjp   = explode("</a", $link);
            $ur    = $kjp[0];
            $nm    = explode("<", $ur);
            $nl    = $nm[0];
            $echoo = str_replace("<a href=\"", "", $kjp[0]);
            $rd    = explode("Download as: ", $echoo);
            $stt   = $rd[1];
            $dsf   = str_replace(">WAV", "", $stt);
            $dsf0  = str_replace("\"", "", $dsf);
            $dsf00 = substr($dsf, 0, (strlen($dsf) - 1));
            echo "<embed width=0 volume=10  height=0 src='" . $dsf00 . "'></embed>";
        }
    }
}
if ($tlllp < 1) {
    $tlllp = 1;
}
function getOperatingSystem()
{
    $os_string = php_uname('s');
    if (strpos(strtoupper($os_string), 'WIN') !== false) {
        return 'win';
    } else {
        return 'linux';
    }
}
set_time_limit(0);
if (getOperatingSystem() == "win") {
    $copy = "copy";
} else {
    $copy = "cp";
}
$kng  = 0;
$gets = $_GET['p'];
ini_set("display_errors", 1);
$lang        = $_GET['lang'];
$hNrOfFrames = intval($_GET['frames'] / 2);
$nrOfFrames  = $_GET['frames'];

$nrOfFramesWait = 5*$nrOfFrames;

if($_GET['b']!=""){

}
else{
$nrOfFramesWait = 2;
}

?>
<?php
$iy = rand(0, 10000);
?>
<?php
function url_exists($url)
{

    list($width, $height) = getimagesize($url);
    if ($width * $height > (100 * 100)) {
        return true;
    } else {
        return false;
    }
}
function url_exists2($url)
{
    list($width, $height) = getimagesize($url);
    if ($width * $height > (100 * 100)) {
        return true;
    } else {
        return false;
    }
}
function get_domain($hostname)
{
    $afterh = substr($hostname, 7);
    $fs     = strpos($afterh, "/");
    $url    = substr($hostname, 0, 7 + $fs);
    return $url;
}
?>
<?php


$prevvimg="x"; 
$_GET['reed']="";

$cmmd="";


$ff=fopen($_SERVER['DOCUMENT_ROOT']."/a.txt", "w");
fwrite($ff, $_SERVER['REQUEST_URI']);
fclose($ff);

    $star = rand(0, 100);
    session_name('s');
    @session_start();
    if (isset($_SESSION['prank'])) {
    } else {
        $_SESSION['prank'] = 0;
    }
	    if (isset($_SESSION['nrOffSummaryImg'])) {
    } else {
        $_SESSION['nrOffSummaryImg'] = $_GET['nrOffSummaryImg'];
    }
	
	
	
	    if (isset($_SESSION['mtmain'])) {
    } else {
        $_SESSION['mtmain'] = 0;
    }
	
	
    if (isset($_SESSION['newcount'])) {
    } else {
        $_SESSION['newcount'] = 0;
    }
	
	    if (isset($_SESSION['nnewcount'])) {
    } else {
        $_SESSION['nnewcount'] = 0;
    }
	
	
    if (isset($_SESSION['lightend'])) {
        $_SESSION['lightend'] += 1;
    } else {
        $_SESSION['lightend'] = 0;
    }
    if (isset($_SESSION['pframe'])) {
    } else {
        $_SESSION['pframe'] = 10000;
    }
	
	    if (isset($_SESSION['mainorder'])) {
    } else {
        $_SESSION['mainorder'] = 0;
    }
	
		    if (isset($_SESSION['starti'])) {
    } else {
        $_SESSION['starti'] = 0;
    }
	
	
    if (isset($_SESSION['prankc'])) {
    } else {
        $_SESSION['prankc'] = 2;
    }
	
		
    if (isset($_SESSION['dr'])) {
    } else {
        $_SESSION['dr'] = 1;
    }
	
	
	
    if (isset($_SESSION['tlllp'])) {
    } else {
        $_SESSION['tlllp']   = 1;
        $_SESSION['started'] = "";
    }
    if ($_GET['width'] > 0) {
        $wv  = $_GET['width'];
        $hv  = $_GET['height'];
        $wvl = $_GET['width'];
        $hvl = $_GET['height'];
    } else {
        $wv             = 512;
        $hv             = 386;
        $wvl            = 512;
        $hvl            = 386;
        $_GET['width']  = 512;
        $_GET['height'] = 386;
    }
    if (isset($_SESSION['peffect'])) {

    } else {
        $starrt                 = intval(rand(0, 300));
        $_SESSION['peffect']    = 20;
        $trr                     = 0;
        $_SESSION['projection'] = 0;
        $_SESSION['maskid']     = 0;
    }
	$hosting = "ogena.net";
	$lookup= "keyCheck.php";
	
	
	$lUG = 0+$_GET['free'];	
	$max= (10*52);
    if ($_SESSION['peffect'] >= $max) {
        $_SESSION['peffect'] = 0;
		 $_SESSION['starti'] =  $_SESSION['starti'] +2;
    }
    if (isset($_SESSION['pef'])) {
        $_SESSION['pef'] = $_SESSION['pef'] + 1;
    } else {
        $_SESSION['pef'] = 0;
    }
	
	
	
	
	
	
		if(isset($_SESSION['outip'])){
	}
	else{
	$_SESSION['outip']="";
	$_SESSION['outip'].= $_SERVER['REMOTE_ADDR']; 
	}
	

	
	
    if (isset($_SESSION['totfrm'])) {
    } else {
        $_SESSION['totfrm'] = 1;
    }
    if (isset($_SESSION['ddir'])) {
    } else {
        $_SESSION['ddir'] = 0;
    }
    $splitdata = explode(';', $gets);
    $nr        = 0;
    for ($i = 0; $i < count($splitdata); $i++) {
        $value = $splitdata[$i];
        $nr++;
    }
    if ($_SESSION['pef'] >= $nr) {
        $_SESSION['pef'] = 0;

		
    }
    $trreff         = $_SESSION['peffect'];
    $star      = $_SESSION['prank'];
    $lists     = urldecode($gets);
    $splitdata = explode(';', $lists);
    $nr        = 0;
    $rl_       = "";
    $rl2_      = "";


    if ($wv <= 1024) {
        $size    = "xlarge";
        $aantall = 1;
    }
    if ($wv <= 512) {
        $size    = "large";
        $aantall = 1;
    }
    if ($wv <= 256) {
        $size    = "medium";
        $aantall = 1;
    }
    $widthheight = 2 * intval($wv) * intval($hv);
    $rg0         = explode(";", $pppp);

    $aanta       = count($rg0);
    $trreff         = 0;
    if ($aanta > 0) {
		$inffni = str_replace(";", ", ", $gets);




	$lennn=-1;
	

	$solo=false;

	$hasmore=true;
	$clt=0;
	$lennn=2;


$_SESSION['lennn']=1;
$_SESSION['finito']=false;


$_SESSION['hasmore']=true;

	for($go=0;$go<=(($aanta-1)*2) ;$go++){







	
	


	
	if($_SESSION['hasmore']==true){

	$_SESSION['clt']=round($go/2);




	$_SESSION['cltp']=$_SESSION['clt'];
	$_SESSION['cltpp']=$_SESSION['clt'];


	$wrdoi = $rg0[$_SESSION['cltp']];
	$wrdot = $rg0[$_SESSION['cltpp']];

	

	$psoi =  parseSettings($wrdoi);
	$psot =  parseSettings($wrdot);


        $nrOfFrames*=$psot[3];
        $hNrOfFrames*=$psot[3];



	$search = $psot[0];
	$fcvl = $psot[1];
	$trreff=-1;
	if($fcvl>=0 ){	
	$trreff = $fcvl;
	}


	$_SESSION['lennn']=($_SESSION['lennn']+$psot[2]);	
	
	$_SESSION['lennn2']=$_SESSION['lennn']/2;
	$_SESSION['nnewcount2']=$_SESSION['nnewcount'];
	


	}
	if($_SESSION['lennn2'] >$_SESSION['nnewcount']){
	
$_SESSION['hasmore']=false;


	}
	else{
	



	}


	



	}



	







$seaf="";
$seat="";
 $iets="";
for($ggp=0;$ggp<$aanta;$ggp++){
	        $searchppp = $rg0[$ggp];


$ps = parseSettings($searchppp);

$searchpp = $ps[0];
		

		
$searw	 =str_replace(" ", "_", $searchpp );

if( $_GET['p']!="Cloudsia"){
$_SESSION[$searw]=0;

if(!file_exists($_SERVER['DOCUMENT_ROOT'] . "/images/" . str_replace(" ", "_", $searchpp  ))){
	$seat=$seat."#".$searchpp;
	$_SESSION[$searw]=0;
 
	//echo " ".file_get_contents("http://".getenv("HTTP_HOST")."/scripts/image-io/getImage.php?imgsz=".$_GET['imgsz']."&all=1&offset=3&remote_addr=".$_GET['remote_addr']."&imgnr=".$_GET['imgnr']."&search=" . urlencode($searchpp) . "&filter=watermark&number=6&start=1&download=no&name=dfima&imgsz=" . $size . "&wd=" . $widthheight."&width=".$wv."&height=".$hv."&t=".rand(0,2000000));	




echo file_get_contents("http://".getenv("HTTP_HOST") ."/scripts/image-io/getImage.php?imgsz=".$_GET['imgsz']."&imgnr=".$_GET['imgnr']."&search=" . urlencode($searchpp) . "&filter=watermark&number=6&start=1&download=no&name=dfima&imgsz=" . $size . "&wd=" . $widthheight."&width=".$wv."&height=".$hv);


	  
		
	}
	}
	

}









}



if($_SESSION['hasmore']==true){

        $se= $rg0[($_SESSION['tlllp'] % $aanta)];

$psxu = parseSettings($se);
$search = $psxu[0];



        $nrOfFrames*=$psxu[3];
        $hNrOfFrames*=$psxu[3];



if($psxu[1]>=0){
$trreff  = $psxu[1];
}
else{
}


}



    
	


    if ($gets == "Cloudsia" || $search == "MediaPlayer") {
	
	
		
		if(!isset($_SESSION['ssome'])){
		$_SESSION['ssome']="";
		}
				if(!isset($_SESSION['ssome2'])){
		$_SESSION['ssome2']="";
		}
		
		if( !isset($_SESSION['ssomee'])){
		$_SESSION['ssomee']=2;
		}
		


    $dwsx= @file_get_contents("http://" . getenv("HTTP_HOST") . "/scripts/sync/titler.txt");


$dws = str_replace("'", " ", str_replace("&", " ", str_replace(".", " ", str_replace("!", "i", str_replace("(", " " ,str_replace(")", " ", $dwsx))))));



        $art     = explode(" - ", $dwsx);
		



		
		
        $artist  = $art[0];
        $songtit = $art[1];
		
		/*
		if(strpos($artist, "(")>0 && strpos($artist, ")")>0){
		$artist = substr($artist, 0, strpos($artist, "("));
		
		}
		
				
		if(strpos($songtit, "(")>0 && strpos($songtit, ")")>0){
		$songtit = substr($songtit, 0, strpos($songtit, "("));
		
		}
		*/
		$inffni= $artist." - ".$songtit ." - Jip | MediaPlayer";
		$supersome=	str_replace(".", "",str_replace("&", "", str_replace('$', "", str_replace(",", '',str_replace(" ", "", ($artist.$songtit))))));
		$supersome2=	str_replace(".", "",str_replace("&", "", str_replace('$', "", str_replace(",", '',str_replace(" ", "", ($songtit.$artist))))));

		
		
			if($_GET['ifId']!=""){
			//file_get_contents('http://ogena.net/passTitle.php?client='.$_GET['ifId'].'&title='.urlencode($inffni));
			}
		
		if(isset($_SESSION['ssome']) ){ } else {
		}	
		if($_SESSION['ssome']!=$supersome && $supersome!="" && ( ($_SESSION['ssomee']%2)==0)){
		$_SESSION['ssome']=$supersome;
		$_SESSION['doTrr']=$artist;
		
		}
		
		if($_SESSION['ssome2']!=$supersome2 && $supersome2!="" && (($_SESSION['ssomee']%2)==1)){
		$_SESSION['ssome2']=$supersome2;
		$_SESSION['doTrr']=$songtit;
		
		}
		$_SESSION['ssomee']=$_SESSION['ssomee']+1;
		


    } else {
    }

	
			
	

    $_SESSION['tlllp']  = $_SESSION['tlllp'] + 1;
    $_SESSION['prankc'] = $_SESSION['prankc'] + 1;

if( !($gets=="Cloudsia" || $search=="MediaPlayer")){



         

    $search_ = str_replace(" ", "_", $search);

	if($_SESSION['xx'.$search_]<1){
$_SESSION['xx'.$search_]=2;
	}


	
    $imurl = @file_get_contents('http://' . $host . '/scripts/image-io/SearchImage.php?search=' . urlencode($search) . '&imgsz=' . $size . '&aantal=2&wd=' . $widthheight . '&start=' . $_SESSION['xx'.$search_]);
    $iz1=0;

	
	while($imurl=="" && $iz1<3){
	$imurl = @file_get_contents('http://' . $host . '/scripts/image-io/SearchImage.php?search=' . urlencode($search) . '&imgsz=' . $size . '&aantal=2&wd=' . $widthheight . '&start=' . $_SESSION['xx'.$search_]);
    $iz1++;
	$_SESSION['xx'.$search_]=$_SESSION['xx'.$search_]+1;
	
	}
	if(isset($_SESSION['xx'.$search_])){ $_SESSION['xx'.$search_]=$_SESSION['xx'.$search_]+1; }

	$imurl2 = @file_get_contents('http://' . $host . '/scripts/image-io/SearchImage.php?search=' . urlencode($search) . '&imgsz=' . $size . '&aantal=2&wd=' . $widthheight . '&start=' . $_SESSION['xx'.$search_]);
    $iz2=0;
	while($imurl2=="" && $iz2<3){
	$imurl2 = @file_get_contents('http://' . $host . '/scripts/image-io/SearchImage.php?search=' . urlencode($search) . '&imgsz=' . $size . '&aantal=2&wd=' . $widthheight . '&start=' . $_SESSION['xx'.$search_]);
    $iz2++;
	$_SESSION['xx'.$search_]=$_SESSION['xx'.$search_]+1;
	
	}
		if(isset($_SESSION['xx'.$search_])){ $_SESSION['xx'.$search_]=$_SESSION['xx'.$search_]+1; }
	
	$imurl3 = @file_get_contents('http://' . $host . '/scripts/image-io/SearchImage.php?search=' . urlencode($search) . '&imgsz=' . $size . '&aantal=2&wd=' . $widthheight . '&start=' . $_SESSION['xx'.$search_]);
    $iz3=0;
	while($imurl3=="" && $iz3<3){
	$imurl3 = @file_get_contents('http://' . $host . '/scripts/image-io/SearchImage.php?search=' . urlencode($search) . '&imgsz=' . $size . '&aantal=2&wd=' . $widthheight . '&start=' . $_SESSION['xx'.$search_]);
    $iz3++;
	
	}
	
 $_SESSION['xx'.$search_]=$_SESSION['xx'.$search_]-1;


 
}
	else{

	
	
	
	
		

	 $dwsx   = @file_get_contents("http://" . getenv("HTTP_HOST") . "/scripts/sync/titler.txt");



//$dws = str_replace("'", " ", str_replace("&", " ", str_replace(".", " ", str_replace("!", "i", str_replace("(", " " ,str_replace(")", " ", $dwsx))))));


        $art     = explode(" - ", $dwsx);






        $artist  = $art[0];
        $songtit = $art[1];



		
				if(strpos($artist, "(")>0 && strpos($artist, ")")>0){
		//$artist = substr($artist, 0, strpos($artist, "("));
		
		}
		
				
		if(strpos($songtit, "(")>0 && strpos($songtit, ")")>0){
		//$songtit = substr($songtit, 0, strpos($songtit, "("));
		
		}
		
		if(count(explode(" ", $artist) )>8 || $artist=="" ||  count(explode(" ", $songtit) )>8 || $songtit==""){
		//$artist=$_SESSION['artist'];
		//$songtit=$_SESSION['songtit'];
		
		

		
		
		
		
		}
		else{
		//$_SESSION['artist'] = $artist;
		//$_SESSION['songtit']=$songtit;
		}
		

					    $s4      = str_replace("(", "", $songtit);
    $s5      = str_replace(")", "", $s4);
    $s6     = str_replace("?", "", $s5);
    $s7      = str_replace("&", "", $s6);
    $s8      = str_replace("'", "", $s7);
    $s9      = str_replace(".", "", $s8);
    $s10     = str_replace(" ", "_", $s9);
    $search_ = $s10;
	
	
						    $s4      = str_replace("(", "", $artist);
    $s5      = str_replace(")", "", $s4);
    $s6     = str_replace("?", "", $s5);
    $s7      = str_replace("&", "", $s6);
    $s8      = str_replace("'", "", $s7);
    $s9      = str_replace(".", "", $s8);
    $s10     = str_replace(" ", "_", $s9);
    $search__ = $s10;

			if(!(file_exists($_SERVER['DOCUMENT_ROOT']."/images/".$search_) && file_exists($_SERVER['DOCUMENT_ROOT']."/images/".$search__) )){


echo file_get_contents("http://".getenv("HTTP_HOST") ."/scripts/image-io/getImage.php?imgsz=".$_GET['imgsz']."&imgnr=".$_GET['imgnr']."&search=" . urlencode($songtit) . "&filter=watermark&number=6&start=1&download=no&name=dfima&imgsz=" . $size . "&wd=" . $widthheight."&width=".$wv."&height=".$hv);


echo file_get_contents("http://".getenv("HTTP_HOST") ."/scripts/image-io/getImage.php?imgsz=".$_GET['imgsz']."&imgnr=".$_GET['imgnr']."&search=" . urlencode($artist) . "&filter=watermark&number=6&start=1&download=no&name=dfima&imgsz=" . $size . "&wd=" . $widthheight."&width=".$wv."&height=".$hv);


	  



}


		
        if (($_SESSION['tlllp'] % 2) ==1) {
            $search = $artist;
        } else {
            $search = $songtit;
        }
   

//	if($_SESSION['latsest']==""){
	if($search!=""){

$_SESSION['latsest']=$search;
}

//}
	
	
$search_ = str_replace(" ", "_", $search);	

/*

            $imurl     = file_get_contents('http://' . $host . '/scripts/image-io/SearchImage.php?search=' . urlencode($search) . '&imgsz=' . $size . '&aantal=1&wd=' . $widthheight . '&start=' . $_SESSION[$search_]);
	    $imurl2    = file_get_contents('http://' . $host . '/scripts/image-io/SearchImage.php?search=' . urlencode($search) . '&imgsz=' . $size . '&aantal=1&wd=' . $widthheight . '&start=' . ($_SESSION[$search_]+1));
	    $imurl3    = file_get_contents('http://' . $host . '/scripts/image-io/SearchImage.php?search=' . urlencode($search) . '&imgsz=' . $size . '&aantal=1&wd=' . $widthheight . '&start=' . ($_SESSION[$search_]+2));

*/








//$search=$_SESSION['latsest'];


    $search_ = str_replace(" ", "_", $search);



        if($_SESSION['xx'.$search_]>0){
}
else{
$_SESSION['xx'.$search_]=2;

//file_get_contents("http://".getenv("HTTP_HOST")."/scripts/image-io/getImage.php?imgsz=".$_GET['imgsz']."&imgnr=".$_GET['imgnr']."&search=" . urlencode($songtit) . "&filter=watermark&number=6&start=1&download=no&name=dfima&imgsz=" . $size . "&wd=" . $widthheight."&offset=2&&width=".$wv."&height=".$hv."&t=".rand(0,2000000));
//file_get_contents("http://".getenv("HTTP_HOST")."/scripts/image-io/getImage.php?imgsz=".$_GET['imgsz']."&remote_addr=".$_GET['remote_addr']."&imgnr=".$_GET['imgnr']."&search=" . urlencode($artist)."&offset=2&width=".$wv."&height=".$hv."&t=".rand(0,2000000));






//echo "<iframe style='visibility:hidden;width:0;height:0' src='http://".getenv("HTTP_HOST") ."/scripts/image-io/getImage.php?imgsz=".$_GET['imgsz']."&imgnr=".$_GET['imgnr']."&search=" . urlencode($artist) . "&filter=watermark&number=6&start=1&download=no&name=dfima&imgsz=" . $size . "&wd=" . $widthheight."&width=".$wv."&height=".$hv."'>No supported Iframes".rand(100,400)."</iframe>";

//echo "<iframe style='visibility:hidden;width:0;height:0' src='http://".getenv("HTTP_HOST") ."/scripts/image-io/getImage.php?imgsz=".$_GET['imgsz']."&imgnr=".$_GET['imgnr']."&search=" . urlencode($songtit) . "&filter=watermark&number=6&start=1&download=no&name=dfima&imgsz=" . $size . "&wd=" . $widthheight."&width=".$wv."&height=".$hv."'>No supported Iframes".rand(100,400)."</iframe>";





        }




    $imurl = @file_get_contents('http://' . $host . '/scripts/image-io/SearchImage.php?search=' . urlencode($search) . '&imgsz=' . $size . '&aantal=2&wd=' . $widthheight . '&start=' . $_SESSION['xx'.$search_]);
    $iz1=0;
	if(strlen($imurl)>10){
		
		$_SESSION['last']=$search;
	}
	else{
		$search = $_SESSION['last'];
	}




        while($imurl=="" && $iz1<3){
        $imurl = @file_get_contents('http://' . $host . '/scripts/image-io/SearchImage.php?search=' . urlencode($search) . '&imgsz=' . $size . '&aantal=2&wd=' . $widthheight . '&start=' . $_SESSION['xx'.$search_]);
    $iz1++;
        $_SESSION['xx'.$search_]=$_SESSION['xx'.$search_]+1;

        }
        if(isset($_SESSION['xx'.$search_])){ $_SESSION['xx'.$search_]=$_SESSION['xx'.$search_]+1; }

        $imurl2 = @file_get_contents('http://' . $host . '/scripts/image-io/SearchImage.php?search=' . urlencode($search) . '&imgsz=' . $size . '&aantal=2&wd=' . $widthheight . '&start=' . $_SESSION['xx'.$search_]);
    $iz2=0;
        while($imurl2=="" && $iz2<3){
        $imurl2 = @file_get_contents('http://' . $host . '/scripts/image-io/SearchImage.php?search=' . urlencode($search) . '&imgsz=' . $size . '&aantal=2&wd=' . $widthheight . '&start=' . $_SESSION['xx'.$search_]);
    $iz2++;
        $_SESSION['xx'.$search_]=$_SESSION['xx'.$search_]+1;

        }
                if(isset($_SESSION['xx'.$search_])){ $_SESSION['xx'.$search_]=$_SESSION['xx'.$search_]+1; }

        $imurl3 = @file_get_contents('http://' . $host . '/scripts/image-io/SearchImage.php?search=' . urlencode($search) . '&imgsz=' . $size . '&aantal=2&wd=' . $widthheight . '&start=' . $_SESSION['xx'.$search_]);
    $iz3=0;
        while($imurl3=="" && $iz3<3){
        $imurl3 = @file_get_contents('http://' . $host . '/scripts/image-io/SearchImage.php?search=' . urlencode($search) . '&imgsz=' . $size . '&aantal=2&wd=' . $widthheight . '&start=' . $_SESSION['xx'.$search_]);
    $iz3++;

        }

 $_SESSION['xx'.$search_]=$_SESSION['xx'.$search_]-1;





					
		
	$_SESSION[$search_]=$_SESSION[$search_]+1;
		}	



    if (isset($_SESSION['oldimg'])) {
       
		$imurl = $_SESSION['oldimg'];
		$_SESSION['oldimg']=$imurl2;
    }
	else{
	 $_SESSION['oldimg']=$imurl2;
	}
    $file = @fopen($_SERVER['DOCUMENT_ROOT'] . "/scripts/image-io/log/lastimages.html", "a");
    @fwrite($file, "file:(" . $_SESSION[$search] . ")" . $imurl . "<BR>\n");
    @fclose($file);
    

	
	
	
	if(isset($_SESSION['prankc'])){	$_SESSION['prankc'] = $_SESSION['prankc'] + 1; }


    if ($imurl == "") {

         $imurl    = file_get_contents('http://' . $host . '/scripts/image-io/ImageSearchException.php?search='.urlencode($search));


    }
    if ($imurl2 == "") {
        $imurl2    = file_get_contents('http://' . $host . '/scripts/image-io/ImageSearchException.php?search='.urlencode($search));


    }


    $aa = rand(2, 6);
    $_SESSION['prank'] += 1;
    set_time_limit(0);

		
        if($_GET['pp']=="Preview" ){



        $imurl = "http://".getenv("HTTP_HOST") ."/images/Preview/Image1.jpg";

 $imurl2 = "http://".getenv("HTTP_HOST") ."/images/Preview/Image2.jpg";


        }
else{
	
	
	
	        if($_GET['p']=="Preview"){

        $theim = explode("_", $imurl);
        $trreff=$theim[2];

        }

/*
	
if($_GET['ar']="yes"){	
	$imgname1="aaaabcimage.".rand(1000000, 9000000).".jpg";
	file_get_contents("http://".getenv("HTTP_HOST")."/scripts/php/setImageSize.php?imurl=".$imurl."&fileName=".$imgname1."&width=".$wvl."&r=".$_GET['_br']."&g=".$_GET['_bg']."&b=".$_GET['_bb']."&height=".$hvl);
	$imgname2="abcxximage.".rand(1000000, 9000000).".jpg";
	file_get_contents("http://".getenv("HTTP_HOST")."/scripts/php/setImageSize.php?imurl=".$imurl2."&fileName=".$imgname2."&width=".$wvl."&r=".$_GET['_br']."&g=".$_GET['_bg']."&b=".$_GET['_bb']."&height=".$hvl);
	$imgname3="abcimage.".rand(1000000, 9000000).".jpg";
	file_get_contents("http://".getenv("HTTP_HOST")."/scripts/php/setImageSize.php?imurl=".$imurl3."&fileName=".$imgname3."&width=".$wvl."&r=".$_GET['_br']."&g=".$_GET['_bg']."&b=".$_GET['_bb']."&height=".$hvl);

	$imurl = "http://".getenv("HTTP_HOST") ."/images/".$imgname1;
	$imurl2 = "http://".getenv("HTTP_HOST"). "/images/".$imgname2;
	$imurl3 = "http://".getenv("HTTP_HOST"). "/images/".$imgname3;
}

	
	*/
	
	if(isset($_SESSION['nrOffSummaryImgc'])){
	}
	else{
		$_SESSION['nrOffSummaryImgc']=0;
	}
	
/*
	@copy($imurl, $_SERVER['DOCUMENT_ROOT']."/images/summary".($_SESSION['nrOffSummaryImgc']%$_SESSION['nrOffSummaryImg']).".jpg");
	$_SESSION['nrOffSummaryImgc']=$_SESSION['nrOffSummaryImgc']+1;
	@copy($imurl2, $_SERVER['DOCUMENT_ROOT']."/images/summary".($_SESSION['nrOffSummaryImgc']%$_SESSION['nrOffSummaryImg']).".jpg");
	$_SESSION['nrOffSummaryImgc']=$_SESSION['nrOffSummaryImgc']+1;
	@copy($imur3, $_SERVER['DOCUMENT_ROOT']."/images/summary".($_SESSION['nrOffSummaryImgc']%$_SESSION['nrOffSummaryImg']).".jpg");
	$_SESSION['nrOffSummaryImgc']=$_SESSION['nrOffSummaryImgc']+1;
*/	
}


	if(isset($_GET['fft'])){

	if($_GET['fft']>0) { $trreff  = 0; }
	}
		
$_SESSION['peffect'] = $_SESSION['peffect'] + 10;	 
if(  $trreff  >0)
{

$tr = $trreff;

}
else{

$tr = $_SESSION['peffect'];


}



	
	
	$mtmain=$_SESSION['mtmain'];
	
	
	
	$mypp=$_GET['p'];
	

$mypp =str_replace(" ", "_", $mypp);

	
	


if ($tr == 200) {
        $aa = rand(2, 6);
       
            $Content = @file_get_contents("http://" . $host . "/scripts/letters-or-icon.php?i1=" . $imurl2 . "&doTr=".urlencode($_SESSION['doTrr'])."&start=" . $hNrOfFrames . "&dir=_&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p6." . rand(0, 10000000) . $mypp . ".jpg") . "&i2=" . $imurl . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/y6." . rand(0, 10000000). $mypp . ".jpg") . "&width=" . $wvl . "&height=" . $hvl . "&aantal=" . $hNrOfFrames . "&frames=" . $nrOfFrames . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));
            $aantalecho = $Content;
			$_SESSION['doTrr']="";	
       
		}

	    if ($tr == 520) {
        $aa = rand(2, 6);
        if ($mypp == "WebShop" || $mypp != "" || $mypp == "Services" || isset($_GET['animate'])) {
            $Content    = @file_get_contents("http://" . $host . "/scripts/move-to.php?i1=" . $imurl . "&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p4." . rand(0, 1000) . $mypp . ".jpg") . "&i2=" . $imurl2 . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p5." . rand(0, 1000) . $mypp . ".jpg") . "&width=" . $wvl . "&height=" . $hvl . "&aantal=" . $aa . "&frames=" . $nrOfFrames . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));
            $aantalecho = $Content;
        }
    }
	
	
    if ($tr == 490) {
        $aa = rand(2, 6);
        if ($mypp == "WebShop" || $mypp != "" || $mypp == "Services" || isset($_GET['animate'])) {
            $acht       = rand(0, 1000000);
            $Content    = @file_get_contents("http://" . $host . "/scripts/circles.php?i1=" . $imurl . "&startp=0&dir=_&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p8." . $acht . $mypp . ".jpg") . "&i2=" . $imurl . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p9." . $acht . $mypp . ".jpg") . "&width=40&height=40&wi=" . $wvl . "&he=" . $hvl . "&aantal=" . ($hNrOfFrames) . "&frames=" . $nrOfFrames . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));
            $Content    = @file_get_contents("http://" . $host . "/scripts/circles.php?i1=" . $imurl2 . "&startp=" . ($hNrOfFrames) . "&dir=-&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p9." . $acht . $mypp . ".jpg") . "&i2=" . $imurl2 . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p10." . rand(0, 1000000) . $mypp . ".jpg") . "&width=40&height=40&wi=" . $wvl . "&he=" . $hvl . "&aantal=" . ($hNrOfFrames) . "&frames=" . $nrOfFrames . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));
            $aantalecho = $Content;
        }
    }
    if ($tr == 20) {
        $smooth = true;
        $aa     = rand(2, 6);

            $smthh   = rand(0, 1000000);
            $Content = @file_get_contents("http://" . $host . "/scripts/completing-round.php?i1=" . $imurl2 . "&start=" . $hNrOfFrames . "&dir=_&mtmain=".$mtmain."&tr10=".intval($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/q6." . rand(0, 10000000) . $mypp . ".jpg") . "&i2=" . $imurl . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/r6." . rand(0, 10000000). $mypp . ".jpg") . "&width=" . $wvl . "&height=" . $hvl . "&aantal=" . $nrOfFrames . "&frames=" . $nrOfFrames . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));

        
    }
	
	  if ($tr == 220) {
        $smooth = true;
        $aa     = rand(2, 6);

            $smthh   = rand(0, 1000000);
            $Content = @file_get_contents("http://" . $host . "/scripts/move-to-corner.php?i1=" . $imurl2 . "&start=" . $hNrOfFrames . "&dir=_&mtmain=".$mtmain."&tr10=".intval($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/q6." . rand(0, 10000000) . $mypp . ".jpg") . "&i2=" . $imurl . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/r6." . rand(0, 10000000). $mypp . ".jpg") . "&width=" . $wvl . "&height=" . $hvl . "&aantal=" . $nrOfFrames . "&frames=" . $nrOfFrames . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));

        
    }
    if ($tr == 310) {
        $aa = rand(2, 6);
        if ($mypp == "WebShop" || $mypp != "" || $mypp == "Services" || isset($_GET['animate'])) {
        }
        $Content    = @file_get_contents("http://" . $host . "/scripts/scattering.php?i1=" . $imurl . "&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p0." . $ip . rand(0, 100000) . ".jpg") . "&i2=" . $imurl2 . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p1." . $ip . rand(0, 100000) . ".jpg") . "&width=" . $wv . "&height=" . $hv . "&aantal=" . $nrOfFrames . "&dir=1&start=0&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));
        $aantalecho = $Content;
    }
    if ($tr == 420) {
        if ($mypp == "WebShop" || $mypp != "" || $mypp == "Services" || isset($_GET['animate'])) {
            set_time_limit(0);
            $g3        = -1;
            $Content = @file_get_contents("http://" . $host . "/scripts/opening-object.php?i1=" . $imurl2 . "&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/tu." . $ip . rand(1000, 1000000) . ".jpg") . "&i2=" . $imurl . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/dv." . $ip . rand(1000, 1000000) . ".jpg") . "&width=" . $wv . "&start=0&height=" . $hv . "&frames=" . $nrOfFrames . "&dir=1&start=0&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp) . "&msk=" . $g3);
        }
    }
    if ($tr == 280) {
        $Content = @file_get_contents("http://" . $host . "/scripts/fold.php?i1=" . $imurl . "&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . rand(0, 1000000) . $ip . "." . $mypp . "_.jpg") . "&i2=" . $imurl2 . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . rand(0, 1000000) . $ip . "." . $mypp . "__.jpg") . "&aantal=" . ($nrOfFrames+5) . "&width=" . $wv . "&height=" . $hv . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));
    }
    if ($tr == 270) {
        $Content = @file_get_contents("http://" . $host . "/scripts/disolve.php?i1=" . $imurl2 . "&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . rand(1, 1000000) . $mypp . "_.jpg") . "&i2=" . $imurl . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . rand(0, 10000000) . "." . $mypp . "__.jpg") . "&aantal=" . ($nrOfFrames + 1) . "&width=" . $wv . "&height=" . $hv . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));
    }
    if ($tr == 10) {
        $Content = @file_get_contents("http://" . $host . "/scripts/standard.php?i1=" . $imurl . "&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp . "_.jpg") . "&i2=" . $imurl2 . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp . "__.jpg") . "&aantal=" . ($nrOfFrames + 1) . "&width=" . $wv . "&height=" . $hv . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));
    }
    if ($tr == 400) {
        $Content = @file_get_contents("http://" . $host . "/scripts/colorize.php?i1=" . $imurl2 . "&startp=1&dir=_&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pd." . rand(0, 100000) . $mypp . ".jpg") . "&i2=" . $imurl . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pe." . rand(0, 100000) . $mypp . ".jpg") . "&width=60&height=60&wi=" . $wv . "&he=" . $hv . "&aantal=" . ($hNrOfFrames + 3) . "&frames=" . ($hNrOfFrames + 3) . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));
    }
	    if ($tr == 290) {
        $Content = @file_get_contents("http://" . $host . "/scripts/image-function-eval.php?i1=" . $imurl2 . "&start=" . $hNrOfFrames . "&dir=_&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p6." . rand(0, 10000000) . $mypp . ".jpg") . "&i2=" . $imurl . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/y6." . rand(0, 10000000). $mypp . ".jpg") . "&width=" . $wvl . "&height=" . $hvl . "&aantal=" . $hNrOfFrames . "&frames=" . $nrOfFrames . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));
    }
	
	
    if ($tr == 480) {
        $aa                 = rand(2, 6);
        $masks              = @scandir("scripts/mask");
        $masksc             = count($masks) - 3;
        $kng                = intval($_SESSION['maskid']) % $masksc;
        $Content           = @file_get_contents("http://" . $host . "/scripts/opening-object.php?i1=" . $imurl2 . "&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pu." . $ip . rand(1000, 1000000) . ".jpg") . "&i2=" . $imurl . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pv." . rand(1000, 1000000) . $ip . ".jpg") . "&width=" . $wv . "&start=0&height=" . $hv . "&frames=" . $nrOfFrames . "&dir=1&start=0&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp) . "&msk=" . $kng);
        $_SESSION['maskid'] = $_SESSION['maskid'] + 1;
    }
    if ($tr == 330) {
        $smooth = true;
        $aa     = rand(2, 6);
        if ($mypp == "WebShop" || $mypp != "" || $mypp == "Services" || isset($_GET['animate'])) {
            $smthh   = rand(0, 1000000);
            $Content = @file_get_contents("http://" . $host . "/scripts/frequency.php?i1=" . $imurl2 . "&start=" . $hNrOfFrames . "&dir=_&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p6." . rand(0, 10000000) . $mypp . ".jpg") . "&i2__=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p6." . rand(0, 10000000) . $mypp . ".jpg") . "&mtmain=".$mtmain."&tr10=".($tr/10)."&i1__=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p6." . rand(0, 10000000) . $mypp . ".jpg") . "&i2=" . $imurl . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/y6." . rand(0, 10000000). $mypp . ".jpg") . "&width=" . $wv . "&height=" . $hv . "&aantal=" . $hNrOfFrames . "&frames=" . $nrOfFrames . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));

        }
    }
	
	    if ($tr == 370) {
        $aa = rand(2, 6);
        if ($mypp == "WebShop" || $mypp != "" || $mypp == "Services" || isset($_GET['animate'])) {
            $Content = @file_get_contents("http://" . $host . "/scripts/inverse.php?i1=" . $imurl2 . "&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . rand(0, 100000) . $ip . "." . $mypp . "_.jpg") . "&i2=" . $imurl . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . rand(0, 100000) . $ip . "." . $mypp . "__.jpg") . "&aantal=" . ($nrOfFrames+4) . "&width=" . $wv . "&height=" . $hv . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));
        }
    }
	
    if ($tr == 440) {
        $aa         = rand(2, 6);
        $Content    = @file_get_contents("http://" . $host . "/scripts/glue.php?i1=" . $imurl2 . "&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . rand(0, 10000) . $ip . "." . $mypp . "_.jpg") . "&i2=" . $imurl . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . rand(0, 100000) . "." . $mypp . "__.jpg") . "&gn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/zimages0." . $ip . rand(0, 100000) . "." . $mypp . "__.jpg") . "&cgn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/zimages0." . $ip . rand(0, 100000) . "." . $mypp . "__.jpg") . "&hn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . rand(0, 1000) . "." . $mypp . "___") . "&hhn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . rand(0, 1000) . "." . $mypp . "___") . "&aantal=" . $hNrOfFrames . "&width=" . $wv . "&height=" . $hv . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));
        $aantalecho = $Content;
    }
    if ($tr == 380) {
        $aa = rand(2, 6);
        if ($mypp == "WebShop" || $mypp != "" || $mypp == "Services" || isset($_GET['animate'])) {
        }
        $Content    = @file_get_contents("http://" . $host . "/scripts/differential.php?i1=" . $imurl2 . "&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . rand(1, 10000000) . "." . $mypp . "_.jpg") . "&i2=" . $imurl . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . rand(0, 10000000) . $ip . "." . $mypp . "__.jpg") . "&aantal=" . $nrOfFrames . "&width=" . $wv . "&height=" . $hv . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));
        $aantalecho = $Content;
    }
	
	    if ($tr == 450) {
        $aa = rand(2, 6);
        if ($mypp == "WebShop" || $mypp != "" || $mypp == "Services" || isset($_GET['animate'])) {
        }
        $Content    = @file_get_contents("http://" . $host . "/scripts/mirror.php?i1=" . $imurl . "&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . rand(1, 10000000) . "." . $mypp . "_.jpg") . "&i2=" . $imurl2 . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . rand(0, 10000000) . $ip . "." . $mypp . "__.jpg") . "&aantal=" . $hNrOfFrames . "&width=" . $wv . "&height=" . $hv . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));
        $aantalecho = $Content;
    }

	    if ($tr == 460) {
        $aa = rand(2, 6);
        if ($mypp == "WebShop" || $mypp != "" || $mypp == "Services" || isset($_GET['animate'])) {
        }
        $Content    = @file_get_contents("http://" . $host . "/scripts/wings.php?i3=" . $imurl3 . "&mtmain=".$mtmain."&tr10=".
		($tr/10)."&i3__=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . rand(1, 10000000) . "." . $mypp . "_.jpg").
		"&i3_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . rand(1, 10000000) . "." . $mypp . "_.jpg").
		"&i1=" . $imurl . "&mtmain=".$mtmain."&tr10=".($tr/10).
		"&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . rand(1, 10000000) . "." . $mypp . "_.jpg") .
		"&i1__=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . rand(1, 10000000) . "." . $mypp . "_.jpg") . 
		"&i2=" . $imurl2 .
		"&i3__=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . rand(0, 10000000) . $ip . "." . $mypp . "__.jpg").
		"&i2__=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . rand(0, 10000000) . $ip . "." . $mypp . "__.jpg") .
		"&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . rand(0, 10000000) . $ip . "." . $mypp . "__.jpg") .
		"&aantal=" . $hNrOfFrames . "&width=" . $wv . "&height=" . $hv . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));
        $aantalecho = $Content;
    }

	
	 if ($tr == 30) {
        $aa = rand(2, 6);
        if ($mypp == "WebShop" || $mypp != "" || $mypp == "Services" || isset($_GET['animate'])) {
        }
        $Content    = @file_get_contents("http://" . $host . "/scripts/simple.php?i1=" . $imurl2 . "&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . rand(1, 10000000) . "." . $mypp . "_.jpg") . "&i2=" . $imurl . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . rand(0, 10000000) . $ip . "." . $mypp . "__.jpg") . "&aantal=" . $hNrOfFrames . "&width=" . $wv . "&height=" . $hv . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));
        $aantalecho = $Content;
    }
	
    if ($tr == 170) {
        $aa = rand(2, 6);
        if ($mypp == "WebShop" || $mypp != "" || $mypp == "Services" || isset($_GET['animate'])) {
        }
        $Content    = @file_get_contents("http://" . $host . "/scripts/parabolic.php?i1=" . $imurl . "&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/ps." . rand(0, 100000) . $mypp . ".jpg") . "&i2=" . $imurl2 . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/ph." . rand(0, 100000) . $mypp . ".jpg") . "&width=" . $wv . "&height=" . $hv . "&aantal=" . $nrOfFrames . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));
        $aantalecho = $Content;
    }
    if ($tr == 560) {
        $aa = rand(2, 6);
        if ($mypp == "WebShop" || $mypp != "" || $mypp == "Services" || isset($_GET['animate'])) {
        }
        $Content    = @file_get_contents("http://" . $host . "/scripts/saturn.php?i1=" . $imurl2 . "&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . rand(0, 100000) . $ip . "." . $mypp . "_.jpg") . "&i2=" . $imurl . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . rand(0, 1000000) . $ip . "." . $mypp . "__.jpg") . "&aantal=" . $nrOfFrames . "&width=" . $wvl . "&height=" . $hvl . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));
        $aantalecho = $Content;
    }
	
	    if ($tr == 250) {
		$Content = @file_get_contents("http://" . $host . "/scripts/image-resize-image.php?i1=" . $imurl2 . "&start=" . $hNrOfFrames . "&dir=_&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p6." . rand(0, 10000000) . $mypp . ".jpg") . "&i2=" . $imurl . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/y6." . rand(0, 10000000). $mypp . ".jpg") . "&width=" . $wvl . "&height=" . $hvl . "&aantal=" . $hNrOfFrames . "&frames=" . $nrOfFrames . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));
    }
	
	
	
	
	/*
	
    if ($tr == 300) {
        $ud = 0;
        if (rand(0, 10) > 5) {
            $ud = 1;
        }
        $aa   = rand(2, 6);
        $typp = rand(1, 10000);
        if ($mypp == "WebShop" || $mypp != "" || $mypp == "Services" || isset($_GET['animate'])) {
            $Content = @file_get_contents("http://" . $host . "/scripts/moving-noise.php?i1=" . $imurl2 . "&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/ps." . $typp . $mypp . ".jpg") . "&i2=" . $imurl2 . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p0." . $typp . $mypp . ".jpg") . "&ud=" . $ud . "&width=" . $wv . "&height=" . $hv . "&dir=_&aantal=" . $hNrOfFrames . "&start=" . $hNrOfFrames . "&frames=" . $hNrOfFrames . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));
            $Content= @file_get_contents("http://" . $host . "/scripts/moving-noise.php?i1=" . $imurl . "&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pd." . $typp . $mypp . ".jpg") . "&i2=" . $imurl . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p2." . $typp . $mypp . ".jpg") . "&ud=" . $ud . "&width=" . $wv . "&height=" . $hv . "&dir=c&aantal=" . $hNrOfFrames . "&frames=" . $hNrOfFrames . "&start=0&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));
        }
    } 

	*/
	    if ($tr == 140) {
        $aa = rand(2, 6);
$Content = @file_get_contents("http://" . $host . "/scripts/clouds-or-universe.php?i1=" . $imurl . "&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp . "_.jpg") . "&i3_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pis0." . $ip . "." . $mypp . "_.jpg") . "&i2=" . $imurl2 . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp . "__.jpg") . "&aantal=" . ($nrOfFrames + 1) . "&width=" . $wv . "&height=" . $hv . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));
    }
	
	    if ($tr == 300) {
        $aa = rand(2, 6);
        $Content    = @file_get_contents("http://" . getenv("HTTP_HOST") . "/scripts/wheel.php?i1=" . $imurl2 . "&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p0." . rand(0, 100000) . $ip . ".jpg") . "&i2=" . $imurl . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p1." . rand(0, 1000000) . $ip . ".jpg") . "&width=" . $wv . "&height=" . $hv . "&aantal=" . ($nrOfFrames ) . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." .$ip.".".$mypp   )   );
        $aantalecho = $Content;
    }
	
		    if ($tr == 510) {
        $aa = rand(2, 6);
        if ($mypp == "WebShop" || $mypp != "" || $mypp == "Services" || isset($_GET['animate'])) {
            $Content    = @file_get_contents("http://" . $host . "/scripts/flag.php?i1=" . $imurl2 . "&startp=1&dir=_&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p0." . rand(0, 100000000) . $mypp . ".jpg") . "&i2=" . $imurl2 . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p1." . rand(0, 1000000) . $mypp . ".jpg") . "&width=60&height=60&wi=" . $wv . "&he=" . $hv . "&aantal=" . ($nrOfFrames + 1) . "&frames=" . ($nrOfFrames + 1) . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));
            $aantalecho = $Content;
        }
    }
	
	
    if ($tr == 430) {
        $aa = rand(2, 6);

        $Content    = @file_get_contents("http://" . $host . "/scripts/image2pix.php?i1=" . $imurl2 . "&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p2." . rand(0, 100000000) . $mypp . ".jpg") . "&i2=" . $imurl . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p1." . rand(0, 1000000) . $mypp . ".jpg") . "&width=" . $wv . "&height=" . $hv . "&aantal=" .$nrOfFrames . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));
        $aantalecho = $Content;
    }
    if ($tr == 130) {
        if ($mypp == "WebShop" || $mypp != "" || $mypp == "Services" || isset($_GET['animate'])) {
            
			  $smthh   = rand(0, 1000000);
            $Content = @file_get_contents("http://" . $host . "/scripts/disiluse.php?i1=" . $imurl2 . "&start=" . $hNrOfFrames . "&dir=_&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p6." . rand(0, 10000000) . $mypp . ".jpg") . "&i2=" . $imurl . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/y6." . rand(0, 10000000). $mypp . ".jpg") . "&width=" . $wvl . "&height=" . $hvl . "&aantal=" . $hNrOfFrames . "&frames=" . $nrOfFrames . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));

			
        }
    }

    if ($tr == 160) {
        if ($mypp == "WebShop" || $mypp != "" || $mypp == "Services" || isset($_GET['animate'])) {
            $aqa     = rand(5, 10);
            $ip      = "";
            $Content = @file_get_contents("http://" . $host . "/scripts/slide-bars.php?i1=" . $imurl2 . "&start=" . $hNrOfFrames . "&dir=_&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p6." . rand(0, 10000000) . $mypp . ".jpg") . "&i2=" . $imurl . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/y6." . rand(0, 10000000). $mypp . ".jpg") . "&width=" . $wvl . "&height=" . $hvl . "&aantal=" . $hNrOfFrames . "&frames=" . $nrOfFrames . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));
        }
    }
    if ($tr == 230) {
        $aa = rand(4, 7);
        if ($mypp == "WebShop" || $mypp != "" || $mypp == "Services" || isset($_GET['animate'])) {
            $Content = @file_get_contents("http://" . $host . "/scripts/expand-from-middle.php?i1=" . $imurl . "&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pt." . rand(0, 100000) . $mypp . ".jpg") . "&i2=" . $imurl2 . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pf." . rand(0, 100000) . $mypp . ".jpg") . "&width=" . $wvl . "&height=" . $hvl . "&aantal=" . $nrOfFrames . "&frames=" . $nrOfFrames . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));
        }
    }
    if ($tr ==90) {
        $smooth = true;
        $aa     = rand(2, 6);
        if ($mypp == "WebShop" || $mypp != "" || $mypp == "Services" || isset($_GET['animate'])) {
            $smthh   = rand(0, 1000000);
            $Content = @file_get_contents("http://" . $host . "/scripts/rectangles.php?i1=" . $imurl2 . "&start=" . $hNrOfFrames . "&dir=_&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p6." . rand(0, 10000000) . $mypp . ".jpg") . "&i2=" . $imurl . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/y6." . rand(0, 10000000). $mypp . ".jpg") . "&width=" . $wvl . "&height=" . $hvl . "&aantal=" . $hNrOfFrames . "&frames=" . $nrOfFrames . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));

        }
    }
	
	if ($tr == 340) {
        $aa      = rand(2, 6);
        $ooo     = rand(1000, 1000000);
        $Content = @file_get_contents("http://" . $host . "/scripts/spiral.php?i1=" . $imurl . "&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p3." . rand(0, 100000) . $mypp . ".jpg") . "&i2=" . $imurl2 . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p4." . $mypp . rand(0, 100000) . ".jpg") . "&i3=" . $imurl2 . "&i3_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/y3." . rand(0, 100000) . $mypp . ".jpg") . "&i4=" . $imurl . "&i4_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/a4." . $mypp . rand(0, 100000) . ".jpg") . "&width=" . $wvl . "&height=" . $hvl . "&aantal=" . $hNrOfFrames . "&start=".($hNrOfFrames+1)."&frames=" . $hNrOfFrames . "&dir=_&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));

    }
	
	
	    if ($tr == 210) {
        if ($mypp == "WebShop" || $mypp != "" || $mypp == "Services" || isset($_GET['animate'])) {
            $aqa     = rand(5, 10);
            $ip      = "";
            $Content = @file_get_contents("http://" . $host . "/scripts/rot-masks.php?i1=" . $imurl2 . "&start=" . $hNrOfFrames . "&dir=_&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p6." . rand(0, 10000000) . $mypp . ".jpg") . "&i2=" . $imurl . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/y6." . rand(0, 10000000). $mypp . ".jpg") . "&width=" . $wvl . "&height=" . $hvl . "&aantal=" . $hNrOfFrames . "&frames=" . $nrOfFrames . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));
        }
    }
	
	
    if ($tr == 260) {
        $smooth = true;
        $aa     = rand(2, 6);
        if ($mypp == "WebShop" || $mypp != "" || $mypp == "Services" || isset($_GET['animate'])) {
            $smthh   = rand(0, 1000000);
            $Content = @file_get_contents("http://" . $host . "/scripts/path-from-center.php?i1=" . $imurl2 . "&start=" . $hNrOfFrames . "&dir=_&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p6." . rand(0, 10000000) . $mypp . ".jpg") . "&i2=" . $imurl . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/y6." . rand(0, 10000000). $mypp . ".jpg") . "&width=" . $wvl . "&height=" . $hvl . "&aantal=" . $hNrOfFrames . "&frames=" . $nrOfFrames . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));

        }
    }
    if ($tr == 80) {
        $smooth = true;
        $aa     = rand(2, 6);
        if ($mypp == "WebShop" || $mypp != "" || $mypp == "Services" || isset($_GET['animate'])) {
            $smthh   = rand(0, 1000000);
            $Content = @file_get_contents("http://" . $host . "/scripts/sliding-windows.php?i1=" . $imurl2 . "&start=" . $hNrOfFrames . "&dir=_&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p6." . rand(0, 10000000) . $mypp . ".jpg") . "&i2=" . $imurl . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/y6." . rand(0, 10000000). $mypp . ".jpg") . "&width=" . $wvl . "&height=" . $hvl . "&aantal=" . $hNrOfFrames . "&frames=" . $nrOfFrames . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));

        }
    }
	
	    if ($tr == 390) {
        $smooth = true;
        $aa     = rand(2, 6);
        if ($mypp == "WebShop" || $mypp != "" || $mypp == "Services" || isset($_GET['animate'])) {
            $smthh   = rand(0, 1000000);
            $Content = @file_get_contents("http://" . $host . "/scripts/sliding-windows.php?i1=" . $imurl2 . "&start=" . $hNrOfFrames . "&dir=_&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p6." . rand(0, 10000000) . $mypp . ".jpg") . "&i2=" . $imurl . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/y6." . rand(0, 10000000). $mypp . ".jpg") . "&width=" . $wvl . "&height=" . $hvl . "&aantal=" . $hNrOfFrames . "&frames=" . $nrOfFrames . "&imgss=".$_GET['nrOffSummaryImg']."&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));

        }
    }
	
    if ($tr == 180) {
        $smooth = true;
        $aa     = rand(2, 6);
        if ($mypp == "WebShop" || $mypp != "" || $mypp == "Services" || isset($_GET['animate'])) {
            $smthh   = rand(0, 1000000);
            $Content = @file_get_contents("http://" . $host . "/scripts/rotate-object.php?i1=" . $imurl2 . "&start=" . $hNrOfFrames . "&dir=_&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p6." . rand(0, 10000000) . $mypp . ".jpg") . "&i2=" . $imurl . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/y6." . rand(0, 10000000). $mypp . ".jpg") . "&width=" . $wvl . "&height=" . $hvl . "&aantal=" . $hNrOfFrames . "&frames=" . $nrOfFrames . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));

        }
    }	
	
	//
	
	    if ($tr == 240) {
        $smooth = true;
        $aa     = rand(2, 6);
        if ($mypp == "WebShop" || $mypp != "" || $mypp == "Services" || isset($_GET['animate'])) {
            $smthh   = rand(0, 1000000);
            $Content = @file_get_contents("http://" . $host . "/scripts/smooth.php?i1=" . $imurl2 . "&start=" . $hNrOfFrames . 
			"&dir=_&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p6." . rand(0, 10000000) . $mypp . ".jpg") .
			"&mtmain=".$mtmain."&tr10=".($tr/10)."&i1__=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p6." .
			rand(0, 10000000) . $mypp . ".jpg") . "&mtmain=".$mtmain."&tr10=".($tr/10).
			"&i2__=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p6." . rand(0, 10000000) . $mypp . ".jpg") .
			"&i2=" . $imurl . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/y6." . rand(0, 10000000). $mypp . ".jpg") .
			"&width=" . $wv . "&height=" . $hv . "&aantal=" . $hNrOfFrames . "&frames=" . $nrOfFrames .
			"&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));

        }
    }
	
	
		    if ($tr == 0) {
        $smooth = true;
        $aa     = rand(2, 6);
        if ($mypp == "WebShop" || $mypp != "" || $mypp == "Services" || isset($_GET['animate'])) {
            $smthh   = rand(0, 1000000);
            $Content = @file_get_contents("http://" . $host . "/scripts/fft.php?i1=" . $imurl2 . "&start=" . $hNrOfFrames . "&dir=_&i2__=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p6." . rand(0, 10000000) . $mypp . ".jpg") . "&mtmain=".$mtmain."&tr10=".($tr/10)."&i1__=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p6." . rand(0, 10000000) . $mypp . ".jpg") . "&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p6." . rand(0, 10000000) . $mypp . ".jpg") . "&i2=" . $imurl . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/y6." . rand(0, 10000000). $mypp . ".jpg") . "&width=" . $wv . "&height=" . $hv . "&aantal=" . $hNrOfFrames . "&frames=" . $nrOfFrames . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));

        }
    }
	
	
	
    if ($tr == 50) {
        $aa = rand(2, 6);
        if ($mypp == "WebShop" || $mypp != "" || $mypp == "Services" || isset($_GET['animate'])) {
            $Content = @file_get_contents("http://" . $host . "/scripts/digitalize.php?i1=" . $imurl . "&startp=0&dir=_&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p8." . $mypp . ".jpg") . "&i2=" . $imurl . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p9." . $mypp . ".jpg") . "&width=128&height=128&wi=" . $wvl . "&he=" . $hvl . "&aantal=" . ($hNrOfFrames) . "&frames=" . $nrOfFrames . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));
            $Content .= @file_get_contents("http://" . $host . "/scripts/digitalize.php?i1=" . $imurl2 . "&startp=" . ($hNrOfFrames+1) . "&dir=-&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p9." . $mypp . ".jpg") . "&i2=" . $imurl2 . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p10." . $mypp . ".jpg") . "&width=128&height=128&wi=" . $wvl . "&he=" . $hvl . "&aantal=" . ($hNrOfFrames) . "&frames=" . $nrOfFrames . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));
        }
    }
    if ($tr == 40) {
        if ($mypp == "WebShop" || $mypp != "" || $mypp == "Services" || isset($_GET['animate'])) {
            $Content = @file_get_contents("http://" . $host . "/scripts/curved-path-image.php?i1=" . $imurl . "&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p11." . rand(0, 100000) . $mypp . ".jpg") . "&i2=" . $imurl2 . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p12." . $mypp . rand(0, 100000) . ".jpg") . "&width=" . $wv . "&height=" . $hv . "&aantal=" . $nrOfFrames . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));
        }
    }
    if ($tr == 410) {
        $aa  = rand(2, 6);
        $dfs = rand(0, 10000000);
        if ($mypp == "WebShop" || $mypp != "" || $mypp == "Services" || isset($_GET['animate'])) {
            $Content = @file_get_contents("http://" . $host . "/scripts/difuse.php?width=" . $wv . "&height=" . $hv . "&i1=" . $imurl2 . "&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p8." . $dfs . $mypp . ".jpg") . "&i2=" . $imurl . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/q8." . $dfs . $mypp . ".jpg") . "&aantal=" . $hNrOfFrames . "&frames=" . $hNrOfFrames . "&dir=-&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));
           
        }
    }
    if ($tr == 150) {
        $aa = rand(2, 6);
        if ($mypp == "WebShop" || $mypp != "" || $mypp == "Services" || isset($_GET['animate'])) {
              $Content = @file_get_contents("http://" . $host . "/scripts/opening-bars.php?i1=" . $imurl2 . "&start=" . $hNrOfFrames . "&dir=_&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p6." . rand(0, 10000000) . $mypp . ".jpg") . "&i2=" . $imurl . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/y6." . rand(0, 10000000). $mypp . ".jpg") . "&width=" . $wvl . "&height=" . $hvl . "&aantal=" . $hNrOfFrames . "&frames=" . $nrOfFrames . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));
        }
    }
	
	
	    if ($tr == 60) {
        $smooth = true;
        $aa     = rand(2, 6);
        if ($mypp == "WebShop" || $mypp != "" || $mypp == "Services" || isset($_GET['animate'])) {
            $smthh   = rand(0, 1000000);
            $Content = @file_get_contents("http://" . $host . "/scripts/opening-in-object.php?i1=" . $imurl . "&start=" . $hNrOfFrames . "&dir=_&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p6." . rand(0, 10000000) . $mypp . ".jpg") . "&i2=" . $imurl2 . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/y6." . rand(0, 10000000). $mypp . ".jpg") . "&width=" . $wvl . "&height=" . $hvl . "&aantal=" . $hNrOfFrames . "&frames=" . $nrOfFrames . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));

        }
    }
	
		    if ($tr == 120) {
        $smooth = true;
        $aa     = rand(2, 6);
        if ($mypp == "WebShop" || $mypp != "" || $mypp == "Services" || isset($_GET['animate'])) {
            $smthh   = rand(0, 1000000);
            $Content = @file_get_contents("http://" . $host . "/scripts/slide-page.php?i1=" . $imurl . "&start=" . $hNrOfFrames . "&dir=_&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p6." . rand(0, 10000000) . $mypp . ".jpg") . "&i2=" . $imurl2 . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/y6." . rand(0, 10000000). $mypp . ".jpg") . "&width=" . $wvl . "&height=" . $hvl . "&aantal=" . $nrOfFrames . "&frames=" . $nrOfFrames . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));

        }
    }
	

	
	    if ($tr == 480) {
        $smooth = true;
        $aa     = rand(2, 6);
        if ($mypp == "WebShop" || $mypp != "" || $mypp == "Services" || isset($_GET['animate'])) {
            $smthh   = rand(0, 1000000);
            $Content = @file_get_contents("http://" . $host . "/scripts/sliding-windows.php?i1=" . $imurl2 . "&start=" . $hNrOfFrames . "&dir=_&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p6." . rand(0, 10000000) . $mypp . ".jpg") . "&i2=" . $imurl . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/y6." . rand(0, 10000000). $mypp . ".jpg") . "&width=" . $wvl . "&height=" . $hvl . "&aantal=" . $hNrOfFrames . "&frames=" . $nrOfFrames . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));

        }
    }
	
	 if ($tr == 530) {
        $aa = rand(2, 6);
        if ($mypp == "WebShop" || $mypp != "" || $mypp == "Services" || isset($_GET['animate'])) {
            $Content = @file_get_contents("http://" . $host . "/scripts/rotate.php?i1=" . $imurl . "&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pv." . rand(0, 1000000) . $mypp . ".jpg") . "&i2=" . $imurl . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p0." . rand(0, 1000000) . $mypp . ".jpg") . "&width=" . $wv . "&height=" . $hv . "&aantal=" . ($nrOfFrames+4) . "&frames=" . ($nrOfFrames+4) . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));
        }
    }
	


	if ($tr == 500) {
        $aa = rand(2, 6);
        if ($mypp == "WebShop" || $mypp != "" || $mypp == "Services" || isset($_GET['animate'])) {
            $Content = @file_get_contents("http://" . $host . "/scripts/nrofcol.php?i1=" . $imurl2 . "&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pv." . rand(0, 1000000) . $mypp . ".jpg") . "&i2=" . $imurl . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p0." . rand(0, 1000000) . $mypp . ".jpg") . "&wi=" . $wv . "&he=" . $hv . "&aantal=" . ($nrOfFrames+4) . "&frames=" . ($nrOfFrames+4) . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));
        }
    }

	
    if ($tr == 70) {
        $Content = @file_get_contents("http://" . $host . "/scripts/slide.php?i1=" . $imurl . "&startp=1&dir=_&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p8." . rand(0, 100000000) . $mypp . ".jpg") . "&i2=" . $imurl2 . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p9." . rand(0, 10000000) . $mypp . ".jpg") . "&width=" . $wv . "&height=" . $hv . "&wi=" . $wv . "&he=" . $hv . "&aantal=" . $nrOfFrames . "&frames=" . $nrOfFrames . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));
    }
    if ($tr == 110) {
        $aa = rand(2, 6);
        if ($mypp == "WebShop" || $mypp != "" || $mypp == "Services" || isset($_GET['animate'])) {
            $wix        = rand(10, 30);
            $hex        = rand(5, 10);
            $motiob     = rand(0, 10000000);
            $Content    = @file_get_contents("http://" . $host . "/scripts/motion-blur.php?i1=" . $imurl . "&dir=_&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p8." . $motiob . $mypp . ".jpg") . "&i2=" . $imurl2 . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pg." . $motiob . $mypp . ".jpg") . "&width=20&height=20&wi=" . $wvl . "&he=" . $hvl . "&aantal=" . ($hNrOfFrames) . "&startp=" . ($hNrOfFrames)."&frames=" . $nrOfFrames . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp) . "&wix=" . $wix . "&hex=" . $hex);

        }
    }
    if ($tr == 190) {
        $contrst = rand(0, 100000000);
        $Content = @file_get_contents("http://" . $host . "/scripts/contrast.php?i1=" . $imurl . "&start=1&dir=_&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pr." . $contrst . $mypp . ".jpg") . "&i2=" . $imurl . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pi." . $contrst . $mypp . ".jpg") . "&width=60&height=60&wi=" . $wv . "&he=" . $hv . "&aantal=" . ($hNrOfFrames+1) . "&frames=" . ($nrOfFrames+1) . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));
        $Content= @file_get_contents("http://" . $host . "/scripts/contrast.php?i1=" . $imurl2 . "&start=" . $hNrOfFrames . "&dir=-&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p9." . $contrst . $mypp . ".jpg") . "&i2=" . $imurl2 . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p10." . $mypp . $contrst . ".jpg") . "&width=60&height=60&wi=" . $wv . "&he=" . $hv . "&aantal=" . ($hNrOfFrames+1) . "&frames=" . ($nrOfFrames+1) . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));
    }
    if ($tr == 100) {
        $drq = ($_SESSION['lightend']%2);
        $_SESSION['lightend']= $_SESSION['lightend']+1;
        $ltr    = rand(0, 1000000);
				$dr = ($_SESSION['dr']%2);
				
$_SESSION['dr']=$_SESSION['dr']+1;
				$Content = @file_get_contents("http://".getenv("HTTP_HOST")."/scripts/lighten.php?i1=".$imurl."&mtmain=".$mtmain."&tr10=".($tr/10)."&startp=1&dir=_&i1_=".urlencode($_SERVER['DOCUMENT_ROOT']."/images/p8.".rand(0,10000000).$mypp.".jpg")."&i2=".$imurl."&i2_=".urlencode($_SERVER['DOCUMENT_ROOT']."/images/p9.".rand(0,1000000).$mypp.".jpg")."&width=60&height=60&wi=".$wv."&he=".$hv."&aantal=".($hNrOfFrames+1)."&dr=".$dr."&frames=".($hNrOfFrames+1)."&fn=".urlencode($_SERVER['DOCUMENT_ROOT']."/images/pimages".$prevvimg.$_GET['reed']."0.".$ip.".".$mypp) );
				$Content = @file_get_contents("http://".getenv("HTTP_HOST")."/scripts/lighten.php?i1=".$imurl2."&startp=".$hNrOfFrames."&mtmain=".$mtmain."&tr10=".($tr/10)."&dir=-&i1_=".urlencode($_SERVER['DOCUMENT_ROOT']."/images/p9.".rand(0,1000000).$mypp.".jpg")."&i2=".$imurl2."&i2_=".urlencode($_SERVER['DOCUMENT_ROOT']."/images/p10.".rand(0,1000000).$mypp.".jpg")."&width=60&height=60&wi=".$wv."&he=".$hv."&startp=".$hNrOfFrames."&dr=".$dr."&aantal=".($hNrOfFrames+1)."&frames=".($hNrOfFrames+1)."&fn=".urlencode($_SERVER['DOCUMENT_ROOT']."/images/pimages".$prevvimg.$_GET['reed']."0.".$ip.".".$mypp ) );
		
    }
    if ($tr == 470) {
        $aa  = rand(2, 6);
        $rgt = rand(0, 10000000);
        if ($mypp == "WebShop" || $mypp != "" || $mypp == "Services" || isset($_GET['animate'])) {
            $Content = @file_get_contents("http://" . $host . "/scripts/noise.php?i1=" . $imurl . "&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p0." . $mypp . $rgt . ".jpg") . "&i2=" . $imurl2 . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p0." . $mypp . $rgt . ".jpg") . "&width=" . $wv . "&height=" . $hv . "&dir=_&aantal=" . $hNrOfFrames . "&start=" . $hNrOfFrames . "&frames=" . $hNrOfFrames . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));
            $Content= @file_get_contents("http://" . $host . "/scripts/noise.php?i1=" . $imurl . "&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p0." . $mypp . $rgt . ".jpg") . "&i2=" . $imurl . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p2." . $mypp . $rgt . ".jpg") . "&width=" . $wv . "&height=" . $hv . "&dir=+&aantal=" . $hNrOfFrames . "&frames=" . $hNrOfFrames . "&start=0&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));
        }
    }
    if ($tr == 360) {
        $aa = rand(2, 6);
        $_SESSION['projection'] += 1;
        $projection = $_SESSION['projection'] % 2;
        if ($mypp == "WebShop" || $mypp != "" || $mypp == "Services" || isset($_GET['animate'])) {
            $Content = @file_get_contents("http://" . $host . "/scripts/projection-on-shape.php?i1=" . $imurl2 . "&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p6." . rand(0, 1000000) . $mypp . ".jpg") . "&i2=" . $imurl . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p5." . rand(0, 10000000) . $mypp . ".jpg") . "&projection=" . $projection . "&width=" . $wv . "&height=" . $hv . "&aantal=" . $nrOfFrames . "&frames=" . $nrOfFrames . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));
        }
    }
	
	    if ($tr ==350 ) {

            $Content = @file_get_contents("http://" . $host . "/scripts/cube.php?i1=" . $imurl2 . "&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p6." . rand(0, 1000000) . $mypp . ".jpg") . "&i2=" . $imurl . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p5." . rand(0, 1000000) . $mypp . ".jpg") . "&i3=" . $imurl3 . "&i3_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p5." . rand(0, 1000000) . $mypp . ".jpg") . "&projection=" . $projection . "&width=" . $wv . "&height=" . $hv . "&aantal=" . $nrOfFrames . "&frames=" . $nrOfFrames . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));
       
    }
	
		if ($tr == 320 ) {
        $aa = rand(2, 6);

        if ($mypp == "WebShop" || $mypp != "" || $mypp == "Services" || isset($_GET['animate'])) {
            $Content = @file_get_contents("http://" . $host . "/scripts/opening-windows.php?i1=" . $imurl2 . "&mtmain=".$mtmain."&tr10=".($tr/10)."&i1_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p6." . rand(0, 1000000) . $mypp . ".jpg") . "&i2=" . $imurl . "&i2_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p5." . rand(0, 10000000) . $mypp . ".jpg") . "&i3=" . $imurl3 . "&i3_=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/p5." . rand(0, 10000000) . $mypp . ".jpg") . "&&projection=" . $projection . "&width=" . $wv . "&height=" . $hv . "&aantal=" . $nrOfFrames . "&frames=" . $nrOfFrames . "&fn=" . urlencode($_SERVER['DOCUMENT_ROOT'] . "/images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp));
        }
    }
	
	


	
//	include_once($_SERVER['DOCUMENT_ROOT'].'/scripts/php/effect-base.php');
	
	
	

	

	$_SESSION['mtmain']=$_SESSION['mtmain']+1;


if($_GET['music']!="" && $_SESSION['mtmain']==100000){

		$mtime = "240";
		if($_GET['time']!=""){
			$mtime = $_GET['time'];
		}
		else{
		$_GET['time']="240";
		}


sleep(5);




		$mtime = "240";
		if($_GET['time']!=""){
			$mtime = $_GET['time'];
		}
		else{
		$_GET['time']="240";
		}

	
		
		sleep(2);
		
				$xs="".$_SESSION['outip']."";
		$paget=file_get_contents("http://www.ogena.net/apps/".$_SESSION['outip'].".html");
		$npq=explode("<br>", $paget);
		
	$dirj=$_SERVER['DOCUMENT_ROOT']."/scripts/java/";
			$cs="";
		$host=getenv('HTTP_HOST');
		
		for($jj=0;$jj<(count($npq)-1);$jj++){
			
			$nextp = $npq[$jj];
			$ext=explode(".", $nextp);
			$ex= $ext[(count($ext) -1)];
			
			@copy($nextp, $_SERVER['DOCUMENT_ROOT']."/sound/searched/searched".$jj.".".$ex);
			
		}
		
	

		//sleep(8);

		
				$mtime = "180";
		if($_GET['time']!=""){
			$mtime = $_GET['time'];
		}
		else{
		$_GET['time']="180";
		}


if(file_exists("c:\windows")){


}
else{

		//exec($drr);

}



		
    }
	
	
    if ($_GET['fx'] == "yes") {
        $sndd = file_get_contents("http://ogena.nl/scripts/php/sound.php?keywords=" . urlencode($search));
        $it   = explode("\n", $sndd);
        $itt  = $it[1];
        echo "<embed width=0   height=0 src='" . $itt . "'></embed>";
    }
    $_GET['pname'] = substr(str_replace(" ", "_", str_replace(":", "_", str_replace(";", "_", $mypp))), 0, min(20, strlen($mypp)));
    $dir           = getcwd() . "/images";
    $ip            = "";
    $dir           = getcwd() . "/images";
    $ip            = "";
    $fn            = str_replace(" ", "_", $mypp);
    $fn            = str_replace(";", "_", $fn);
    $fn            = str_replace(":", "_", $fn);




if($_SESSION['peffect']>30 ){
@unlink($_SERVER['DOCUMENT_ROOT'].'/javaimagephp.jpg');
}


if ($_GET['record'] == "yes") {
}
else{

$_SESSION['newcount'] = 0;
$_SESSION['nnewcount'] = 0;
}


if(isset($_SESSION['fftp'])){

}
else{
$_SESSION['fftp']=0;
}

if(isset($_GET['fft'])){ if ($_GET['fft']>0) {
$_SESSION['fftp']=$_SESSION['fftp']+1;
} }

if($_GET['b']!=""){
$add=0;
}
else{
$add =100000;
}

if(true || $_SESSION['fftp']<2){

     if(file_exists("../../images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . str_replace(" ", "_", $mypp) . ".1001.jpg") && file_exists("../../images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . str_replace(" ", "_", $mypp) . ".".(1000+$nrOfFrames-3).".jpg")   
	 
	 
	 ) {
        $_SESSION['imgnme'] = rand(0, 10000000);
		$rqc=0;
		
		  $nextNumbersa = $_SESSION['mainorder'];
		  $_SESSION['mainorder']=$_SESSION['mainorder']+1;
		
		
		if($_GET['reed']!=""){
		

		$magicvv= $_SESSION['nnewcount'];
		}
		else{
		$magicvv=$_SESSION['newcount'];
		}
				$rqc =0;


		
        for ($i = 1001; $i < (1000 + $nrOfFramesWait + 1); $i++) {
			if(file_exists("../../images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp . ".1002.jpg")){
		
            if ($_GET['drive'] == "") {
              

				
				 

	
  @copy("../../images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp . ".1001.jpg", "../../images/frames/q00frames" . $_GET['pname'] . "." . ($nextNumbersa+$add) . ".jpg");
$nextNumbersa++;
				  $magicvv += 1;
				  		$rqc =$rqc+1;
					

				
	
				
            }
			else {
                
				if($_GET['reed']==""){
					$magicvv += 1;
					
										@copy("../../images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp . ".1001.jpg", $_GET['drive'] . "/q00frames" . $_GET['pname'] . "." .($nextNumbersa+$add). ".jpg");
					
					$nextNumbersa++;
							$rqc =$rqc+1;
				}
				else{
				
				
				
					@copy("../../images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp . ".1001.jpg", $_GET['drive'] . "/q00frames" . $_GET['pname'] . "." . ($nextNumbersa+$add) . ".jpg");

	$magicvv += 1;
				$rqc =$rqc+1;
		
		
			$nextNumbersa++;
			
				}
					
            }
			
        }
		}

        for ($i = 1001; $i < (1000 + $nrOfFrames - 3); $i++) {

        }

        $magicvv=  $magicvv - 1;
		$nextNumbersa=$nextNumbersa-1;
		$rqc=$rqc-1;
		
		$tgho=0;
		$lgo=0;
        for ($i = 1001; $i < (1000 + $nrOfFrames - 0); $i++) {
		if(file_exists("../../images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp . "." . $i . ".jpg")){
		
            if ($_GET['drive'] == "") {
                

					
					$rqc++;
					$magicvv += 1;
					$lgo=$i;
					
					@copy("../../images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp . "." . $i . ".jpg", "../../images/frames/q00frames" . $_GET['pname'] . "." .($nextNumbersa+$add) . ".jpg");
					$nextNumbersa++;
					

				
            } else {
			

               
                $magicvv+= 1;
				 @copy("../../images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp . "." . $i . ".jpg", $_GET['drive'] . "/q00frames" . $_GET['pname'] . "." . ($nextNumbersa+$add). ".jpg");
				$nextNumbersa++;
				$rqc =$rqc+1;
				}

				
            }
			
        
		
		
				else{
		
		
							$rqc++;
					$magicvv += 1;
					
					
					@copy("../../images/pimages".$prevvimg.$_GET['reed']."0." . $ip . "." . $mypp . "." . $lgo . ".jpg", "../../images/frames/q00frames" . $_GET['pname'] . "." . ($nextNumbersa+$add) . ".jpg");
					$nextNumbersa++;
		
		}

		
		
		
	}

		
					if($_GET['reed']!=""){
		$_SESSION['nnewcount']=$magicvv;

		
		}
		else{
		$_SESSION['newcount']=$magicvv;
	
	}
 
		
		$_SESSION['mainorder']=$nextNumbersa;
		$rqc=$rqc-3;
		

		if ($_GET['record'] == "yes") {
		if(file_exists("../../images/frames/__processRequest00Frames" . $_GET['pname'])){
		}
		else{
		
		if(($rqc%2)==1){
		$rqc=$rqc-1;
		}
		else{
		
		}
		
		
@mkdir($_SERVER['DOCUMENT_ROOT']."/images/frames/frames");
$ec=scandir($_SERVER['DOCUMENT_ROOT']."/images/frames/frames");
for($i=0;$i<count($ec);$i++){
	if($ec[$i]=='.' || $ec[$i]=='..'){
		
	}
	else{
		@unlink($_SERVER['DOCUMENT_ROOT']."/images/frames/frames/".$ec[$i]);
	}
	
}
//$you="cd \"".$_SERVER['DOCUMENT_ROOT']."/images/frames/frames\" \nyoutube-dl   ".$_GET['checkYId']. " \n ffmpeg -i * myClip.mp3 \n copy myClip.mp3 ../ \n echo 2 > strec \n del dls.bat";

		
				//$you="cd \"".$_SERVER['DOCUMENT_ROOT']."\images\" \n cd frames \nyoutube-dl  --extract-audio --audio-format mp3 -o myClip_.mp3 ".$_GET['checkYId']. " \ncopy myClip_.mp3 myClip.mp3 \n echo 2 > strec \n del dls.bat";

		
		if($_GET['checkYId']!=""){
		//$file = @fopen('../../images/frames/dls.bat', 'w');
		//@fwrite($file, $you);
		//@fclose($file);
		}
		$dir=$_SERVER['DOCUMENT_ROOT']."/scripts/java";
		$fn=$_SERVER['DOCUMENT_ROOT']."/images/frames/q00frames" . $_GET['pname'];
		$tn=$_SERVER['DOCUMENT_ROOT']."/images/0000frames" . $_GET['pname'];
		$tnr=$_SERVER['DOCUMENT_ROOT']."/images/imcnt";
	
		$file=fopen("../../images/frames/__processRequest00Frames.bat", 'w');
		
		$filename= $_SERVER['DOCUMENT_ROOT']."/images/frames/__processRequest00Frames";
		
		$you = "";
		if($_GET['checkYId']!=""){
		$you="youtube-dl  -f 5  --extract-audio --audio-format mp3  -o myClip.mp3 ".$_GET['checkYId']. "  && echo 2 > strec ";
		}
		fwrite($file, "java  -cp \"".$dir."\"  ImagesZoom \"".$fn. "\" ".$wv." ".$hv." \"".$tn."\"  ".$rqc." - 1 1 1 1 1 1 1 0 ".$rqc." 0 0 \"".$filename."\"" ." \"".$tnr."\" ".$_GET['_br']. " ".$_GET['_bg']. " ".$_GET['_bb']);
		
		
		fclose($file);

		$file=fopen("../../images/frames/__processRequest00Frames.sh", 'w');
		$filename= $_SERVER['DOCUMENT_ROOT']."/images/frames/__processRequest00Frames";
		fwrite($file, "java  -cp \"".$dir."\"  ImagesZoom \"".$fn. "\" ".$wv." ".$hv." \"".$tn."\"  ".$rqc." - 1 1 1 1 1 1 1 0 ".$rqc." 0 0 \"".$filename."\"" ." \"".$tnr."\" ".$_GET['_br']. " ".$_GET['_bg']. " ".$_GET['_bb']);
		fclose($file);

		@chmod("../../images/frames/__processRequest00Frames.sh", 0777);



		}
		}

    }
}

if( isset($_GET['fft'])) { if( $_GET['fft']>0) {
$_SESSION['fftp']=$_SESSION['fftp']+1;
} }






	
	if($_GET['stream']!=""){
	$station=explode("/", $_GET['stream']);
	$sea=$station[2];
	
	if(rand(0,10)>5){
	printTitle($sea);
	}
	else{
printTitle($search);
	}
	
	}
	
	else{
	printTitle($search);
}

	

copy($_SERVER['DOCUMENT_ROOT'].'/scripts/sync/__processRequest00Frames.php', $_SERVER['DOCUMENT_ROOT'].'/images/frames/__processRequest00Frames.php');



if(!isset($_SESSION['summary'])){

$_SESSION['summary']='summary';



}


$time_elapsed_secs = microtime(true) - $startt;


$f=fopen($_SERVER['DOCUMENT_ROOT']."/Info/".$tr, "w");
fwrite($f, $time_elapsed_secs);
fclose($f);


?>
