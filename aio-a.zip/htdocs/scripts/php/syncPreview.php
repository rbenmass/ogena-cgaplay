<?php

	@mkdir($_SERVER['DOCUMENT_ROOT']."/images/Preview");
	if($_GET['reset']=="reset"){
		$files = scanDir($_SERVER['DOCUMENT_ROOT']."/images/Preview");
		for($i=0;$i<count($files);$i++){
		
			if($files[$i]=="." || $files[$i]==".."){
			}
			else{
				@unlink($_SERVER['DOCUMENT_ROOT']."/images/Preview/".$files[$i]);
			}
		
		}
		@unlink($_SERVER['DOCUMENT_ROOT']."/images/previewEffect");
		
		
	}
	if($_GET['imurl']!=""){
	
	
			$files = scanDir($_SERVER['DOCUMENT_ROOT']."/images/Preview");
		for($i=0;$i<count($files);$i++){
		
			if($files[$i]=="." || $files[$i]==".."){
			}
			else{
			
				$fil = explode("_", $files[$i]);
				$w==$fil[0]."_".$fil[1];
				if($w=="image_".$_GET['imageIndex']){
				@unlink($_SERVER['DOCUMENT_ROOT']."/images/Preview/".$files[$i]);
				}
				
				}
			}
		
		
	
	
	@copy($_GET['imurl'], $_SERVER['DOCUMENT_ROOT']."/images/Preview/image_".(11111+$_GET['imageIndex'])."_".$_GET['tr'].".jpg");
	
	
	
	
	
	
	
	$fil ="". @file_get_contents("http://".getenv("HTTP_HOST")."/images/previewEffect");
	$fil=$fil.";".$_GET['tr'];
	$f = fopen($_SERVER['DOCUMENT_ROOT']."/images/previewEffect", "w");
	fwrite($f, $fil);
	fclose($f);
	
	}

?>