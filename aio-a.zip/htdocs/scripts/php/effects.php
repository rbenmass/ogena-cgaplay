<?php

	header('Access-Control-Allow-Origin: http://ogena.net');
	date_default_timezone_set('Europe/Amsterdam');
		function getEffectNumber($search_){

		
					$fc="";
			$handle = fopen($_SERVER['DOCUMENT_ROOT']."/scripts/php/jip-scripts.php", "r");
			if ($handle) {
				while (($line = fgets($handle)) !== false) {
					$fc.=$line;
				}
			} else {
		
			} 
			$dfg = explode("tr ==", $fc);
			for($i=1;$i<count($dfg);$i++){
				$next = $dfg[$i];
				$dosc=true;
				$tl=0;
				while($dosc==true){
				$ch=$next[$tl];
				
				if($ch==')'){
				$dosc=false;
				}
				$tl++;
				
				}
				$stt = strpos($next, "scripts/");
				

				
				$stte = strpos($next, "?");
				$eff=substr($next, ($stt+8), ($stte-$stt-12));
				
				if(strlen($eff)<25){
				
				$effDesc[]=array(str_replace(" ", "",substr($next, 1, ($tl-2))),$eff);
				}
			}
		
		
			if($search_==""){
				for($eff=0;$eff<count($effDesc);$eff++){
					$nn= $effDesc[$eff];
					echo $nn[1]."  ::  ".$nn[0]."<BR>";
									if($eff%10==9){
				echo "<br>";
				}
				}
			}
			else{
			
			if($search_>0){
				return $search_;
			}
			

				
			$search=strtolower($search_);
			for($i=0;$i<count($effDesc);$i++){
				$score=0;
				$next = $effDesc[$i];
				$losse = explode(" ", $search);
				$book = explode("-", $next[1]);
				
				for($o=0;$o<count($losse);$o++){
					for($p=0;$p<count($book);$p++){
						if($losse[$o]==$book[$p])
							$score++;
						}
					}
					$sc[]=$score/count($book);				
			}
			
			$max=$sc[0];
			$ind=0;
			for($l=0;$l<count($sc);$l++){
				if($sc[$l]>$max){
					$max=$sc[$l];
					$ind=$l;
				}			
			}
			$rf=$effDesc[$ind];	
		
		
		
		return $rf[0];
		}	
		}
		
		if($_GET['show']=="info" && !isset($_GET['version'])){ echo  getEffectNumber(""); }
		if($_GET['show']=="info" && isset($_GET['version'])){ 
		$version=file_get_contents("http://".getenv("HTTP_HOST")."/Info/Release");
		
		echo  getEffectNumber("")."@".$version; }
		
		
		
?>
