<?php
set_time_limit(15); 

$dir =$_SERVER['DOCUMENT_ROOT']. "/scripts/java";  
set_time_limit(0); 


exec("java -cp \"".$dir."\" ToolsImage \"".$_GET['imurl']. "\" ". "\"".$_SERVER['DOCUMENT_ROOT']."/images/".$_GET['fileName']."\"" ." ".$_GET['width']. " ".$_GET['height'] ." ".$_GET['r']." ".$_GET['g']." ".$_GET['b']."");







?>
