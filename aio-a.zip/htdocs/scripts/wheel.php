<?php


$dir =getcwd(). "/java";  




exec(" java -cp \"".$dir."\" ToolsImage \"".$_GET['i1']. "\" ". "\"".$_GET['i1_']."\"" );
exec(" java -cp \"".$dir."\" ToolsImage \"".$_GET['i2']. "\" ". "\"".$_GET['i2_']."\"" );






exec("java -cp \"".$dir."\" ImageBezierCurveWheel \"".$_GET['i1_']. "\" ". "\"".$_GET['i2_']."\" ".rand(5,15)."  ".$_GET['width']." ".$_GET['height']."  ".$_GET['aantal']. " \"" .$_GET['fn']."\""  );



?>