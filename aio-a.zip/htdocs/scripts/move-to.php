<?php


$dir =getcwd(). "/java";  

set_time_limit(0); 
copy($_GET['i1'], $_GET['i1_']);

copy($_GET['i2'], $_GET['i2_']);






$plx= $_GET['width']/10;
$ply=$_GET['height']/15;

$in = rand(0, $plx);
$inn = rand(0, $ply);

  exec(" java -cp \"".$dir."\" ImageMoveTo \"".$_GET['i1_']. "\" ". "\"".$_GET['i2_']."\" ". "\"".$_GET['fn']."\" "." ".$_GET['aantal']." 0 ". "1 1 ". $_GET['frames']." ".$_GET['width']. " ".$_GET['height'] ." ".$in." ".$inn    );

  exec(" java -cp \"".$dir."\" ImageFramesZoom \"".$_GET['fn']. "\" ".$_GET['width']." ".$_GET['height']." \"".$_GET['fn']."\"  ".$_GET['aantal']." - 1 1 1 1 1 1 1 1000 ".$_GET['tr10']." ".$_GET['mtmain']);




?>
