<?php
set_time_limit(160); 

$dir =getcwd(). "/java";  
set_time_limit(0); 
@copy($_GET['i1'], $_GET['i1_']);

@copy($_GET['i2'], $_GET['i2_']);








if($_GET["dir"]=="_"){
  exec(" java -cp \"".$dir."\" ImageMosaic \"".$_GET['i1_']. "\" ".$_GET['aantal']." ".$_GET['width']." ".$_GET['height']." \"".$_GET['fn']."\" "."+"." 0 0 ".$_GET['startp'] . " ".$_GET['wi']." ". $_GET['he'] );

 }
else
{
  exec(" java  -cp \"".$dir."\" ImageMosaic \"".$_GET['i1_']. "\" ".$_GET['aantal']." ".$_GET['width']." ".$_GET['height']." \"".$_GET['fn']."\" "."-"." 0 0 ".$_GET['startp'] . " ".$_GET['wi']." ". $_GET['he'] );


 }

  exec(" java -Xmx1024m -cp \"".$dir."\" ImageFramesZoom \"".$_GET['fn']. "\" ".$_GET['wi']." ".$_GET['he']." \"".$_GET['fn']."\"  ".($_GET['aantal']*2)." - 1 1 1 1 1 1 1 1000 ".$_GET['tr10']." ".$_GET['mtmain']);







?>
