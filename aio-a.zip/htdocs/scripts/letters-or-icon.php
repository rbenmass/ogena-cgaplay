﻿<?php
set_time_limit(160); 

$dir =getcwd(). "/java";  
set_time_limit(0); 
@copy($_GET['i2'], $_GET['i1_']);
@copy($_GET['i1'], $_GET['i2_']);



if(rand(0, 10)<=2){

$alfa="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
$ln=rand(1,2);
$str="";
for($i=0;$i<$ln;$i++){
$ni = rand(0, (strlen($alfa)-2));
$st.=substr($alfa, $ni, 1);
$font="Monospaced";
}
}
else{
$font="WingDings";


$st=rand(61473, (61473+222) );



}
 





if($_GET['doTr']!=""){
$st= substr(urldecode($_GET['doTr']), 0, min(16, strlen(urldecode($_GET['doTr']))));
$r=rand(0,10);
if($r<=3){
$font="Monospaced";
}
if($r>3 && $r<=6){
$font="Georgia";
}
if($r>6){
$font="Script";
}

}

  exec(" java -cp \"".$dir."\" ImageUTFChar  \"".$_GET['i1_']. "\" ". "\"".$_GET['i2_']."\" ".$_GET['frames']." \"".$_GET['fn']."\" 0 ".$font." \"".$st."\" ".$_GET['width']." ".$_GET['height']   );
exec(" java -cp \"".$dir."\" ImageFramesZoom \"".$_GET['fn']. "\" ".$_GET['width']." ".$_GET['height']." \"".$_GET['fn']."\"  ".$_GET['frames']." - 1 1 1 1 1 1 1 1000 ".$_GET['tr10']." ".$_GET['mtmain']);

 







?>
