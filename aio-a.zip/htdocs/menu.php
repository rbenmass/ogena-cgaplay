<?php
	@include_once($_SERVER['DOCUMENT_ROOT']."/html-scripts/menuStart.php");
    @include_once($_SERVER['DOCUMENT_ROOT']."/html-scripts/menuData.php");
    @include_once($_SERVER['DOCUMENT_ROOT']."/html-scripts/menuEnd.php");
?>


