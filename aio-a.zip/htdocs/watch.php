<?php
/*
	Author: Ridouan Ben Massoud
	Description: Watch, Main file to view/record animation.
	Domain: Hosted at ogena.net
	Date: 29-07-2014
*/

ini_set('default_charset', 'UTF-8');
error_reporting(E_ALL ^E_NOTICE);
@exec("killall java");
@exec("taskkill /f /im java.exe");
@exec("killall java");
@exec("taskkill /f /im java.exe");

if(isset($_GET['p'])){

$oldp=$_GET['p'];

}
else{
$oldp="";

}


if(isset($_GET['photos'])){

$photos=$_GET['photos'];

}
else{
$photos="";
}






if(isset($_GET['sound'])){
        $oldsound=$_GET['sound'];
}
else{
        $oldsound="";
}

if(isset($_GET['music'])){
        $newsound=$_GET['music'];
}
else{
        $newsound="";
}

$thethesnd=$oldsound.$newsound;







if($_GET['url']!=""){

$page=file_get_contents($_GET['url']);
$nrOf = explode("<tr>", $page);

$next=$nrOf[$_GET['start']];
$tds= explode("<td>", $next);
$art =  str_replace("&amp;", " & ", strip_tags($tds[1]));
$tit =  str_replace("&amp;", " & ", strip_tags($tds[2]));


if($oldp."".$photos== $art.";".$tit){

}
else{

$_GET['p']=$art.";".$tit;
$_GET["sound"]= $tit." ".$art ." lyrics";
$_GET['title-clip']="Nr 1 Hit ". $art. " ".$tit;
$_GET['description']="Nr 1 Hit ". $art. " ".$tit . " - In Animation";
$_GET['tags']=$art.", ".$tit.", ".", Animation";



}









}

if($_GET['br']!="" && $_GET['bg']!="" && $_GET['bb']!=""){

$_br=$_GET['br'];
$_bg=$_GET['bg'];
$_bb=$_GET['bb'];

}
else{
$_br=255;
$_bg=255;
$_bb=255;
}

/*Simple Crypto: Easy Rotate Function in Include*/
include_once('scripts/php/andersom.php');
include_once('scripts/php/translations.php');
set_time_limit(120);

/*Time out in Seconds*/
$maxTimeOut = 60;
/*Frame rate*/
if($_GET['fr']>0){
	$framerate=$_GET['fr'];
}
else{
	$framerate=16;
}








$nameDirectoryFrames = "clipframes";
@unlink('frameszoom.txt');

@mkdir("sound/melody");
@mkdir("sound/searched");
@mkdir("sound/samples");
@mkdir("sound/vocals");
@mkdir("sound/instruments");
@mkdir("sound/drums");
@mkdir("sound/silent");
@unlink("images/frames/dls.bat");
@unlink("images/frames/dls.sh");



@mkdir("sound/tune");
@mkdir("sound/tuneTemp");

@mkdir($_SERVER['DOCUMENT_ROOT']. "/images/");
@mkdir($_SERVER['DOCUMENT_ROOT']. "/images/frames");
@mkdir($_SERVER['DOCUMENT_ROOT']. "/images/".$nameDirectoryFrames);

@chmod($_SERVER['DOCUMENT_ROOT']. "/images/", 0777);
@chmod($_SERVER['DOCUMENT_ROOT']. "/images/frames", 0777);
@chmod($_SERVER['DOCUMENT_ROOT']. "/images/".$nameDirectoryFrames, 0777);

/*To Run Multiple Instance on one Computer*/
$animRndPrefDate= "1-1-2016";




        @mkdir("sound/volume");
        $f = @fopen("sound/volume/".$_SERVER['REMOTE_ADDR'].".volume.txt", "w");
        @fwrite($f, "0.6");
        @fclose($f);








$ip=""; 
$_GET['store']="yes";
$_GET['filter']="watermark";
$_GET['download']="yes";
$_GET['record']="yes";
 
 
/*
	New: Images in News Feeds
*/
if(isset($_GET['feed'])){
	if($_GET['feed']!=""){
		$oldp."".$photos="Feed";
		@mkdir("images/Feed");
		@mkdir("images/talk");
		$ff=@scandir("images/Feed");
		for($h=0;$h<count($ff);$h++){
			if($ff[$h]=="." || $ff[$h]==".."){
			}
			else{
				@unlink("images/Feed/".$ff[$h]);
				
			}
		}
		
		$ff=@scandir("images/talk");
		for($h=0;$h<count($ff);$h++){
			if($ff[$h]=="." || $ff[$h]==".."){
			}
			else{
				@unlink("images/talk/".$ff[$h]);
				
			}
		}
		
		
		$rss = simplexml_load_file($_GET['feed']);
		if($rss)
		{
			$items = $rss->channel->item;
			$t=0;
			if(count($items)>0){
				foreach($items as $item)
				{
				
					$file=fopen("images/talk/talk".$t.".txt", "w");
						fwrite($file, strip_tags($item->title.". ".$item->description));
						fclose($file);
				
					$t++;
					
					
					if($item->children('media', 'content')){
						foreach($item->children('media', 'content') as $thumb) {
							$xx= $thumb->attributes()->url . '<br/>';
						}
						@copy($xx, "images/Feed/Image".($t+2000).".jpg");
					}			
					
					if($item->enclosure){
					
						@copy($item->enclosure['url'], "images/Feed/Image".($t+2000).".jpg");
					}
					else{
						if(strpos($item->description, "<img")>0){
							
							$im=explode("src='", $item->description);
							if(count($im)>1){
								$thes=explode("'", $im[1]);
							}
							else{
								$im=explode("src=\"", $item->description);
								$thes=explode("\"", $im[1]);
		
							}
							$img=$thes[0];
							@copy($img, "images/Feed/Image".($t+2000).".jpg");
						}
					
					}
				} 
			 }
		 }
	}
 }
 
 
 
 
 
 
 
function get_username(){
	return "Users/Public";
}


function getIdYoutube($q_, $mxx){

$idd=ytDl($q_);

	

	@exec("youtube-dl --get-duration ".$idd ." > dur.txt");
	$cnt = @file_get_contents('dur.txt');
	$dura=explode(":", $cnt);
	$tm=(60*$dura[0])+$dura[1];
@unlink('dur.txt');

        $fou = fopen($_SERVER['DOCUMENT_ROOT']."/images/time", "w");
        fwrite($fou, $tm);
        
$_GET['time']=$tm;
fclose($fou);



	return  $idd;








}

//zoz

if($thethesnd!=""){
	if(file_exists($thethesnd)){

	}
	else{


	$checkYId = getIdYoutube($thethesnd, -1 );


	}

}
 //$checkYId = getIdYoutube($thethesnd, -1 );


/*Desktop name in Linux */
$st= "/home/".get_username()."/.config/user-dirs.dirs";
@exec("echo sudo  cp ".$st. " ".$_SERVER['DOCUMENT_ROOT']."/sound/environment.txt > /var/www/sound/settings.sh");
@chmod($_SERVER['DOCUMENT_ROOT']."/sound/settings.sh", 0777);
$fl="http://".getenv("HTTP_HOST")."/sound/environment.txt";

$rtg = @file_get_contents($fl);
$ds=@explode("\n", $rtg );
$desktop="";
for($i=0;$i<count($ds);$i++){

	if(substr($ds[$i], 0, strlen("XDG_DESKTOP_DIR="))=="XDG_DESKTOP_DIR="){
		$desk = substr($ds[$i], 23);
		$desktop = substr($desk, 0, (strlen($desk)-1)). "" ;
	}

}
@exec("echo ".$desktop ." > /var/www/sound/desktop.txt");

if(!isset($_GET['asname'])){
$_GET['asname']="Animation";
}


/*Artist, Title Lookup Search Paramters*/
$nrOffSummaryImg = 14;
$__p=$oldp."".$photos;

if($_GET['artist']!="")
{
	$oldp."".$photos=$_GET['artist'];
	
	if($_GET['title']!="")
	{
			$oldp."".$photos=$_GET['artist'].";".$_GET['title'];
			if($__p!=""){
				$oldp."".$photos=$_GET['artist'].";".$_GET['title'].";".$__p;
			}
	}

}
if($_GET['title']!="")
{
	$oldp."".$photos=$_GET['title'];
	
	if($_GET['artist']!="")
	{
			$oldp."".$photos=$_GET['artist'].";".$_GET['title'];
			if($__p!=""){
				$oldp."".$photos=$_GET['artist'].";".$_GET['title'].";".$__p;
			}
	}
}
if($_GET['artist']=="" && $_GET['title']==""){
	if($__p==""){
		$oldp."".$photos="Cloudsia";
	}
}


/* The sound of 'it' is standard nowaday's */
if($_GET['fx']==""){
//$_GET['fx']="yes";
}



/*Clean Up*/
file_get_contents("http://".getenv("HTTP_HOST")."/scripts/sync/reset.php");
$wstm = 120;
@exec("taskkill /f /im java.exe");
@exec("taskkill /f /im cmd.exe");

@unlink("scripts/sync/station.txt");
@unlink("scripts/sync/infoStream.txt");
@unlink("scripts/sync/mptitle.txt");
@unlink("scripts/sync/mptitle");
@unlink("scripts/sync/title.txt");



$dirim =scanDir("images/frames");
for($ii=0;$ii<count($dirim);$ii++)
{
	if($dirim[$ii]=="." || $dirim[$ii]=="."){
	}
	else{
		@unlink("images/frames/".$dirim[$ii]);
	}
}


$dirim =scanDir("images");
for($ii=0;$ii<count($dirim);$ii++)
{
	if($dirim[$ii]=="." || $dirim[$ii]=="."){
	}
	else{
		@unlink("images/".$dirim[$ii]);
	}
}



$dirim =scanDir("sound/searched");
for($ii=0;$ii<count($dirim);$ii++)
{
	if($dirim[$ii]=="." || $dirim[$ii]=="."){
	}
	else{
		@unlink("sound/searched/".$dirim[$ii]);
	}
}

@mkdir("temp");
$dirim =scanDir("temp");
for($ii=0;$ii<count($dirim);$ii++)
{
        if($dirim[$ii]=="." || $dirim[$ii]=="."){
        }
        else{
                @unlink("temp/".$dirim[$ii]);
        }
}




$dirim =scanDir("sound/vocals");
for($ii=0;$ii<count($dirim);$ii++)
{
	if($dirim[$ii]=="." || $dirim[$ii]=="."){
	}
	else{
		if(strpos($dirim[$ii],".mp3")>0){
		@unlink("sound/vocals/".$dirim[$ii]);
		}
	}
}






$dirim =scanDir("sound/tuneTemp");
for($ii=0;$ii<count($dirim);$ii++)
{
	if($dirim[$ii]=="." || $dirim[$ii]=="."){
	}
	else{
		@unlink("sound/tuneTemp/".$dirim[$ii]);
	}
}

$dirim =scanDir("sound/tune");
for($ii=0;$ii<count($dirim);$ii++)
{
	if($dirim[$ii]=="." || $dirim[$ii]=="."){
	}
	else{
		@unlink("sound/tune/".$dirim[$ii]);
	}
}












$dirim =scanDir("sound/melody");
for($ii=0;$ii<count($dirim);$ii++)
{
	if($dirim[$ii]=="." || $dirim[$ii]=="."){
	}
	else{

		@unlink("sound/melody/".$dirim[$ii]);
	
	}
}


$dirim =scanDir("sound/vocals");
for($ii=0;$ii<count($dirim);$ii++)
{
        if($dirim[$ii]=="." || $dirim[$ii]=="."){
        }
        else{

                @unlink("sound/vocals/".$dirim[$ii]);

        }
}




$dirim =scanDir("images/".$nameDirectoryFrames);
for($ii=0;$ii<count($dirim);$ii++)
{
	if($dirim[$ii]=="." || $dirim[$ii]=="."){
	}
	else{
		@unlink("images/".$nameDirectoryFrames."/".$dirim[$ii]);
	}
}

exec( "echo  0 > images/imcnt");


$dirim =scanDir("images/");
for($ii=0;$ii<count($dirim);$ii++)
{
	if($dirim[$ii]=="." || $dirim[$ii]=="."){
	}
	else{
		@unlink("images/".$dirim[$ii]);
	}
}

exec( "echo  0 > images/imcnt");


@unlink("../cgi-bin/myClip.AVI");
@unlink("../cgi-bin/tmp.flv");
@unlink("../cgi-bin/tmp.flv.part");
@unlink("../cgi-bin/tmp.wav");
@unlink("../cgi-bin/tmp.AVI");

@unlink("sound/title");
@unlink("sound/description");
@unlink("sound/kewords");
@unlink("sound/download");

//@unlink('images/imcnt');
@exec("echo 0 > images/imcnt");

@unlink("sound/download");
@unlink("../cgi-bin/tmp.mp3");
@unlink("../cgi-bin/myClip.mp3");
@unlink("../cgi-bin/myClip.wav");
@unlink("../cgi-bin/myClip.AVI");
@unlink("../cgi-bin/myClip.AVI");
@unlink("images/myClip.mp3");
@unlink("images/frames/myClip.mp3");
@unlink("images/frames/myClip_.mp3");

@unlink("sound/myCli.mp3");

@unlink("sound/myClipx.mp3");

@unlink("sound/t00.mp3");
@unlink("sound/t01.mp3");
@unlink("sound/t02.mp3");
@unlink("sound/t03.mp3");
@unlink("sound/t04.mp3");
@unlink("sound/t44.mp3");
@unlink("sound/t05.mp3");


@unlink("sound/myClip.wav");
@unlink("sound/myClip.AVI");
@unlink("sound/tmp.flv");
@unlink("sound/cop.bat");
@unlink("sound/cp.sh");
@unlink("scripts/sync/title");

$nlink = fopen("scripts/sync/mptitle", "w");
fwrite($nlink, "");
fclose($nlink);

/*Clean alt values*/
exec("echo 0 > sound/strec");
exec("echo 0 > images/frames/strec");

exec("echo 0 > images/time");
exec("echo Images > images/index.html");







$pp=$oldp."".$photos;
$exp = explode(';', $pp);
for($i=0;$i<count($exp);$i++){
        $nf=$exp[$i];
        if(substr($nf, -4)==".zip"){
        $fil=explode("/", $nf);
        $ppi = $fil[(count($fil)-1)];
        @copy($nf, $_SERVER['DOCUMENT_ROOT']."/images/".$ppi);

   $arch=substr($ppi, 0, (strlen($ppi)-4));
	$sp="\"";
        exec("unzip ".$_SERVER['DOCUMENT_ROOT']."/images/".$ppi . " -d ".$_SERVER['DOCUMENT_ROOT']."/images/".$arch);


	$files=scandir($_SERVER['DOCUMENT_ROOT']."/images/".$arch);
	for($k=0;$k<count($files);$k++){
		if($files[$k]=="." || $files[$k]==".."){
		}
		else{
			@rename($_SERVER['DOCUMENT_ROOT']."/images/".$arch."/".$files[$k],  $_SERVER['DOCUMENT_ROOT']."/images/".$arch."/".str_replace(" ", "_",$files[$k]));	
		}	
	}	

	$arch=substr($ppi, 0, (strlen($ppi)-4));
	$oldp."".$photos=str_replace($nf, $arch, $oldp."".$photos);

        }

}





/*Location for youtube piece of video in animation (Frames)*/
$srcOrgFramessrcOrgFrames="images/".$nameDirectoryFrames."/myFrames";
 
ini_set('default_charset', 'UTF-8');

session_name('s');
session_start();

$_SESSION['mainorder']=0;
$_SESSION['nnewcount']=0;
$_SESSION['newcount']=0;
$_SESSION['prank']=0;
$_SESSION['peffect']=0;
$_SESSION['mtmain']=0;
$searchpp = $oldp."".$photos;
$searw	 =str_replace(" ", "_", $searchpp );
$_SESSION[$searw]=0;

if($_GET['song']!=""){
		$mtime = "280";
		if($_GET['time']!=""){
			$mtime = $_GET['time'];
		}
		else{
		$_GET['time']="280";
		}
}		
		
set_time_limit(0);
$lookup = "keyCheck.php";
$host=getenv("HTTP_HOST");


if($_GET['time']!=""){
	$fou = fopen($_SERVER['DOCUMENT_ROOT']."/images/time", "w");
	fwrite($fou, $_GET['time']);
	fclose($fou);	
	if($_GET['soundfx']==""  && $thethesnd=="" && $_GET['song']==""){
	$_GET['nosound']="yes";
	}	
}

?>
<?php
function andersom($a){

return str_replace('qbyyne', '&', str_rot13($a));

}
	if($_GET['q']!=""){	
		echo andersom($_GET['q']);
	}	
?><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge" />
<HTML>
<body id='theBody'>
<script type='text/javascript' src='/scripts/js/buffer-loader.js'></script>
<script type='text/javascript'>
"use strict";
var context;
var bufferLoader;

function playAudio(src) {
  // Fix up prefixing
  window.AudioContext = window.AudioContext || window.webkitAudioContext;
  context = new AudioContext();

  bufferLoader = new BufferLoader(
    context,
    [
      src
    ],
    finishedLoading
    );

  bufferLoader.load();
}

function finishedLoading(bufferList) {
  // Create two sources and play them both together.
  var source1 = context.createBufferSource();
  source1.buffer = bufferList[0];

  source1.connect(context.destination);
  source1.start(0);
}

</script>

<script type='text/javascript'> 
function wypiwyg(){ 
<?php 

include_once('scripts/php/temp.php');

?> 	
}

        if (window.addEventListener) {  // all browsers except IE before version 9
            window.addEventListener ("beforeunload", OnBeforeUnLoad, false);
        }
        else {
            if (window.attachEvent) {   // IE before version 9
                window.attachEvent ("onbeforeunload", OnBeforeUnLoad);
            }
        }

            // the OnBeforeUnLoad method will only be called in Google Chrome and Safari
        function OnBeforeUnLoad () {

}   





var tststf="00:00:00.0"
var tstst=2;
var seconden=1;
function seco(){
	
	
seconden++;
if((tstst%15)==0){
getdataps();
}


	if(cfra>100000){
tstst+=1;

hz=Math.floor(tstst/3600);
mz=Math.floor((tstst-(hz*60*60))/60);
sz=tstst-(hz*60*60)-(mz*60);

if(hz<10){
ha="0"+hz;
}
else{
ha=hz;
}

if(mz<10){
ma="0"+mz;
}
else{
ma=mz;
}


if(sz<10){
sa="0"+sz;
}
else{
sa=sz;
}



tststf=ha+":"+ma+":"+sz;

	}
setTimeout("seco()", 1000);

}











</script>
<img src='/javaimagephp.jpg' id='dummyImage' width=1 height=1>
<div id='soundy'>
</div>
<script  type="text/javascript">

function splashRestore(){
stv = document.getElementById('slidex');
stv.src='pictures/javaimagephp.jpg';
}


ldayte=new Date();
var nowinsecsx=(60*60*ldayte.getHours())+(ldayte.getMinutes()*60)+ldayte.getSeconds();

var infoo= " -- Title -";
var isPlaying=false;
var parallels = "<?php echo $parallels; ?>";
var effectcnt=0;
var efft = false;
var wt=0;
var checkSoundd=false;
var can=0;
var vpl = 0;
var bgt=0;
var ftm=0;
var psp=100;
rdone=false;
var lastimage = "/javaimagephp.jpg";
var repaintAll=0;
var repaintTemp=0;
var reddy=true;
var reddytopm=1;
var reddytopm=1;
var reddytopml=1;
var lreddy=-1;
var lreddyt=-1;
var trrrtrrrt = -1000000;
var cmean = 0;
var cmest =0;
var smcc=0;
var mct = 100000;
var cfra=100000;
var __cfra=100000;
var  __oldcfra =0;
var fps=0;
var reddyF = true;
var readTime=100000;
var totpercent = 0;
var pairNr1=0;
var pairNr2=0;
var finit=false;
var startero = false;
var newpnew="";





var 		xmlhttprr = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
var             xmlhttpyy = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
var 		xmlhttpto = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");


</script>


<?php



echo "<script type='text/javascript'>";
if($_GET['windowOpen']==""){

echo " function triggeredyy(){  if ((xmlhttpyy.readyState == 4) && (xmlhttpyy.status == 200)) {   tb=document.getElementById('theBody'); tb.innerHTML=\"<center><span style='color:orange'>The video is copied to the studio. Press on Home</span></center>\";  window.top.location.href='/index.php?p=Home';    return true;      } }";
}
else{

echo "function triggeredyy(){    if ((xmlhttpyy.readyState == 4) && (xmlhttpyy.status == 200)) {    tb=document.getElementById('theBody'); tb.innerHTML=\"<center><span style='color:#eeffA0'>&#10004;</span><br><span style='color:orange'>The video is copied to the studio. Press on Home</span></center>\";    } }";


}

echo "</script>";

?>


<script type="text/javascript">


function executeCode(code) {
    var element = document.createElement('script');
    element.type = 'text/javascript';

    try {
        element.appendChild(document.createTextNode(code));
        document.body.appendChild(element);
    }
    catch (e) {
        element.text = code;
        document.body.appendChild(element);
    }
}



function triggeredrr() {
	if ((xmlhttprr.readyState == 4) && (xmlhttprr.status == 200)) {	
		dosou = document.getElementById('soundy');

		ss0=xmlhttprr.responseText;
			ss0 =ss0.replace(new RegExp('>', 'g'),'');
			ss0 =ss0.replace(new RegExp('<', 'g'),'');


			executeCode(ss0);
	
	reddytopml=1;
	slideitx();

	}
}



function ztriggered() {
	if ((zxmlhttp.readyState == 4) && (zxmlhttp.status == 200)) {	
		dosou = document.getElementById('speek');
		dosou.innerHTML=zxmlhttp.responseText;
	
	}
}

function stor(file){

        xmlhttpyy=null;
                xmlhttpyy = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
        

        

	xmlhttpyy.onreadystatechange = triggeredyy;
        xmlhttpyy.open("GET", "/scripts/php/store.php?save="+file+"&dest=<?php echo $_SERVER['DOCUMENT_ROOT']; ?>/data[<?php  echo $_SERVER['REMOTE_ADDR']; ?>]/myMedia/Anim."+Math.ceil(9000*Math.random())+".AVI" );

	xmlhttpyy.send(null);
	tb=document.getElementById('theBody');
	tb.style.backgroundColor='gray';
	tb.innerHTML="<center><img src='/pictures/progress.gif'><br><br><span style='color:white'>Please wait while the video is copied and proccesed...</span></center>";




}

var secst = false;
function getdatarr(dest, ob) {
	

	xmlhttprr = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
	
	xmlhttprr.onreadystatechange = triggeredrr;
	xmlhttprr.open("GET", dest, true);
	xmlhttprr.send(null);


}


var  xmlhttpqq = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
function getdataps() {

        xmlhttpqq = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");

        xmlhttpqq.open("GET", "http://<?php echo getenv("HTTP_HOST"); ?>/scripts/sync/stream.php?url=<?php echo $_GET['streamer']; ?>&pd="+Math.random(), true);
        xmlhttpqq.send(null);

	

}
<?php

if($_GET['streamer']!=""){
echo " getdataps(); ";
}

?>




function triggeredto() {
        if ((xmlhttpto.readyState == 4) && (xmlhttpto.status == 200)) {
                dosd = document.getElementById('ifrmy');
                //dosd.innerHTML=xmlhttpto.responseText;
                reddytopm=1;
        }
}


	
function getdatat(dest) {
	
	xmlhttpto=null;
	xmlhttpto = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
	
	xmlhttpto.onreadystatechange = triggeredto;
	xmlhttpto.open("GET", dest);
	xmlhttpto.send(null);
}




</script>
<head>
<link   rel='stylesheet' type='text/css' href='styles.css'/>
<title id=title name=title >Javaimagephp - Animation App. for Slideshow and real-time Visualization</title>
<meta name="google-site-verification" content="bsBLUsCnvoyOrptUvY5P8b3lfnyKPDha6qQxRgcE_p4" />
</head>
<?php



exec("echo title > scripts/sync/mptitle");
?>
<?php
 
if($_GET['width']>0){
	$wv=$_GET['width'];
	$hv=$_GET['height'];

	$wvl=$_GET['width'];
	$hvl=$_GET['height'];
}else{
	$wv=640;
	$hv=360;

	$_GET['width']=640;
	$_GET['height']=360;

	$wvl=640;
	$hvl=360;

	$_GET['width']=640;
	$_GET['height']=360;
}

/*Unique Signature : Waves, Lines and dots of art */
exec("java Signature 1400 900 28 javaimagephp.jpg 0 0 0");
exec("java Signature 1400 900  28 pictures/javaimagephp.jpg 0 0 0");



if($_GET['song']=="yes"){
	echo "
	<embed width=0 id=fx  height=0 ></embed>
	<div id=ins><embed  id=instrument src=''  loop=true repeat=false  width=0 height=0></embed></div>
	<div id=sou><embed  id=sound    width=0 height=0></embed></DIV>
	<div id=voc><embed  id=vocal   loop=false repeat=false width=0 height=0></embed></div>
	<div id=str><embed  id=string   loop=true repeat=false width=0 height=0></embed></div>
	<div id=bas><embed  id=base   loop=true repeat=false width=0 height=0></embed></div>";
}
?>

<script type='text/javascript'>

	var bases = new Array();
	var drums = new Array();
	var instruments = new Array();
	var samples = new Array();
	var vocals = new Array();
	var silent = new Array();	
	var ldate=new Date();
	var nowin=(60*60*ldate.getHours())+(ldate.getMinutes()*60)+ldate.getSeconds();

        var xmlhttpz = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
        var xmlhttpxt = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");


<?php
	/*Function To download  some default Music/Sound Instruments*/
	function loadSound($dir, $arr, $snn){


		if($arr=="drums"){

			$rt=scandir("sound/drums");
			for($u=0;$u<count($rt);$u++){
				if($rt[$u]=="." || $rt[$u]==".."){
				}
				else{
				unlink("sound/drums/".$rt[$u]);
				}
			}

				for($i=1;$i<3;$i++){	
	                        $pg = file_get_contents("http://".getenv("HTTP_HOST")."/sound/getDrum.php?style=".$_GET['drums']);
                	        
                	        	copy($pg, "sound/drums/drum.".$i.".mp3");
				}
	
		}




                if($arr=="samples"){

                        $rt=scandir("sound/samples");
                        for($u=0;$u<count($rt);$u++){
                                if($rt[$u]=="." || $rt[$u]==".."){
                                }
                                else{
                                @unlink("sound/samples/".$rt[$u]);
                                }
                        }

                                for($i=1;$i<4;$i++){
                                $pg = file_get_contents("http://".getenv("HTTP_HOST")."/sound/getSynth.php?style=nnnnnnnn");

                                        @copy($pg, "sound/samples/synth.".$i.".mp3");
                                }

                }



		$dirD = scandir($_SERVER['DOCUMENT_ROOT'].'/'.$dir);
		$tl = 0;
		$cs="";
		$host=getenv('HTTP_HOST');	
		$dirj=$_SERVER['DOCUMENT_ROOT']."/scripts/java/";

		for($i=0;$i<count($dirD);$i++){
			$extr= explode(".", $dirD[$i]);
			$ext= $extr[(count($extr)-1)];
			
			if(($dirD[$i]=="." || $dirD[$i]=="..")  ){
			}
			else{

				if($ext=="php"){
				$datas = file_get_contents("http://".$host."/".$dir."/".$dirD[$i]);
				$inst = str_replace(".php", ".mp3", $dirD[$i]);
				$datart=str_replace("\n", "", $datas);	
				if(file_exists($_SERVER['DOCUMENT_ROOT']."/".$dir."/".$inst) ){	
				}
				else
				{
					$cs=$cs." java -cp \"".$dirj."\" ToolsImage ".$datart." \"".$_SERVER['DOCUMENT_ROOT']."/".$dir."/".$inst."\" & ";
					echo " ".$arr."[".$tl."]='http://".$host."/".$dir."/".$inst."'; \n";
					$tl++;
				}		
				}
				else{
				echo " ".$arr."[".$tl."]='http://".$host."/".$dir."/".$dirD[$i]."'; \n";
				$tl++;
				
				}							
			}
		}
		
	if($arr=="vocals"){
		$wwo = explode(";", $snn);
		for($p=0;$p<count($wwo);$p++){
		
		if($_GET['l']!=""){
		$langu=$_GET['l'];
		}
		else{
		$langu="en";
		}
		
	
		//$lon = explode("-", $langu);
		$defen= file_get_contents("http://".getenv("HTTP_HOST")."/scripts/php/trans.php?q=".urlencode($wwo[$p])."&lang=".$_GET['lang']);
		$sl="\"";
		$defen = urlencode($wwo[$p])." ". str_replace($sl,"'", $defen); 
		
		if(strlen($defen)>200){
		$wor=substr($defen, 0, 200);
		}
		else{
		$wor = $defen;
		}
		

		$googl="https://translate.google.com/translate_tts?ie=UTF-8&q=".str_replace("\n", "", str_replace(" ", "%20", $wor ))."&tl=".$_GET['lang']."&client=tw-ob";
$w="curl '".$googl."' -H 'Referer: http://translate.google.com/' -H 'User-Agent: stagefright/1.2 (Linux;Android 5.0)' > ".$_SERVER['DOCUMENT_ROOT']."/sound/vocals/defenition.".$p.".mp3";
$file = fopen("/var/www/html/sound/praat.sh", "w");
fwrite($file, $w);
fclose($file);
chmod("/var/www/html/sound/praat.sh", 0777);
exec("/var/www/html/sound/praat.sh");



		
		///ditendat
		//copy("http://tts-api.com/tts.mp3?q=".urlencode($wor), $_SERVER['DOCUMENT_ROOT']."/sound/vocals/defenition.".$p.".mp3");

		




	}
		
	}	
	return $cs;
	}


	if($_GET['soundfx']!=""){
	
	$csj= loadSound("sound/drums", "drums", "");
	$csj.=loadSound("sound/vocals", "vocals", $_GET['soundfx']);
	$csj.=loadSound("sound/samples", "samples", $_GET['soundfx']);
	$csj.=loadSound("sound/bases", "bases",0, "");
	$csj.=loadSound("sound/instruments", "instruments", 0, "");
	$csj.=loadSound("sound/silent", "silent", 0, "");
	$musicr=substr($csj, 0 , (strlen($csj)-2));

}


	/*Actual Download of Music Samples */
	if(strlen($musicr)>0 && $_GET['song']=="yes"){
		exec($musicr);
	}	
	
	
	if($_GET['soundfx']!=""){
		@mkdir("sound/searched");
		@mkdir("sound/samples");
		@mkdir("sound/vocals");
		@mkdir("sound/instruments");
		@mkdir("sound/drums");
		@mkdir("sound/silent");
		$dirj=$_SERVER['DOCUMENT_ROOT']."/scripts/java/";



		@mkdir("sound/searched");
		@mkdir("sound/extra");

		if($_GET['soundfx']!=""){
			
	$inst=0;
			$tt=explode(";", $_GET['soundfx']);
			for($tu=0;$tu<count($tt);$tu++){

				$tr= translate($tt[$tu], $_GET['lang'], "en");

				if(file_exists("c:\windows")){
				
				
					$pg = file_get_contents("http://www.ogena.nl/scripts/php/sound.php?keywords=".urlencode($tr)."&list=yes");
				}
				else{


   $pg = file_get_contents("http://www.ogena.nl/scripts/php/sound.php?keywords=".urlencode($tr)."&list=yes");

				}				
				$list = str_replace("\n", "", $pg);
				$itt = explode("<br>", $list);
				for($tv=0;$tv<2;$tv++){
					$datart = str_replace("\n", "", $itt[$tv]);
					$extt = explode(".", $datart);
					$ext = $extt[(count($extt)-1)];
					@copy($datart, "sound/searched/melodyinstr.".$inst.".".$ext);
					$inst++;
				}
			}

		

			$pg = file_get_contents("http://www.ogena.nl/scripts/php/sound.php?keywords=".urlencode($_GET['melody'])."&list=yes");
							$list = str_replace("\n", "", $pg);
				$itt = explode("<br>", $list);
				for($tv=1;$tv<2;$tv++){
					$datart = str_replace("\n", "", $itt[$tv]);
					$extt = explode(".", $datart);
					$ext = $extt[(count($extt)-1)];
					@copy($datart, "sound/tuneTemp/melodyinstr.".$inst.".".$ext);
					$inst++;
				}









		}
		




		$snn=$_GET['soundfx']; 

	
		$ssound = explode(";", $snn );		
		for($i=0;$i<count($ssound); $i++){
			$cs0="";
		
			$pg = file_get_contents("http://ogena.nl/scripts/php/sound.php?keywords=".urlencode($ssound[$i])."&list=yes&number=4");
			$list = str_replace("\n", "", $pg);
			$itt = explode("<br>", $list);
			
			for($n=0;$n<count($itt);$n++){
				$datart = str_replace("\n", "", $itt[$n]);
				$extt = explode(".", $datart);
				$ext = $extt[(count($extt)-1)];
				$cs0=$cs0." java -cp \"".$dirj."\" ToolsImage ".$datart." \"".$_SERVER['DOCUMENT_ROOT']."/sound/melody/sample".$n.".".$i.".".$ext."\" &  ";
			}
			exec($cs0);			
		}


	
	}
	exec('echo 0 > images/imcnt');
?> 














function onerr(){
}

function triggeredx() {
	if ((xmlhttpz.readyState == 4) && (xmlhttpz.status == 200  )) {
		trf0= ""+xmlhttpz.responseText;
	
		cfrai = 100000+parseFloat(trf0);
		if(cfrai>100000){
			cfra = cfrai;
			__oldcfra = cfra;

		}
		else{
			cfra=  __oldcfra;
		}

		

		
	}
}


function triggeredxt()
{
	if ((xmlhttpxt.readyState == 4) && (xmlhttpxt.status == 200)) {
	tt =xmlhttpxt.responseText;
	if(tt.length>2){
		infoo = tt;
	}
	}
}


var zxmlhttp = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
	

function zetdata(dest){

	zxmlhttp = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
	
	zxmlhttp.onreadystatechange = ztriggered;
	zxmlhttp.open("GET", dest, true);
	zxmlhttp.send(null);


}
var totdan=0;
function getdataz() {


totdan++;

		
		xmlhttpz = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
		


	xmlhttpz.onreadystatechange = triggeredx;


                        xmlhttpz.open('GET', 'http://<?php echo getenv("HTTP_HOST"); ?>/images/imcnt?aw='+totdan);


xmlhttpz.send(null);


	//xmlhttpxt = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
	//xmlhttpxt.onreadystatechange = triggeredxt;
	//xmlhttpxt.open('GET', '/scripts/sync/mptitle?q='+totdan);
	//xmlhttpxt.send(null); 


setTimeout("getdataz()", 2000);
	
}





function triggeredy() {
}

var drcc=0;
var noMo=false;
</script>


<div id='soux'></div>
<div id="quote">
<img src='/javaimagephp.jpg' name=slidex id=slidex onerror='splashRestore()'>
<div id=txt>
</div>
<div id='speek'></div>
<?php

/*More Javascript Settings, Variables*/
$nrOfFrames  = $framerate;


$stp="
	<script type='text/javascript'>
	var framesEffect=".$framerate."
	var srcOrgFrames=\"".$srcOrgFramessrcOrgFrames."\"
	var ready=true
	var maxTimeOut = ".$maxTimeOut.";
	var maxTimeOutcnt = 0;
	</script>
	";
	echo $stp;
?>




<script type="text/javascript">
/* Kick Start Slide show starts here*/
rrd="xx";
var order=true;
var wypiwyg = wypiwyg();


var upda=false;






function slideitx(){


	if(can>1 && upda==false){
upda=true;
updateIt();
}


	reddy=true;	
	var tatstr="..";
	fpss=parseFloat("0"+fps).toFixed(2);
	if(reddy==true){
		reddyy = "Ready.";
	}
	else{
		reddyy = "Rendering...";
	}
	
	
		<?php
		if($_GET['time']!="") {
		echo "readTime=".$_GET['time'].";"; 
		}
		?>
if(readTime==0){
readTime=1;
}
		tota = 100*(cfra-100000)/( readTime*framesEffect*3/5)   ;
		
		

		
		tatstr =tota.toFixed(0)+"%" ;
		totpercent = tota;
		
		if(finit==true){
		totpercent=100;
		}
		
		totDone = mct;
		totFrames = Math.ceil(readTime*framesEffect*3/5);
		
		totFramesWaiting = (totFrames-(cfra-100000));
		
		if(fps==0){
		
		fps=1;
		}
		secswaiting = Math.floor(totFramesWaiting/fps);
		
		
		restmin= Math.floor(secswaiting/60);
		restSec= secswaiting%60;
		
		progress=tota.toFixed(0) + "%";
		
		if(restSec<10)
		{
			tatstr =tota.toFixed(0)+"% , ETA: "+restmin+":0"+restSec ;
		}
		else{
			tatstr =tota.toFixed(0)+"% , ETA: "+restmin+":"+restSec ;
		}
		
		if((tota>=98 && tota<150) || finit==true){
		tatstr = " Finishing Video .. ";
		noMo=true;
		}	


	<?php
/*Zooming In And Concatinate Image Frames*/
copy($_SERVER['DOCUMENT_ROOT'].'/scripts/sync/__processRequest00Frames.php', $_SERVER['DOCUMENT_ROOT'].'/images/frames/__processRequest00Frames.php');
copy($_SERVER['DOCUMENT_ROOT'].'/scripts/sync/__processRequest00Sound.php', $_SERVER['DOCUMENT_ROOT'].'/images/frames/__processRequest00Sound.php');
?>
	
<?php
	
	if($thethesnd!="" || $_GET['time']!="" || $_GET['soundfx']!=""){
	}
	else{
	echo " tatstr =''; ";
	echo " finit==false; ";
	echo " totpercent = 0; ";
	
	}
	
?>
	
	/*Information on the Browser: Window Title*/	
	itit=  infoo+ " "+tatstr + " ("+fpss+" fps.  By Ben Massoud (R)";
	document.title = itit;

	if(secst==false){
		secst=true;
		seco();
		
	}
	
	var plop='<?php echo urlencode($oldp."".$photos);?>';
	//if(newpnew!=""){
	//plop=newpnew;
	//}
	
	
	
	if((reddytopml==1 && finit==false) && noMo==false){

		if(totpercent > 99){
			
					getdatarr('scripts/php/jip-scripts.php?lang=<?php echo $_GET['lang']; ?>&free='+wypiwyg+'&remote_addr=<?php echo $_SERVER['REMOTE_ADDR']; ?>&imgnr=<?php echo $_GET['imgnr'];  ?>&imgsz=<?php echo $_GET['imgsz'];  ?>&ar=no&_br=<?php echo $_br; ?>&_bg=<?php echo $_bg; ?>&_bb=<?php echo $_bb; ?>&b=f&stream=<?php echo urlencode($_GET['streamer']); ?>&music=<?php echo $_GET['song']; ?>&time=<?php echo $_GET['time']; ?>&reed=&nrOffSummaryImg=<?php echo $nrOffSummaryImg; ?>&frames='+framesEffect+'&ifId=<?php echo $_GET['ifId']; ?>&download=<?php echo $_GET['download']; ?>&filter=<?php echo $_GET['filter']; ?>&drive=<?php echo $_GET['drive']; ?>&directory=<?php echo $_GET['directory']; ?>&cat=<?php echo urlencode($_GET['cat']); ?>&soundfx=<?php echo $_GET['soundfx']; ?>&checkYId=<?php echo $checkYId; ?>&fx=<?php echo $_GET['fx']; ?>&width=<?php echo $_GET['width']; ?>&record=<?php echo $_GET['record']; ?>&height=<?php echo $_GET['height']; ?>&source=<?php echo $_GET['source']; ?>&p='+plop+'&prgrss='+progress+'&dsd='+10000*Math.random(),'quote')
	
	
	}
		else{

		
	
			getdatarr('scripts/php/jip-scripts.php?lang=<?php echo $_GET['lang']; ?>&free='+wypiwyg+'&remote_addr=<?php echo $_SERVER['REMOTE_ADDR']; ?>&imgnr=<?php echo $_GET['imgnr'];  ?>&imgsz=<?php echo $_GET['imgsz'];  ?>&ar=no&_br=<?php echo $_br; ?>&_bg=<?php echo $_bg; ?>&_bb=<?php echo $_bb; ?>&b=f&stream=<?php echo urlencode($_GET['streamer']); ?>&music=<?php echo $_GET['song']; ?>&time=<?php echo $_GET['time']; ?>&reed=&nrOffSummaryImg=<?php echo $nrOffSummaryImg; ?>&frames='+framesEffect+'&ifId=<?php echo $_GET['ifId']; ?>&download=<?php echo $_GET['download']; ?>&filter=<?php echo $_GET['filter']; ?>&drive=<?php echo $_GET['drive']; ?>&directory=<?php echo $_GET['directory']; ?>&cat=<?php echo urlencode($_GET['cat']); ?>&soundfx=<?php echo $_GET['soundfx']; ?>&checkYId=<?php echo $checkYId; ?>&fx=<?php echo $_GET['fx']; ?>&width=<?php echo $_GET['width']; ?>&record=<?php echo $_GET['record']; ?>&height=<?php echo $_GET['height']; ?>&source=<?php echo $_GET['source']; ?>&p='+plop+'&prgrss='+progress+'&dsd='+10000*Math.random(),'quote')
	

	}
	

	
		effectcnt++;
		
		can++;
		maxTimeOutcnt=0;
	}
	pairNr1++;








}
slideitx();
/*End Slide Function, One of two*/



function slideitxp(){

}



var vidgedaan=false;

























/*Javscript Memory Management Of Images*/
var lurllo = "/javaimagephp.jpg";
var direc=1;
var mtmr = 0;
var newImage = new Image();
var nnewImage = new Image();

newImage.src=lurllo;
var lurll="/javaimagephp.jpg";
var nm = new Image();
var speedad=0;
var thecorrect=1;



var startedfbt =false;
var urlz = new Array();

function mctt(){
mct++;
}

/*Simple Buffering*/
function correctIt(){
/*
	if(mct>0 && cfra>0){
		facc=1; //Math.max(1, Math.round((cfra-100000)/(mct-100000+1)));
	}
	*/
}
var urll="";
var gra=1;
var oldcf=0;
var timm=0;
var otstst=0;
var facc=1;
var imoo=document.getElementById('slidex');
otstst=tstst;
var eop=-1;
var somecc=1;
var avdiv=0;
var avdivc=1;

var cframin15s=0;
var seconden1s=0;
var slos=0;


/*Frame Rate Calculation And Refreshing of Image Frames*/
function updateIt(){
	somecc = 10+(4*(cfra-99999)/(mct-99999+10));
	psp=Math.floor(somecc);
	div=(cfra-99999)-(mct-99999);
	
		
	
	avdivvs = avdiv*(avdivc-1);
	avdiv=(avdiv*(avdivc-1))+div;
	avdiv=avdiv/(avdivc+1);
	avdivc=avdivc+1;

	lastto=((mct-99999)*div/(mct-99999+1))-2;

	if( newImage.complete && (cfra- mct)>0 ) {
		urll= "http://<?php
		$mypp=$oldp."".$photos;
		$mypp =str_replace(" ", "_", $mypp);
		 echo getenv("HTTP_HOST")."/images/0000frames".substr(str_replace(" ", "_", str_replace(":", 
		"_", str_replace(";", "_", $mypp))), 0, min(20, strlen($mypp)))."."; ?>"+Math.ceil((0*avdiv)+mct)+".jpg";
		imoo.src=urll;
		newImage.src = urll;

		

		mct++;
		timm=0;
	}
	else{
		otstst = tstst+1;
		timm++;
	}

	divo=div;
	if((cfra-99999)>div){
		divo=div;
	}

	fps=(cfra-99999+divo)/(seconden+1);
	
	tm = Math.floor(1000/fps);

	fg=(seconden%15);
	if(fg==0){
		cframin15s = cfra;
	}
	

	if(cframin15s == cfra){
		
		if((seconden1s+1)<=seconden){
			seconden1s=seconden+1;
			slos=slos+1;
		}
		
	}

	if(cframin15s != cfra){
		cframin15s = cfra;
		slos=0;

	}
	ttt=div/(slos+1);
	rr=Math.floor(1000/ttt);


	
	
	if(seconden<10){

		setTimeout('updateIt()', Math.floor(   50    ));
	}
	else{
	setTimeout('updateIt()', Math.floor(   tm+rr    ));
	
	}
}






</script>
</div>
<div id=tit width=0 height=0>
</div>

<script type='text/javascript'>
function getCurrentTitle(){       //Keyword, or media Information
	d=document.getElementById('tit');
	infoo = ""+d.innerHTML;
	setTimeout("getCurrentTitle()", 6000);
}
</script>
<script type='text/javascript'>
var ifd= "";
var begun=false;
function wach(){

if(can==1 && begun==false){
	begun=true;
}
else{
setTimeout("wach()", 1000);
}
}
wach();
</script>
<?php
/*Zooming In And Concatinate Image Frames*/
copy($_SERVER['DOCUMENT_ROOT'].'/scripts/sync/__processRequest00Frames.php', $_SERVER['DOCUMENT_ROOT'].'/images/frames/__processRequest00Frames.php');
copy($_SERVER['DOCUMENT_ROOT'].'/scripts/sync/__processRequest00Sound.php', $_SERVER['DOCUMENT_ROOT'].'/images/frames/__processRequest00Sound.php');






	$mypp=$oldp."".$photos;
	

$mypp =str_replace(" ", "_", $mypp);

   $_GET['pname'] = substr(str_replace(" ", "_", str_replace(":", "_", str_replace(";", "_", $mypp))), 0, min(20, strlen($mypp)));

		$dir=$_SERVER['DOCUMENT_ROOT']."/scripts/java";
		$fn=$_SERVER['DOCUMENT_ROOT']."/images/frames/q00frames" . $_GET['pname'];
		$tn=$_SERVER['DOCUMENT_ROOT']."/images/0000frames" . $_GET['pname'];
		$tnr=$_SERVER['DOCUMENT_ROOT']."/images/imcnt";
	
		$file=fopen("images/frames/__processRequest00Frames.bat", 'w');
		
		$filename= $_SERVER['DOCUMENT_ROOT']."/images/frames/__processRequest00Frames";
		
		$you = "";
		if($checkYId!=""){
		$you="youtube-dl  -o images/frames/temp ".$checkYId. " && ffmpeg -i temp.* myClip_.mp3 && cp myClip_.mp3 myClip.mp3 && copy myClip_.mp3 myClip.mp3 && echo 2 > strec && rm dls.sh && del dls.bat";
		}


$nrOfFrames  = $framerate;

$nrOfFramesWait = round((pow(M_E,2.0)*$nrOfFrames));

	$rqc=$nrOfFramesWait+$nrOfFrames-6;	
	fwrite($file, "java  -cp \"".$dir."\" ImagesZoom \"".$fn. "\" ".$wv." ".$hv." \"".$tn."\"  ".$rqc." - 1 1 1 1 1 1 1 0 ".$rqc." 0 0 \"".$filename."\"" ." \"".$tnr."\" 255 255 255");
		
		
		fclose($file);





?>
<?php 
$mypp=$oldp."".$photos;
$mypp =str_replace(" ", "_", $mypp);
echo "<script type='text/javascript'> var framesName='images/0000frames".substr(str_replace(" ", "_", str_replace(":", "_", str_replace(";", "_", $mypp))), 0, min(20, strlen($mypp))).".'; </script>"; 

@mkdir($_SERVER['DOCUMENT_ROOT']."/images/frames/frames");
$ec=scandir($_SERVER['DOCUMENT_ROOT']."/images/frames/frames");
for($i=0;$i<count($ec);$i++){
	if($ec[$i]=='.' || $ec[$i]=='..'){
		
	}
	else{
		@unlink($_SERVER['DOCUMENT_ROOT']."/images/frames/frames/".$ec[$i]);
	}
	
}
$you="cd \"".$_SERVER['DOCUMENT_ROOT']."/images/frames/frames\" \nyoutube-dl   ".$checkYId. " \n ffmpeg -i * myClip.mp3 \n copy myClip.mp3 ../ \n echo 2 > strec \n del dls.bat";


				$youx="youtube-dl  --extract-audio  --audio-quality 4 --audio-format mp3 -o myClip.mp3 ".$checkYId. "  \necho 2 > strec \n ";

$yoush = " killall youtube-dl & youtube-dl  --extract-audio  --audio-quality 4 --audio-format mp3 -o myClip.mp3 ".$checkYId. "  &  echo 2 > strec ";

$you="cd ".$_SERVER['DOCUMENT_ROOT']."/images/frames \n youtube-dl --audio-quality 4  --extract-audio --audio-format mp3 -o myClip_.mp3 ".$checkYId. " \n ffmpeg -i myClip_.mp3 myClip__.mp3 \n copy myClip__.mp3 myClip.mp3 \n echo 2 >strec \n del dls.bat";
$you2="cd ".$_SERVER['DOCUMENT_ROOT']."/images/frames \n youtube-dl --audio-quality 4  --extract-audio --audio-format mp3 -o myClip_.mp3 ".$checkYId. " \n ffmpeg -i myClip_.mp3 myClip__.mp3 \n cp myClip__.mp3 myClip.mp3 \n echo 2 >strec \n rm dls.sh";

$you3=""; //"cd \"".$_SERVER['DOCUMENT_ROOT']."/temp\" \n youtube-dl   -o temp.o  ".$checkYId. "  \n ffmpeg -ss 0:1:1 -t 0:0:4 -i temp.o.AVI  image%d.jpg  \n\n ffmpeg -ss 0:1:1 -t 0:0:4 -i temp.o.webm  image%d.jpg  \n ffmpeg -ss 0:1:1 -t 0:0:4 -i temp.o.flv  image%d.jpg  \n ffmpeg -ss 0:2:1 -t 0:0:4 -i temp.o.flv  iimage%d.jpg  \n ffmpeg -ss 0:2:1 -t 0:0:4 -i temp.o.AVI  iimage%d.jpg   \n ffmpeg -ss 0:2:1 -t 0:0:4 -i temp.o.mkv  iimage%d.jpg   \n ffmpeg -ss 0:2:1 -t 0:0:4 -i temp.o.webm  iimage%d.jpg ";
$you33=""; //"cd \"".$_SERVER['DOCUMENT_ROOT']."/temp\" \n youtube-dl   -o temp.o  ".$checkYId. "  \n ffmpeg -ss 0:1:1 -t 0:0:4 -i temp.o.AVI  image%d.jpg \n ffmpeg -ss 0:1:1 -t 0:0:4 -i temp.o.webm  image%d.jpg \n ffmpeg -ss 0:1:1 -t 0:0:4 -i temp.o.flv  image%d.jpg  \n ffmpeg -ss 0:2:1 -t 0:0:4 -i temp.o.flv  iimage%d.jpg  \n ffmpeg -ss 0:2:1 -t 0:0:4 -i temp.o.AVI  iimage%%d.jpg  \n ffmpeg -ss 0:2:1 -t 0:0:4 -i temp.o.mkv  iimage%%d.jpg  \n ffmpeg -ss 0:2:1 -t 0:0:4 -i temp.o.webm  iimage%%d.jpg ";





$theSound=$checkYId;	


		
		if($checkYId!=""){
		$file = fopen('images/frames/dls.bat', 'w');
		fwrite($file, $you);
		fclose($file);

		
		$file1 = fopen('images/frames/dls2.bat', 'w');
        fwrite($file1, $you33);
        fclose($file1);
        chmod('images/frames/dls2.bat', 0777 );
				
		
		$file = fopen('images/frames/dls.sh', 'w');
		fwrite($file, $you2);
		fclose($file);		
		chmod('images/frames/dls.sh', 0777 );


                $file1 = fopen('images/frames/dls2.sh', 'w');
                fwrite($file1, $you3);
                fclose($file1);
                chmod('images/frames/dls2.sh', 0777 );


		}



?>
<script type='text/javascript'>
try {
	var xmlhttpxx = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
	xmlhttpxx.onreadystatechange = triggeredxx;
	} catch (e) {
}
try {
	var xmlhttpxxra = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
var xmlhttpxxrad = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
	} catch (e) {
}

try {
	var xmlhttpxxrs = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");

	} catch (e) {
}




var iistarted=false;
function okax(){
	if(iistarted==false){
		
		xmlhttpxxra = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
		xmlhttpxxra.open("GET", "/images/frames/__processRequest00Frames.php?startFrames=0&dirClip=&frameRate="+framesEffect+"&duration="+readTime+"&framesName="+framesName+"&qwq="+(1000*Math.random()));
		xmlhttpxxra.send(null);	
	
	
		xmlhttpxxrs = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
		xmlhttpxxrs.open("GET", "/images/frames/__processRequest00Sound.php?startFrames=0&dirClip=&frameRate="+framesEffect+"&duration="+readTime+"&framesName="+framesName+"&pqwq="+(1000*Math.random()));
		xmlhttpxxrs.send(null);
	}
}


	var xmlhttpxxd = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
	xmlhttpxxd.onreadystatechange = triggeredxxrd;

var hasBegun=false;

function triggeredxxrd(){
	if ((xmlhttpxxd.readyState == 4) && (xmlhttpxxd.status == 200)) {
			daxx = parseFloat(xmlhttpxxd.responseText);
	
			if(daxx==1){

				okax();
				hasBegun  =true;
				
				
			}
			else{
			hasBegun  =false;
				
			}
						
	}
}


function initOk(){
	if(hasBegun==false){
		xmlhttpxxd = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
		xmlhttpxxd.onreadystatechange = triggeredxxrd;
		xmlhttpxxd.open("GET", "/scripts/sync/check.php?qwq="+(1000000*Math.random()));
		xmlhttpxxd.send(null);
		setTimeout("initOk()", 3000);
hasBegun=true;
		}else{

	}
}
initOk();


</script>
<?php
if(   (file_exists($thethesnd) || strpos($thethesnd, "://")>0)  &&  $thethesnd!=""){
	$_SESSION['snd']="hsound";	
	$time = @file_get_contents("http://".getenv("HTTP_HOST")."/sound/snd.php?request=".urlencode($thethesnd));
	
	$time = @file_get_contents("http://".getenv("HTTP_HOST")."/images/time?request=".urlencode($thethesnd));
	echo "<script type='text/javascript'>readTime=".$time."; </script>";
}
?>
<div id='ifrmx'></div>
<div id='ifrmy'></div>
<div id='tmpSnd'></div>
<script type='text/javascript'>
var checkSoundd1 = false;

var progress = "";
	var xmlhttpsxq = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");

function triggeredsa()
{
	if ((xmlhttpsxq.readyState == 4) && (xmlhttpsxq.status == 200)) {

	tt =parseFloat(xmlhttpsxq.responseText);
	
	if(tt==2 && checkSoundd==false && isPlaying==false){
		//alert("Okaa");
		checkSoundd = true;
		souxii = document.getElementById('soux');
		var nua = navigator.userAgent;
		var is_android = (nua.indexOf('Android ') > -1 || nua.indexOf('AppleWebKit') > -1);
		if(is_android || true){
			//red="<audio id='' src='/images/frames/myClip.mp3?p="+Math.random()+"'   width='1' height='1' autoplay='autoplay' 				bgcolor='white'  loop='loop' audio='true'></audio>" ;
			//souxii.innerHTML=red;
			playAudio("images/frames/myClip.mp3?p="+Math.random());
			
			}
		else{
			red="<embed  id='sc' src='/images/frames/myClip.mp3?p="+Math.random()+"' style='width:2;height:1;visibility:hidden'><embed>";
			souxii.innerHTML=red;
		}	
		isPlaying=true;
						
		}
	}
}

var xmlhttpsxq2 = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
	

function triggeredsa2()
{
	if ((xmlhttpsxq2.readyState == 4) && (xmlhttpsxq2.status == 200)) {

	 var att=xmlhttpsxq2.responseText;
	//alert('a');
	if(att.substr(0, 1)=="2" && checkSoundd1==false && isPlaying==false){
		//alert('b');
		checkSoundd1 = true;
		souxii = document.getElementById('soux');
		var nua = navigator.userAgent;
		var is_android = (nua.indexOf('Android ') > -1 || nua.indexOf('AppleWebKit') > -1);
		if(is_android || true){
				playAudio("images/frames/myClip.mp3?p="+Math.random());
			}
		else{
			red="<embed  id='sc' src='/images/frames/myClip.mp3' style='width:2;height:1;visibility:hidden'></embed>";
			souxii.innerHTML=red;
		}	
		isPlaying=true;
						
		}
	}
}


<?php

if($_GET['streamer']!=""){

echo "checkSoundd1 = true;   checkSoundd = true; ";

}

?>
	 
	   
	
	function checkSound(){
xmlhttpsxq=null;
 xmlhttpsxq = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
	xmlhttpsxq.onreadystatechange = triggeredsa;
	xmlhttpsxq.open("GET", 'http://<?php echo getenv("HTTP_HOST"); ?>/sound/exists.php?file=images/frames/myClip.mp3&other=images&output=strec&value=2rn='+Math.random());
	
	xmlhttpsxq.send(null);


	if(checkSoundd==false){
	setTimeout("checkSound()", 5000);
	}
	
}


	

	   
	//var chkSoundd = false;
	
	function checkSound2(){
	xmlhttpsxq2=null;
		 xmlhttpsxq2 = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
	
		xmlhttpsxq2.onreadystatechange = triggeredsa2;
	xmlhttpsxq2.open("GET", 'images/frames/strec?oi='+Math.random());
	xmlhttpsxq2.send(null);


	if(checkSoundd1==false){
	setTimeout("checkSound2()", 4250);
	
	}
	}


<?php
if($thethesnd!="" || $_GET['soundfx']!=""){	
echo "checkSound(); 
checkSound2();
";
}
?>
function triggeredsaq()
{
	if ((xmlhttpsxqq.readyState == 4) && (xmlhttpsxqq.status == 200)) {
	
	}
}





</script>




<div id='extra'>
</div>

<script type='text/javascript'>
var xmlhttpxxct = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");

var foundtm=false;
					
function triggeredxct(){
	if ((xmlhttpxxct.readyState == 4) && (xmlhttpxxct.status == 200 && foundtm==false)) {
		readTime = parseFloat(xmlhttpxxct.responseText);
		if(readTime>30){
			foundtm = false;
		}
						
	}
}	

function onTimerD(){
xmlhttpxxctu=null;
	xmlhttpxxctu = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
	xmlhttpxxctu.onreadystatechange = triggeredxct;
	xmlhttpxxctu.open("GET", "/sound/strect.php?fr="+Math.random());
	xmlhttpxxctu.send(null);

xmlhttpxxct=null;
  	xmlhttpxxct = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
	xmlhttpxxct.onreadystatechange = triggeredxct;
	xmlhttpxxct.open("GET", "/images/time?fr="+Math.random());
	xmlhttpxxct.send(null);
	setTimeout("onTimerD()", 4000);					
}

var xmlhttpxxctux = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP"); 
var ddown=false;
function triggeredxctx(){
        if ((xmlhttpxxctux.readyState == 4) && (xmlhttpxxctux.status == 200)) {
                readTi = parseFloat(xmlhttpxxctux.responseText);
                if(readTi>0 && ddown==false){
         	ddown=true;
<?php
		$snd="";

		if($_GET['tags']==""){
		$_GET['tags']="Funny,very,special,";

                	$tagss = explode(";", $_GET['soundfx']);
                        	for($t=0;$t<count($tagss);$t++){
	                 	$_GET['tags'].=$tagss[$t].",";
        			$snd.=$tagss[$t].", ";           		

     	}
		$ds="";
                        $tagss = explode(" ", $oldp."".$photos);
                                for($t=0;$t<count($tagss);$t++){
                                        $_GET['tags'].=$tagss[$t].",";
		$ds.=$tagss[$t].", ";                        

        }




		}


		if($_GET['description']==""){
		$_GET['description']="Special Animated Animation - ".$ds ." very funny , with music samples of:".$snd . ". Sofware @(ogena.net) " ;
		}

		if($_GET['title-clip']==""){
			$_GET['title-clip']="Funny special Video ".$ds ." very funny audio";
		}
?>

			dc = document.getElementById('quote');               
	alert("The Recording Finished"); dc.innerHTML="<center><a href='<?php echo "/sound/".$_GET['asname']."-".str_replace(";", "_", str_replace(" ","-", $oldp."".$photos)).".AVI"; ?>'><img width=80 src='images/summary15.jpg'><BR>Download Video!</a><BR><BR><BR><aonclick=\"stor('<?php echo "sound/".$_GET['asname']."-".str_replace(";", "_", str_replace(" ","-", $oldp."".$photos)).".webm"; ?>')\" >Use in Studio</a>";



                }

        }
}


<?php

exec("echo 0 > sound/download");

?>
function download(){
xmlhttpxxctux=null;
        xmlhttpxxctux = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
        xmlhttpxxctux.onreadystatechange = triggeredxctx;
        xmlhttpxxctux.open("GET", "/sound/download?fr="+Math.random());
        xmlhttpxxctux.send(null);


setTimeout("download()", 10000);

}
<?php
if($thethesnd!="" || $_GET['soundfx']!=""){
echo "download(); ";
}
?>

				
				




<?php


$mypp=$oldp."".$photos;
	

$mypp =str_replace(" ", "_", $mypp);



if($thethesnd!="" || $_GET['time']!="" ){
 



	$extr="";
	if($_GET['voptions']!=""){
		//$voptions="" ; $_GET['voptions'];
	}
	else{
		//$voptions="" ;"-vcodec copy -qscale 1 ";
	}

$dirs = "/";


$mypp=$oldp."".$photos;
	

$mypp =str_replace(" ", "_", $mypp);
$arf= "images/0000frames".substr(str_replace(" ", "_", str_replace(":", "_", str_replace(";", "_", $mypp))), 0, min(20, strlen($mypp))); 
$ddownl = "sound".$dirs."".$_GET['asname']."-".str_replace(";", "_", str_replace(" ","-", $oldp."".$photos)).".webm";

	if($_GET['nosound']=="yes"){	
		if($thethesnd!="" || $_GET['soundfx']!="" || $_GET['song']!=""){	
			$strfdt= "
			ffmpeg  -framerate ".round(3/5*$framerate)."  -i \"c:".$dirs."program files".$dirs."apache software foundation".$dirs."apache2.2".$dirs."htdocs".$dirs.$arf.".1%%5d.jpg\" -i  \"c:".$dirs."program files".$dirs."apache software foundation".$dirs."apache2.2".$dirs."htdocs".$dirs."images".$dirs."frames".$dirs."myClip.mp3\"    -r ".round(3/5*$framerate)."   -b:v 990k  -cpu-used 5 -threads 4   \"c:".$dirs."Program Files".$dirs."Apache Software Foundation".$dirs."Apache2.2".$dirs."htdocs".$dirs."sound".$dirs."".$_GET['asname']."-".str_replace(";", "_", str_replace(" ","-", $oldp."".$photos)).".webm\"  &&  ffmpeg -i \"c:".$dirs."Program Files".$dirs."Apache Software Foundation".$dirs."Apache2.2".$dirs."htdocs".$dirs."sound".$dirs."".$_GET['asname']."-".str_replace(";", "_", str_replace(" ","-", $oldp."".$photos)).".AVII\"  - \"c:".$dirs."Program Files".$dirs."Apache Software Foundation".$dirs."Apache2.2".$dirs."htdocs".$dirs."sound".$dirs."".$_GET['asname']."-".str_replace(";", "_", str_replace(" ","-", $oldp."".$photos)).".webm\"  \n copy \"c:".$dirs."Program Files".$dirs."Apache Software Foundation".$dirs."Apache2.2".$dirs."htdocs".$dirs."sound".$dirs."".$_GET['asname']."-".str_replace(";", "_", str_replace(" ","-", $oldp."".$photos)).".webm\" \"".$_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/myMedia/Anima".rand(100,999).".webm\" \n echo 2 > \"c:".$dirs."Program Files".$dirs."Apache Software Foundation".$dirs."Apache2.2".$dirs."htdocs".$dirs."sound".$dirs."download\"";
		}
		else{
			$strfdt= "
			ffmpeg  -framerate ".round(3/5*$framerate)."  -i \"c:".$dirs."program files".$dirs."apache software foundation".$dirs."apache2.2".$dirs."htdocs".$dirs.$arf.".1%%5d.jpg\"     ".$voptions."  -r ".round(3/5*$framerate)."   -b:v 990k  -cpu-used 5 -threads 4   \"c:".$dirs."Program Files".$dirs."Apache Software Foundation".$dirs."Apache2.2".$dirs."cgi-bin".$dirs."myClip.AVI\" \nffmpeg  -i  \"c:".$dirs."Program Files".$dirs."Apache Software Foundation".$dirs."Apache2.2".$dirs."htdocs".$dirs."sound".$dirs."".$_GET['asname']."-".str_replace(";", "_", str_replace(" ","-", $oldp."".$photos)).".webm\"  &&  ffmpeg -i \"c:".$dirs."Program Files".$dirs."Apache Software Foundation".$dirs."Apache2.2".$dirs."htdocs".$dirs."sound".$dirs."".$_GET['asname']."-".str_replace(";", "_", str_replace(" ","-", $oldp."".$photos)).".AVII\"  \"c:".$dirs."Program Files".$dirs."Apache Software Foundation".$dirs."Apache2.2".$dirs."htdocs".$dirs."sound".$dirs."".$_GET['asname']."-".str_replace(";", "_", str_replace(" ","-", $oldp."".$photos)).".webm\"  \n copy \"c:".$dirs."Program Files".$dirs."Apache Software Foundation".$dirs."Apache2.2".$dirs."htdocs".$dirs."sound".$dirs."".$_GET['asname']."-".str_replace(";", "_", str_replace(" ","-", $oldp."".$photos)).".webm\" \"".$_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/myMedia/Anima".rand(100,999).".webm\" \n echo 2 > \"c:".$dirs."Program Files".$dirs."Apache Software Foundation".$dirs."Apache2.2".$dirs."htdocs".$dirs."sound".$dirs."download\""; 
		}		
	}
	else{		
		if($thethesnd!="" || $_GET['soundfx']!=""  || $_GET['song']!="" ){	
		$strfdt= "
		ffmpeg  -framerate ".round(3/5*$framerate)."  -i \"c:".$dirs."program files".$dirs."apache software foundation".$dirs."apache2.2".$dirs."htdocs".$dirs.$arf.".1%%5d.jpg\"   -i  \"c:".$dirs."program files".$dirs."apache software foundation".$dirs."apache2.2".$dirs."htdocs".$dirs."images".$dirs."frames".$dirs."myClip.mp3\"        -r ".round(3/5*$framerate)."   -b:v 990k  -cpu-used 5 -threads 4 \"c:".$dirs."Program Files".$dirs."Apache Software Foundation".$dirs."Apache2.2".$dirs."htdocs".$dirs."sound".$dirs."".$_GET['asname']."-".str_replace(";", "_", str_replace(" ","-", $oldp."".$photos)).".webm\"  && ffmpeg -i \"c:".$dirs."Program Files".$dirs."Apache Software Foundation".$dirs."Apache2.2".$dirs."htdocs".$dirs."sound".$dirs."".$_GET['asname']."-".str_replace(";", "_", str_replace(" ","-", $oldp."".$photos)).".AVII\"   \"c:".$dirs."Program Files".$dirs."Apache Software Foundation".$dirs."Apache2.2".$dirs."htdocs".$dirs."sound".$dirs."".$_GET['asname']."-".str_replace(";", "_", str_replace(" ","-", $oldp."".$photos)).".webm\"  \n copy \"c:".$dirs."Program Files".$dirs."Apache Software Foundation".$dirs."Apache2.2".$dirs."htdocs".$dirs."sound".$dirs."".$_GET['asname']."-".str_replace(";", "_", str_replace(" ","-", $oldp."".$photos)).".webm\" \"".$_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/myMedia/Anima".rand(100,999).".webm\" \n echo 2 > \"c:".$dirs."Program Files".$dirs."Apache Software Foundation".$dirs."Apache2.2".$dirs."htdocs".$dirs."sound".$dirs."download\"";
		}
		else{		
		$strfdt= "
		ffmpeg   -framerate ".round(3/5*$framerate)."  -i \"c:".$dirs."program files".$dirs."apache software foundation".$dirs."apache2.2".$dirs."htdocs".$dirs.$arf.".1%%5d.jpg\"  -i  \"c:".$dirs."program files".$dirs."apache software foundation".$dirs."apache2.2".$dirs."htdocs".$dirs."images".$dirs."frames".$dirs."myClip.mp3\"    -r ".round(3/5*$framerate)."   -b:v 990k  -cpu-used 5 -threads 4 \"c:".$dirs."Program Files".$dirs."Apache Software Foundation".$dirs."Apache2.2".$dirs."htdocs".$dirs."sound".$dirs."".$_GET['asname']."-".str_replace(";", "_", str_replace(" ","-", $oldp."".$photos)).".webm\"  && ffmpeg -i \"c:".$dirs."Program Files".$dirs."Apache Software Foundation".$dirs."Apache2.2".$dirs."htdocs".$dirs."sound".$dirs."".$_GET['asname']."-".str_replace(";", "_", str_replace(" ","-", $oldp."".$photos)).".AVII\"   \"c:".$dirs."Program Files".$dirs."Apache Software Foundation".$dirs."Apache2.2".$dirs."htdocs".$dirs."sound".$dirs."".$_GET['asname']."-".str_replace(";", "_", str_replace(" ","-", $oldp."".$photos)).".webm\"  \n copy \"c:".$dirs."Program Files".$dirs."Apache Software Foundation".$dirs."Apache2.2".$dirs."htdocs".$dirs."sound".$dirs."".$_GET['asname']."-".str_replace(";", "_", str_replace(" ","-", $oldp."".$photos)).".webm\" \"".$_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/myMedia/Anima".rand(100,999).".webm\" \n echo 2 > \"c:".$dirs."Program Files".$dirs."Apache Software Foundation".$dirs."Apache2.2".$dirs."htdocs".$dirs."sound".$dirs."download\"";;		
		}		
		
	}
$ddownl = "sound".$dirs."".$_GET['asname']."-".str_replace(";", "_", str_replace(" ","-", $oldp."".$photos)).".webm";
	
	
	
	
	
	

	
	
	
	
	$filof = fopen("c:/program files/apache software foundation/apache2.2/cgi-bin/build.bat", "w");
	fwrite($filof, $strfdt);
	fclose($filof);
	
		$filof = fopen("c:/program files/apache software foundation/apache2.2/htdocs/images/build.bat", "w");
	fwrite($filof, $strfdt);
	fclose($filof);

	if($_GET['nosound']=="yes"){
		$strfdt= "ffmpeg  -framerate ".round(3/5*$framerate)."  -i \"".$_SERVER['DOCUMENT_ROOT']."/images/0000frames".substr(str_replace(" ", "_", str_replace(":", "_", str_replace(";", "_", $mypp))), 0, min(20, strlen($mypp))). ".1%5d.jpg\"    ".$voptions."  \"/var/www/sound/myClip.AVI\" \n
		ffmpeg -i  \"/var/www/sound/myClip.AVI\"   \"".$_SERVER['DOCUMENT_ROOT']."/sound/".$_GET['asname']."-".str_replace(";", "_", str_replace(" ","-", $oldp."".$photos)).".AVI\" \n chmod 777 \"".$_SERVER['DOCUMENT_ROOT']."/sound/".$_GET['asname']."-".str_replace(";", "_", str_replace(" ","-", $oldp."".$photos)).".AVI\" \n chmod 777 \"".$_SERVER['DOCUMENT_ROOT']."/sound/".$_GET['asname']."-".str_replace(";", "_", str_replace(" ","-", $oldp."".$photos)).".AVI\" ";
	}
	else{


		$title=str_replace(";", " ", $oldp."".$photos)." - Original Composition";
		if($_GET['title']==""){

		}
		else{
		$title=$_GET['title']. " (Original Composition)";
		}




		$description= "An original  Video Animation of ".$title ;

		if($_GET['description']!=""){
		$description = $_GET['description'];
		}

		$author = "R Ben Massoud";
		if($_GET['author']!=""){
		$author=$_GET['author'];
		}

		$artist= "R Ben Massoud";
                if($_GET['artist']!=""){
                $artist=$_GET['artist'];
                }


		$year= "Year";


$ddownl = $_SERVER['DOCUMENT_ROOT']."/sound".$dirs."".$_GET['asname']."-".str_replace(";", "_", str_replace(" ","-", $oldp."".$photos)).".webm";
$ddownll = $_SERVER['DOCUMENT_ROOT']."/sound".$dirs."".$_GET['asname']."-".str_replace(";", "_", str_replace(" ","-", $oldp."".$photos)).".webm";


$strfdt= "ffmpeg  -r ".round(3/5*$framerate)." -i \"".$_SERVER['DOCUMENT_ROOT']."/images/0000frames%*.jpg\"     -i  \"".$_SERVER['DOCUMENT_ROOT']."/images/frames/myClip.mp3\"  -cpu-used 5 -threads 4  -b:v  990k -preset ultrafast   ".$voptions." ".$ddownl. " \n cp ".$ddownll." ".$_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/myMedia/Anim".rand(100,999).".webm \n echo 2 > ".$_SERVER['DOCUMENT_ROOT']."/sound/download ";
		$filofl = fopen($_SERVER['DOCUMENT_ROOT']."/images/build.sh", "w");
		fwrite($filofl, $strfdt);
		fclose($filofl);

$ddownl = "sound".$dirs."".$_GET['asname']."-".str_replace(";", "_", str_replace(" ","-", $oldp."".$photos)).".webm";

	
		@chmod($_SERVER['DOCUMENT_ROOT']."/images/build.sh", 0777);
	}

	if($_GET['nosound']!="yes"){
		$soundQuality="13";
		if($_GET['soundQuality']!=""){
		$soundQuality =  $_GET['soundQuality'];
		}

		$tm = file_get_contents("http://".getenv("HTTP_HOST")."/images/time");
		
		if($thethesnd!=""  || $_GET['soundfx']!="" ){
		
		
		if($_GET['youtubeId']!=""){
		
			$extr ="

			";
		}
		}
		else{
		if($_GET['youtubeId']!=""){
			$extr ="

			";
			
		}
		
		}

		$extlr ="youtubee-dl -f ".$soundQuality."  -o ".$_SERVER['DOCUMENT_ROOT']."/sound/tmp.flv \"https://www.youtube.com/watch?v=".$_GET['youtubeId']."\" \nffmpeg -i  ".$_SERVER['DOCUMENT_ROOT']."/sound/tmp.flv      ".$_SERVER['DOCUMENT_ROOT']."/images/frames/myClip.mp3\nchmod 777 ".$_SERVER['DOCUMENT_ROOT']."/images/frames/myClip.mp3 \necho 2 > ".$_SERVER['DOCUMENT_ROOT']."/images/frames/strec  \nffmpeg -i  ".$_SERVER['DOCUMENT_ROOT']."/sound/tmp.flv  -vf  scale=".$wv.":".$hv." ".$_SERVER['DOCUMENT_ROOT']."/images/clipframes/clipyou%d.jpg \nchmod 777 ".$_SERVER['DOCUMENT_ROOT']."/sound/strec\nrm ".$_SERVER['DOCUMENT_ROOT']."/scripts/sync/temp.sh\n";
		if(file_exists("/var/www"  && $_GET['youtubeId']!="")){
			$filel=fopen($_SERVER['DOCUMENT_ROOT']."/scripts/sync/temp.sh", "w");
			@chmod($_SERVER['DOCUMENT_ROOT']."/scripts/sync/temp.sh", 0777);
			fwrite($filel, $extlr);
			fclose($filel);
			exec($extlr);

		}

		if(file_exists("c:/windows")){	
			$file=fopen($_SERVER['DOCUMENT_ROOT']."/scripts/sync/tempsnd.bat", "w");
			fwrite($file, $extr);
			fclose($file);

			$file=fopen($_SERVER['DOCUMENT_ROOT']."/scripts/sync/temp.vbs", "w");
			fclose($file);
			

			$file=fopen($_SERVER['DOCUMENT_ROOT']."/scripts/sync/temp.bat", "w");
			fwrite($file, " \n
			\n

			");
			fclose($file);
		}


else{



                $title=str_replace(";", " ", $oldp."".$photos)." - Original Composition";
                if($_GET['title']==""){

                }
                else{
                $title=$_GET['title']. " (Original Composition)";
                }

                $description= "An original  Video Animation of ".$title ." made with AGAPlay (Software at ogena.net)";

                if($_GET['description']!=""){
                $description = $_GET['description'];
                }

                $author = "info@gena.net - Ben Massoud, (R)";
                if($_GET['author']!=""){
                $author=$_GET['author'];
                }

                $year= "";


}


		}
		
		
		if($thethesnd==""){	
			
			$extr ="\n
			cd \"c:\program files\apache software foundation\apache2.2\htdocs\scripts\sync\"
			\n
			wscript.exe temp.vbs & 
			\n
			cmd /c  start /min tempsnd.bat 
			\n
			\n
			echo cls > temp.bat 
			
			";


	
	}
		
		
 }
 
/*If time specified, It can be recorded to the Desktop */
if($_GET['time']!=""){
	$fou = fopen($_SERVER['DOCUMENT_ROOT']."/images/time", "w");
	fwrite($fou, $_GET['time']);
	fclose($fou);
	
	if($_GET['soundfx']=="" && $thethesnd=="" && $_GET['song']==""){
	$_GET['nosound']="yes";
	}
}
?>

var fnm= "<?php 

$mypp=$oldp."".$photos;
	

$mypp =str_replace(" ", "_", $mypp);

echo "images/0000frames".substr(str_replace(" ", "_", str_replace(":", "_", str_replace(";", "_", $mypp))), 0, min(20, strlen($mypp))); ?>";
					
/*Buils A webm After Time Elapsed*/
function closing(){
	if(totpercent >= 96 && (totpercent<120) && reddyF==true   ){
		reddyF=false;
		
  		xmlhttpxxclosef = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
		xmlhttpxxclosef.open("GET", "/scripts/sync/__fin.php?rr="+Math.random());

		xmlhttpxxclosef.send(null);
				framesEffectx = framesEffect;

		
	}
	if(reddyF==true){
		setTimeout('closing()', 3500);
	}
}
closing(); 

/*Summary Images, Used in the Animation*/
var hasBSummery = false;
function beginSummary(){
	if(hasBSummery==false && can >4 ){
  		hasBSummery = true;
xmlhttpxxsume=null;

		xmlhttpxxsume = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
		xmlhttpxxsume.open("GET", "http://<?php echo getenv("HTTP_HOST"); ?>/scripts/php/summary.php?p=<?php echo $oldp."".$photos; ?>&nrPrevImage=<?php echo $nrOffSummaryImg; ?>&qwq="+(10000000*Math.random()));
		xmlhttpxxsume.send(null);
		hasBSummery  =true;
	}
	else{
		setTimeout("beginSummary()", 4000);
	}				
}

beginSummary();


<?php
if($_GET['soundfx']==""){
}
else{
echo "onTimerD(); ";
}
?>

htmlprotect= document.getElementById('quote');
var xmlhttpxxctux = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP"); 
var ddown=false;
function triggeredxctx(){
        if ((xmlhttpxxctux.readyState == 4) && (xmlhttpxxctux.status == 200)) {
                readTi = parseFloat(xmlhttpxxctux.responseText);
                if(readTi>0 && ddown==false){
         	ddown=true;
<?php
		$snd="";

		if($_GET['tags']==""){
		$_GET['tags']="Funny,very,special,";

                	$tagss = explode(";", $_GET['soundfx']);
                        	for($t=0;$t<count($tagss);$t++){
	                 	$_GET['tags'].=$tagss[$t].",";
        			$snd.=$tagss[$t].", ";           		

     	}
		$ds="";
                        $tagss = explode(" ", $oldp."".$photos);
                                for($t=0;$t<count($tagss);$t++){
                                        $_GET['tags'].=$tagss[$t].",";
		$ds.=$tagss[$t].", ";                        

        }




		}


		if($_GET['description']==""){
		$_GET['description']="Special Animated Animation - ".$ds ." very funny , with music samples of:".$snd . ". Sofware @(ogena.net) " ;
		}

		if($_GET['title-clip']==""){
			$_GET['title-clip']="Funny special Video ".$ds ." very funny audio";
		}
		

		if(file_exists("/var/www")){
	
		}
		else{

		
		}
		$down = $ddownl;
?>

			dc = document.getElementById('quote');               
	alert("The Recording Finished"); dc.innerHTML="<center><a href='<?php echo $down; ?>'><img width=80 src='images/summary15.jpg'><BR>Download Video!</a><BR><BR><BR><a onclick=\"stor('<?php echo $down; ?>')\">Use in Studio ..</a>";




                }

        }
}



function download(){
	xmlhttpxxctux=null;
        xmlhttpxxctux = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
        xmlhttpxxctux.onreadystatechange = triggeredxctx;
        xmlhttpxxctux.open("GET", "/sound/download?fr="+Math.random());
        xmlhttpxxctux.send(null);


setTimeout("download()", 4000);

}
download();




function downloadm(){

	xmlhttpxxctuxm=null;
        xmlhttpxxctuxm = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
        
        xmlhttpxxctuxm.open("GET", "/sound/mkSonLin.php?time="+readTime+"&fr="+Math.random());
        xmlhttpxxctuxm.send(null);




}
<?php
if($_GET['song']=="yes"){
echo " downloadm(); ";
}







if($_SESSION['mtm']>0){
echo "readTime=".$_SESSION['mtm']."; ";
}



if($thethesnd!="" || $_GET['soundfx']!=""){

	
		
		if($_GET['youtubeId']!=""){
		
		

		}


		if($theSound!=""){
		
		$_GET['time']=$datred;
		
		


		
	


		}
		else{
		
		if(file_exists($thethesnd) || $_GET['soundfx']!="" ){
		}
		else{
		echo "alert('No matching Audio...'); ";
		}
		
		}


		

		

}

	
?>

</script> 



<?php  

if($_GET['sounfdx']!=""){
@include_once('sound/mkit.php');
}









?>
		<?php
		
		if($_GET['song']=="yes"){
		
		echo ("<script type='text/javascript'>
		xmlhttpxxrad1 = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject(\"Microsoft.XMLHTTP\");
		xmlhttpxxrad1.open(\"GET\", \"http://".gethostbyname(getenv("HTTP_HOST"))."/sound/mkSonWin.php?time=\"+readTime+\"&qwq=\"+(1000*Math.random()));
		xmlhttpxxrad1.send(null);
		</script>
		");
		}
if(!($_GET['soundfx']=="" || $thethesnd=="" )){

}







        $time = @file_get_contents("http://".getenv("HTTP_HOST")."/images/time?request=".urlencode($thethesnd));

if($time>0){
        echo "<script type='text/javascript'>readTime=".$time."; </script>";

}



		
		?>
<?php




	













if($_GET['info']==1){

echo "<div id='text' style='position:absolute;top:10px;left:10px;background:#808080;background-color:rgba(80,80,80,0.5);'>.#.</div>
<script type='text/javascript'>
var tht= document.getElementById('text'); 
function showS(){ft=(cfra-100000)/(seconden+1); tht.innerHTML=\"<span style='color:#ddddff'>Time Up: \"+(tststf)+\"</span><br><span style='color:white'>cfra:\"+Math.floor(cfra-100000)+\", imct: \"+(mct-100000)+\"  fr: \"+Math.round(2*avdiv)+\" | fps: \"+ft.toFixed(1)+\"</span><br><span style='color:yellow'>\"+newpnew+\"</b><BR>\";
setTimeout('showS()', 700);
}
showS();
</script>
";





}


?>

<script type='text/javascript'>


var existImcnt=0;
var     xmlhttpReady = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");

function triggeredReady() {
        if ((xmlhttpReady.readyState == 4) && (xmlhttpReady.status == 200)) {
		 existImcnt=  xmlhttpReady.responseText;
	}
}

function getdataReady(dest) {
          xmlhttpReady=null;
                xmlhttpReady = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
             

        
        xmlhttpReady.onreadystatechange = triggeredReady;
        xmlhttpReady.open("GET", dest);
        xmlhttpReady.send(null);


}

var klaar1=false;
function getDatazz(){	
	if(klaar1==false){
	getdataReady('scripts/php/scanImages.php?p'+Math.random());

	if(existImcnt>200 ){
		
		klaar1=true;
		getdataz();
	}
	else{
		setTimeout("getDatazz()", 1000);
	}
}
}
getDatazz();
</script>

<?php

function ytDl($p){

$q=$p." site:youtube.com ";
$url2= "http://search.yahoo.com/search?p=".urlencode($q);

$datah= file_get_contents($url2);
$rs=10;
$ff=false;
$first="";
        $ex=explode("Cached", $datah);
for($i=0;$i<6;$i++){
        $e=$ex[$i];
        $start=0;
        $end=0;
        for($jj=0;$jj<(strlen($e)-6);$jj++){
                $wo=substr($e, $jj, 5);
                if($wo=="<h3 c"){
                        $start=$jj;
                }
                if($wo=="</h3>"){
                        $end=$jj+5;
                }
        }
$thetit= str_replace(" - YouTube", "", strip_tags(substr($e, $start, ($end-$start))));
        $ef=explode("www.youtube.com/watch?v=", $e);
        $st=strpos($ef[1], "v=");
        $end=strpos($ef[1], "</span>");
        $st= substr($ef[1], ($st+2), ($end-$st-2));
        $title2= "http://img.youtube.com/vi/".$st."/mqdefault.jpg";
        $p=$thetit;

        $sst[]=$st;
        if($first==""){
                $first=$st;
        }

}

if($_GET['randomTrack']==true){
        return $sst[rand(0, (count($sst)-1 ))];
}
else{
        return $first;
}

}





if($_GET['streamer']!=""){

		file_get_contents("http://".getenv("HTTP_HOST")."/scripts/sync/stream.php?url=".$_GET['streamer']);
		include_once("sound/radiost.php");
		


}




?>

