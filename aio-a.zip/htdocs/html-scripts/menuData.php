<?php
/*
	Title: Web Based Video Maker / Editor 
	Description: General Purpose Graphics / Animation & Movie Editing
	Author:Ridouan Ben Massoud
	Domain: ogena.net & e-rogen.eu
	Date: 20-01-2015
	File: /menuData.php (Build Parameter & Previewer)
*/
?>


<?php

if($_GET['theSelectedIndex']!=""){

echo "<div  id='sometrans' style='border-radius:8px;position:absolute;left:630px;top:25px;background:#050505;   );  opacity: 0.3;text-align:center'>";

}
else{

echo "<div  id='sometrans' style='border-radius:8px;position:absolute;left:630px;top:25px;background:#050505;   );  opacity: 0.7;text-align:center'>";



}
?>


<script type='text/javascript'>


function clearSound(dat){
getdataa("/scripts/phpstudio/clearAudio.php?dat="+dat+"&ii="+Math.random());

}

st =document.getElementById('sometrans');
st.style.filter='progid:DXImageTransform.Microsoft.Alpha(Opacity=70)';
st.style.filter="alpha(opacity=70)";
</script>

<h3><span style='color:orange' id='previ'>Preview </span><span id='totalRecorderTime' style='color:orange'><?php 

$lw=@file_get_contents("http://".getenv("HTTP_HOST" )."/data[".$_SERVER['REMOTE_ADDR']."]/lenWav.txt");
if($lw==""){
$lw=0;
}

echo "<script type='text/javascript'> dura =".$lw.";  durah=Math.floor(dura/(60*60)); duram=Math.floor(  (dura-(durah*60*60)) /60); duras= dura-(60*60*durah)-(duram*60); 
if(durah<10){
durah='0'+durah;
}
if(duram<10){
duram='0'+duram;
}
if(duras<10){
duras='0'+duras;
}
document.writeln(durah+':'+duram+':'+duras);
</script>";

?></span></h3>
<span id='video'>


<?php if($_GET['p']=="Record") {

echo "<video id='video8' autoplay  style='width:200px;height:130px;'></video>";
}
?>



</span>

<br><button style='background-color:#666666;width:130px;height:25px;color:orange' onclick='replay()'>Replay</button>

<br/>
<br/>

Video Name <input type='text' id=vname value='My Video[<?php echo date("Y-m-j"); ?>]'> 
<br/>
<br/>

Container<select name='vext' id='vext'>
										<option value='avi'>avi</option>
										<option value='mov'>mov</option>
										<option value='mpg'>mpg</option>
										<option value='webm' selected>webm</option>
										<option value='mp4' >mp4</option>
										<option value='gif'>gif</option>
										<option value='flv'>flv</option>
										<option value='webm'>webm</option>
										<option value='ogg'>ogg</option>
										<option value='wmv' >wmv</option>
							</select>
<br/>
<br/>


Video Quality (Bit Rate)<input type='text' name=preset id=preset value='800k' style='width:40px'>



<br/>
<br/>

<br/>
<br/>
<script type='text/javascript'>
if(_width){
document.write("Width  <input type='text' id=vwidth  style='width:40px' value='"+_width+"';>Height  <input style='width:40px' type='text' id=vheight  value='"+_height+"'> Pixels ");
}
</script>
<br/>
<br/>
<button onclick='downloadVideo()' style='background-color:orange;width:130px;height:25px;color:white' >Download / Save</button>
<br/>
<br/>
<a href='http://ogena.net/'>Contact Us</a>

</div>

   


	

				
				
			

	<div id='audio' style='position:absolute;left:100px;top:240px'>

		</div>	
		
<div id='timespan' style='position:absolute;left:100px;top:340px'></div>
<div id='audioplot' style='position:absolute;left:100px;top:170px'>

</div>


<div id='settings' style='position:absolute;left:100px;top:245px'></div>			 	
<script type='text/javascript'>

ff="";
<?php
	$re=@file_get_contents("http://".getenv("HTTP_HOST")."/data[".$_SERVER['REMOTE_ADDR']."]/projectAudio.data");
	$red=explode("<next>", $re);
$af="";	
for($i=0;$i<(count($red)-1);$i++){
	$ag= substr($red[$i], 0 , (strlen($red[$i])-0) );
	
	
	if(strlen($ag)>4 && $_GET['p']==""){
	$he= "<h4>Audio</h4>";
	if($i==0){

	$af.="<button onclick=clearSound('".$ag."')>Clear Audio</button><img src='/pictures/icons/audio.gif' width=30>".$ag."<br/>";
	}
	else{
 $af.="<button onclick=clearSound('".$ag."')>Clear Audio</button><img src='/pictures/icons/audio.gif' width=30>".$ag."<br/>";

	}

	}
}
	echo "ff=\"".$af."\"; ";
	?>

dd=document.getElementById('audio');
dd.innerHTML=ff+'';





getdataf("/data[<?php echo $_SERVER['REMOTE_ADDR']; ?>]/mfps.txt?p="+Math.random());



<?php

if(!file_exists($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."/My_Video[".date('Y')."-".date('m')."-".date('j')."].mp4")){


echo " vid=document.getElementById('video');  vid.innerHTML=\"<img src='/pictures/icons/mmedia.gif' style='opacity:0.1;' width=200>\"; ";


}
$top=0;


	$dat = @file_get_contents("http://".getenv("HTTP_HOST")."/data[".$_SERVER['REMOTE_ADDR']."]/pproject.data");
	if(strlen($dat)>10){
	$ec=explode("<next>", $dat);
	$k=0;

	
	for($jo=0;$jo<count($ec);$jo++){

	if($ec[$jo]=="" ){
	}
	else{
	echo " vidsArray[".$jo."] = \"".$ec[$jo]."\"; \n";
	echo " vidsArray[".$jo."] = \"".$ec[$jo]."\"; \n";
	$e= explode("'", $ec[$jo]);
	$ee = $e[3];
	$dd=explode("*", $ee);
	echo " vidFPS[".$jo."]=".str_replace("\\", "", $dd[3])."; ";

	$k++;

	}
	}
	echo "counterVids =  ".$k.";  ";
	}


        $dat = @file_get_contents("http://".getenv("HTTP_HOST")."/data[".$_SERVER['REMOTE_ADDR']."]/pprojectz.data");

        

	$g = explode("<next>", $dat);


$k=0;
	for($i=1;$i<(count($g)-1);$i++){



	$ec=explode(";", $g[$i]);



        for($jo=0;$jo<count($ec);$jo++){
	

        echo " perItem[".$k."] = new Array('".$ec[1]."','".$ec[2]."','".$ec[3]."','".$ec[4]."','".$ec[5]."','".$ec[6]."','".$ec[7]."','".$ec[8].
"','".$ec[9] ."','".$ec[10]."','".$ec[11]."','".$ec[12]."','".$ec[13]."','".$ec[14]."' ); \n";
 



	if($ec[2]==""){

	echo " vidSTART[".($k+1)."]=0; ";
}
else{

 echo " vidSTART[".($k+1)."]=".$ec[2]."; ";


}

    






}


$k++;






        }

echo " maxPart=".$k.";   display(); ";



	
?>
</script>	


<?php
if(file_exists('../data/wave.gif')){


echo "<script type='text/javascript'>
dd=document.getElementById('audioplot');
wwwi= document.getElementById('timespan').offsetWidth;
dd.innerHTML=\"<br><img width='\"+wwwi+\"px' height=\"70px\" src='/data/wave.gif?p=\"+Math.random()+\"'>\";
</script>";
}
?>
<script type='text/javascript'>
function downloadVideo(){
refreshClipName();

window.open('/scripts/phpstudio/saveDownloadClip.php?file='+clipName+'&path=data[<?php echo $_SERVER['REMOTE_ADDR']; ?>]&e='+Math.random(), 'Download');
}


refreshClipName();










printSome();
syncTitles();



</script>		




</div>
</div>
</div>

</div>

<div style='position:absolute;left:35px;top:300px'>

<?php

if($_GET['p']=='form'){

echo " <iframe src='/html-scripts/upload.html' scrolling='no' scrollbars='no' width='150px' height='120px' style='border:0'>NO IFRAME SUPPORT</iframe> <br/><br/><br/>";


}



?>


    <a href="http://validator.w3.org/check?uri=referer"><img
      style='border:0' src="http://www.ogena.net/w3c/images/w3c-validated.png" alt="Valid HTML 5 Page - W3C Validation Icon" height="31" width="88" /></a>
  <br/><br/>



           <a href="http://jigsaw.w3.org/css-validator/check/referer">
    <img style="border:0;width:88px;height:31px"
        src="http://jigsaw.w3.org/css-validator/images/vcss"        alt="Valide CSS!"/><br/><br/>
</a>

<br/>



</div>


