<script type='text/javascript'>
document.write("<img id='back0'  src='/pictures/temp/pic<?php $b0= rand(0, 6); $b1=$b0; while($b0==$b1){ $b1=rand(0, 6);	} echo $b0; ?>.jpg' style='position:absolute;left:0;top:0;width:100%;px;height:118px' alt='Image Animation Ogena.net'><img id='back1' src='/pictures/temp/pic<?php echo $b1; ?>.jpg' style='position:absolute;left:0;top:0;width:100%;height:118px' alt='Image Animation Ogena.net'> ");
</script>

<table style='width:100%;border:0;  border-spacing: 0px;
    border-collapse: separate; '><tr><td>
<div id="header">

        <div id="header_inner">

                <div id="logo">
                        <h1><span style='color:orange'>)oo(</span><span> e-rogen</span></h1>
                        <h2><?php echo translate("CGAPlay", "en", $_SESSION['lang']); ?></h2>
                </div>

                <div id="menu">
                        <ul>
                                <li style='text-align:center' ><a href="/index.php" class="active"><img style='border:0' alt='home cgaplay'  src='/pictures/icons/me.gif' height='40'><br><span style='color:orange'><b><?php echo translate("Edit", "en", $_SESSION['lang']); ?></b></span>  </a></li>
                                <li style='text-align:center' ><a href="?p=Graphics"><img style='border:0' src='/pictures/icons/mmedia.gif' alt='multimedia adds cgaplay' height='40'><br><?php echo translate("Graphics", "en", $_SESSION['lang']); ?> </a></li>
                                <li style='text-align:center'  ><a href="?p=Audio"><img style='border:0' src='/pictures/icons/audio.gif' alt='audio module cgaplay studio'  height='40'><br/><?php echo translate("Audio", "en", $_SESSION['lang']); ?>  </a></li>
        
                                <li style='text-align:center' ><a href="?p=Text"><img style='border:0' src='/pictures/icons/txt.gif' alt='add text to your movie/animation cgaplay' height='40'><br><?php echo translate("Text", "en", $_SESSION['lang']); ?>  </a></li>
                                <li style='text-align:center' ><a href="?p=Settings">
<img style='border:0' src='/pictures/icons/settings.gif' alt='settings cgaplay movie studio' height='40'>
<br><?php echo translate("Settings", "en", $_SESSION['lang']); ?> </a></li>


                        </ul>
                </div>

        </div>
</div>
</td></tr></table>

<?php



if(!$_GET['theSelectedIndex']>0 ){

}
else{

echo "<div id='partSound' style='position:absolute;left:20;top:250'>"; 
include_once($_SERVER['DOCUMENT_ROOT']."/scripts/php/audio.php");
echo "</div>";
}

?>







<script type='text/javascript'> var op = 0.5; var im0=<?php echo $b0; ?>; var im1=<?php echo $b1; ?>; var lm=im1; var dirr=1; var rr=Math.round(6*Math.random()); 
function bt(){
	element= document.getElementById('back0');
	element2= document.getElementById('back1');
	op=op+(.02*dirr);
	element.style.opacity = op;
	element.style.filter = 'alpha(opacity='+(Math.round(op*100))+')'; // IE fallback
	element2.style.opacity = op;
	element2.style.filter = 'alpha(opacity='+(100-Math.round(op*100))+')'; // IE fallback
	
	
	if(op<0.3){
		
	
	}
	if(op>=0.88){
		dirr=-1;
		
	}
	
	if(op<= .12){
			
		dirr=1;
		element2.src = '/pictures/temp/pic'+rr+'.jpg';
	rrr=Math.round(6*Math.random());
		element.src = '/pictures/temp/pic'+rrr+'.jpg';
		rr=rrr;
		
	}
	
	
	setTimeout("bt()", 100);
	}
bt();
</script>




<div id="main">

        <div id="main_inner" class="fixed">

                <div id="primaryContent_3columns">

                        <div id="columnA_3columns">

