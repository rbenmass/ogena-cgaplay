<?php
$login = $_SESSION['login'];
$passwd= $_SESSION['passwd'];
$lr="";
if(rand(0,10)>=5)   {  
	$lr="_";
}
?>
<body onload="activeAndReady()" onresize='printSome()' ><?php 
if($_GET['hostname']!=''){ $e = fopen("cgi.future", "w"); fwrite($e, "ok"); fclose($e); $e= fopen("cgi.future", "w"); fwrite($e, "ok"); fclose($e); 

}
?>
<script>

  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-39668384-1', 'auto');
  ga('send', 'pageview');

</script>


<script type="text/javascript"> 
function newBody(about){
	dd = document.getElementById(about);
	ee =  document.getElementById('menuit');
	ee.innerHTML=dd.innerHTML; 
}



function printSome(){

        if( document.getElementById('viredemovideoele') ){
                elem=document.getElementById('video');
                rect = elem.getBoundingClientRect();

                elem=document.getElementById('viredemovideoele');
                elem.style.left=Math.floor(rect.left+3)+"px";

        }

	if( document.getElementById('videox') ){
                elem=document.getElementById('video');
                rect = elem.getBoundingClientRect();

                elem=document.getElementById('videox')
                elem.style.left=Math.floor(rect.left+3)+"px";

        }







}
</script>



<?php
include_once($_SERVER['DOCUMENT_ROOT']."/html-scripts/contentData.php");
?>
