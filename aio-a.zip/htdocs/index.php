<?php
/*	File:index.php
	Author: Ridouan Ben Massoud
	Last update: 19-08-2014
	Domain: Ogena.net
	Description: Managing Class for Internet Page 
*/
 date_default_timezone_set('Europe/Amsterdam');
$about = "";
include_once('Medium.php');
 
class Head extends Medium{
	/*
		The working class variables
	*/
	private $__version;
	private $_domain;
	
	private $symbols;
	private $post;
	private $get;
	
	function __construct() {  
	$this->__version='p';
	}	
	
	function getId(){  
		return $this->__version;
	}
		
	function init($i){
		$this->_domain = $i;
	}		
} 

class Body extends Head{
	//Neccessary pages/modules files.
	private $header;
	private $startPage;
	private $body;
	private $craweler;
	private $searcher1;
	private $searcher2;
	private $menu;  
	private $footer;
	private $_domain;
	
	function __construct($xs) {
		parent::__construct();
		$specific = str_replace(">>","/", $xs);
		
		$this->header       = $_SERVER['DOCUMENT_ROOT']."/hf/Header.php";
		
		//if(rand(0,10)>7){
		$this->startPage    = $specific."Home.php";
		//}
		//else{
		//$this->startPage    = $specific."randomnews.php";
		//}
		
		$this->body         = $specific."content.php";
		$this->crawler      = $_SERVER['DOCUMENT_ROOT']."/saveUrl.php";
		$this->searcher1    = $_SERVER['DOCUMENT_ROOT']."/modules/UService.php";
		$this->searcher2    = $_SERVER['DOCUMENT_ROOT']."/modules/Search.php";
		$this->menu         = $specific."menu.php";
		$this->footer       = $_SERVER['DOCUMENT_ROOT']."/hf/Footer.php";			
	}
		
	function feed($a_, $b_){
		$this->post = $b_;
		$this->get = $a_;
	}

	/*
		Usesless time function: Defined here but not needed
	*/
	function microtime_float_time()
	{
		list($usec, $sec) = explode(" ", microtime());
		return ( (float)$usec);
	}

	/*
		No need for identity or Idea (id's and so on)
	*/
	function copy(){
		include_once($this->header);
		if($this->get[$this->getId()]!=""){
		$this->symbols = $this->get[$this->getId()];
		}
		if($this->post[$this->getId()]!=""){
		$this->symbols = $this->post[$this->getId()];
		}
	}

	/*
		Including/displying the Content. Function renders the webpage, with menu and Footer.
		The proper modules defined by variable p is included
	*/
	function mind() {
		//$symbols1="Webdings";
		
		@include_once($this->body);
		$_SESSION['logind']=rand(0,202020);

		if($this->symbols==""){ 
		@include_once($this->startPage);
		}else{
			//Load or process symbols
			$p=$this->symbols;
			
			if(file_exists('modules/'.str_replace(" ", "_",$p).'.php' ) ||  file_exists('modules/'.str_replace("_", " ",$p).'.php' )){
			$key="NULL";
			if(file_exists("keys/".str_replace(" ", "_",$p).".php") || file_exists("keys/".str_replace(" ", "_",$this->post[$this->getId()]).".php") ){
			$key=file_get_contents("keys/".str_replace(" ", "_",$this->post[$this->getId()]).".php");
			}
			if(( trans1red($_POST['key'])==$key)  && file_exists("keys/".str_replace(" ", "_",$this->post[$this->getId()]).".php") ){
				include_once('modules/'.str_replace(" ", "_",$p).'.php');
				}
			else{
				if(file_exists("keys/".str_replace(" ", "_",$this->post[$this->getId()]).".php") && ( $_POST['key']==$key) ){
					include_once('modules/'.str_replace(" ", "_",$this->post[$this->getId()]).'.php');
					}else{
						if(!file_exists("keys/".str_replace(" ", "_",$p).".php")){
							include_once('modules/'.str_replace(" ", "_",$p).'.php');
						}else{
							//Key needed		
						}
					}  
				}
			}else{
			//Search or Crawl p
			$this->get[$this->getId()]=$symbols;
			@include_once($this->crawler);
			@include_once($this->searcher1);
			@include_once($this->searcher2);			
			}			   
		}		
		@include_once($this->menu);
		//echo $this->toString();
		include_once($this->footer);
	}
}
?>
<?php
$body = new Body($about);
$body ->clean();
$body ->feed($_GET, $_POST);
$body ->copy();
$body ->mind();
?>