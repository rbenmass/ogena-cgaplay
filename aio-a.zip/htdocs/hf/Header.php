﻿<?php
/*
	Author: Ridouan Ben Massoud
	Date Last Change: 27-07-2015
	Domain: 127.0.0.1 / (*/ $http='ogena.net'; /*))
	File: hf/Header.php
	Description: Header Functions for HTTP uploads e.g. 
*/
error_reporting(E_ALL ^E_NOTICE);
date_default_timezone_set('Europe/Amsterdam');
@mkdir($_SERVER['DOCUMENT_ROOT']."/pictures/");
@mkdir($_SERVER['DOCUMENT_ROOT']."/pictures/temp");

$bgg=@scandir($_SERVER['DOCUMENT_ROOT']."/pictures/temp");
set_time_limit(300);

$bgg=scandir($_SERVER['DOCUMENT_ROOT']."/pictures/temp");
if(count($bgg)<4){

	for($j=0;$j<7;$j++){
	@copy("http://".$http."/cgaplay/backgrounds/pic".$j.".jpg" , $_SERVER['DOCUMENT_ROOT']."/pictures/temp/pic".$j.".jpg");
	}
}
set_time_limit(0);
if($_GET['action']=="createBG"){
	@mkdir($_SERVER['DOCUMENT_ROOT'].'/pictures/temp');
	for($i=1;$i<=4;$i++){
		$im = getImageListFromGoogleLarge("stars nebula orange", ($i*8), "huge", "", 8, false);

		for($t=0;$t<count($im);$t++){
		@copy($im[$t], $_SERVER['DOCUMENT_ROOT']."/pictures/temp/img.".$i.".".$t.".jpg");
		}

	}

}
else{

	$im = scanDir($_SERVER['DOCUMENT_ROOT']."/pictures/temp");
	for($j=0;$j<count($im);$j++){

	if($im[$j]=="." || $im[$j]==".."){
	}
	else{
	$imgs[]=$im[$j];
	}
	}

	@unlink($_SERVER['DOCUMENT_ROOT']."/pictures/n1.jpg" );
	@copy($_SERVER['DOCUMENT_ROOT']."/pictures/temp/".$imgs[rand(0, (count($imgs)-1))],  $_SERVER['DOCUMENT_ROOT']."/pictures/n1.jpg");

	list($w,$h)=@getimagesize("http://".getenv("HTTP_HOST")."/pictures/n1.jpg");
}

function getDocRoot(){
	$docroot = $_SERVER['DOCUMENT_ROOT'];
	return $docroot;
}

$target_dir = $_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/myMedia/";

$target_diraud = $_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/myMediaAudio/";

$target_file = $target_dir . basename($_FILES["userfile"]["name"]);
if(strpos($_FILES["userfile"]["name"] , ".jpg")>0){
	$target_dir = $_SERVER['DOCUMENT_ROOT']."/php/uploads/";
	$target_file = $target_dir . basename($_FILES["userfile"]["name"]);
    if (move_uploaded_file($_FILES["userfile"]["tmp_name"], $target_file)) {
    } else {
    }
	exec ("ffmpeg -r 25 -f lavfi -i aevalsrc=0 -loop 1 -i \"".$target_file."\" -t 20 -shortest -c:v copy -c:a aac -strict experimental \"".$_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/myMedia/Anim-".rand(10000,40000).".avi\"");
}
else{


	if($_POST['audio']=="yes"){

        $uploadOk = 1;
        $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
        if (move_uploaded_file($_FILES["userfile"]["tmp_name"], $target_diraud."".str_replace(" ", "_",  $_FILES["userfile"]["name"]) )) {
        }
        else {
        }

}
else{
	$uploadOk = 1;
	$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
	if (move_uploaded_file($_FILES["userfile"]["tmp_name"], $target_file)) {
	} 
	else {	 
	}

}


}

	
function symbolTifinagh($x){
}

function wordTifinagh($wqa){

}

function calP($n){
}

function quit(){

}

?>
<?php
ini_set('default_charset', 'UTF-8');   

function translate($q, $s, $e){
return $q;
}

function formatNumberStringPlus($x, $p){

}

$wvl= 1800;
$hvl=1600;

@exec("java  -cp \"".$_SERVER['DOCUMENT_ROOT']."\" Signature ".$wvl. " ".$hvl. " 28 \"".$_SERVER['DOCUMENT_ROOT']."/javaimagephp.jpg\" 0 0 0");


?><!DOCTYPE html>
<html>
<head>
<link rel='stylesheet' type='text/css' href='<?php echo "http://".getenv('HTTP_HOST'); ?>/styles.css?pp=<?php echo rand(10, 10000000); ?>' media="all" />
<title><?php 

echo translate("CGAPlay - By بن مسعود (R)", "en", "en");

?>
</title>


<?php



function getIdYoutube($q, $n4){
}

function getDescription($q, $rs, $extt){



	$urt = "http://en.wikipedia.org/wiki/".str_replace(" ", "_", urldecode($q));
	$page = @file_get_contents($urt);

	if(strpos($page, "Wikipedia does not have an article with this exact name")>0 ){

	}
	else{

		$dps=strpos($page, "</div>\n</div>\n<p>");
		$datap = substr($page, $dps);
		$page=explode("<p>", $datap);
		$thies= $page[1];
		$the.=strip_tags($thies);

return $the;
		

	}







	$url2= "http://us.search.yahoo.com/search?p=".urlencode($q);
	$datah= file_get_contents($url2);


	$ff=false;
	for($i=0;$i<$rs;$i++){

	$st=strpos($datah, "<a id=\"link-".$i."\"");
	$en= strpos($datah, "<a id=\"link-".($i+1)."\"");
	


	$datad= substr($datah, $st, ($en-$st));
	$d = strpos($datad, "</span>");

	$dats = substr($datad, 0, ($d+7));

	$p=str_replace("<b>", "",   $dats);

	$link = strpos($p ,"href=");
	$linkq =strpos($p, "target");
	$linkItem  =substr($p, ($link+6), ($linkq-$link-7) );

	if($extt>0){

	if(strpos($linkItem, "wikipedia")>0 && $ff==false){
	$ff=true;
	$datapp = file_get_contents($linkItem);

	$dps=strpos($datapp, "</div>\n</div>\n<p>");

	$datap = substr($datapp, $dps);


	$page=explode("<p>", $datap);
	$thies= $page[1];
	$the.=strip_tags($thies);

return $the;
		


	}
	}
	else{
	$data[] = $linkItem;
	}
	}


	
}

echo "<meta name=\"description\" content=\"";




echo translate("Real Time Graphics Slideshow, Special Effect Image Player. Professional Computers Animation, visualization and Clip (Film) Maker. An Arts Directory", "en", "en");




echo "\"/>";

?>
<meta name="google-site-verification" content="bsBLUsCnvoyOrptUvY5P8b3lfnyKPDha6qQxRgcE_p4" />
<meta name="google-site-verification" content="elhUFRZQ3h6B7KGMBr3BzfWlyTJXpi3SilsefKZx7v8" />
<meta name="msvalidate.01" content="17B73E15D3A5FA3F5FC6AA9BE9D13D10" />
<meta name="google-site-verification" content="C4AMuRUj57oi05AGIaO0t_LreTJlRtjxw7TFkO8Zvkw" />
<meta http-equiv="Content-Type" content="text/html;charset=utf-8"/>
<meta name='Author' content="Ridouan Ben Massoud" />
<meta name="dcterms.rightsHolder" content="All rights reserved -  Ogena Net."/>
<meta name="dcterms.rights" content="@(Download) COPYRIGHT"/>
<meta name="dcterms.dateCopyrighted" content="<?php echo date('Y'); ?>"/>


<?php

function trans1red($input){
}
function trim_img_tags($string) {
}
function displayTopOgenaCountries(){
}
function CheckImageExists($imgUrl) {
}
function loc_redirect($url) {
}
function url_existss($url) {
}
function transla($enc, $desi, $descr){
}
function trjm($wordd, $try, $amBoo){
}  
?>
<?php
$_SESSION['prank']=2;
function findPos($x, $str, $start, $ir){
}
function replaceComments($str){
}
function parseStarEndFunction($strrr){
}
function getPasswd($usr)
{
}
function nslookup($ip) {
return $ip;
}
function microtime_float()
{
    list($usec, $sec) = explode(" ", microtime());
    return ( (float)$sec);
}
function getRandomImage($usr){
}
function isupper($i) { return (strtoupper($i) === $i);}
function islower($i) { return (strtolower($i) === $i);}
function getRandomImages($usr){ 
}
function baseN($number, $base){
}
?>
<script type='text/javascript'>
var iaa__ ='';
var the__='';
function allowDrop(ev) {
  ev.preventDefault();
}
var theRa = 0;
function cng(){
theRa = Math.ceil(10000*Math.random());	
	return theRa;
}

function drag(ia, the) {
iaa__ = ia;
the__ = the;
}

function dropp(ev) {
alert("Drag dropped"+ev);	
}


<?php
echo " var ipme='".$_SERVER['REMOTE_ADDR']."';";
?>
</script>
<?php

function getImageListFromGoogleLargeX($search4, $start, $imgsz, $color, $nrOfm, $thumnail){
}
function getImageFromGoogleLarge($search4, $start, $imgsze, $color){

}
function ifimurl($imur){
return false;
}
function getImageFromGoogle($search4, $start){
}

?>


<style type="text/css">
html, body , #slidex{width:100%; margin:0; padding:0;margin: 0;} 
#slidexs{ width:100%;margin:0; padding:0;margin: 0;} 
#slidext{ width:100%;margin:0; padding:0;margin: 0;}
#slidexu{ width:100%;margin:0; padding:0;margin: 0;}
#page-background {position:absolute; top:0; left:0; width:100%; height:100%; padding:0px;margin: 0px}
#page-backgroundo {position:absolute; top:0; left:0;padding:0px;margin: 0px; width:100%;height:100%}
#page-backgroundp {position:absolute; top:0; left:0;padding:0px;margin: 0px;width:100%;height:100% }
#page-backgroundq {position:absolute; top:0; left:0; width:100%; height:100%;padding:0px;margin: 0px}
#content {position:relative; z-index:1; padding:0px;margin: 0px;}
</style>

<style type="text/css">
#slidex{
width:100%;
height:100%;
}
#slidexs{
width:100%;
height:100%;    
}
#slidext{
height:99%;
}
#slidexu{
height:99%;
}
#content{
width:100%;
}
</style>
</head>
<?php
$dirtysec="15sec.mp3";
if(file_exists($_SERVER['DOCUMENT_ROOT']."/temp/".$dirtysec )){

}
else{

	exec("ffmpeg -f lavfi -i aevalsrc=0 -t 15  -q:a 9 -acodec libmp3lame \"".$_SERVER['DOCUMENT_ROOT']."/temp/".$dirtysec."\"");
}
function getWikiPedia($search){
}
if($_FILES['userfile']['name']){
	$uploaddir = "";
	$uploadfile = $uploaddir.$_FILES['userfile']['name'];
	if (move_uploaded_file($_FILES['userfile']['tmp_name'], $uploadfile)) {
	   
	}
	else{
		echo "Error uploading";
	}

}

if( $_FILES['userfile']['name'] ){

	

	 if(  strpos($_FILES['userfile']['name'], ".jpg")>0){
		$datime = date("Y-m-d-H.i.s", time() ) ; # - 3600*7
		$uploadDir = $_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/myMedia";
		$uploaddir = $uploadDir."/";
		$str=str_replace(" ", "_",$_FILES['userfile']['name']);
		$ext=explode(".", $str);
		$ex=$ext[(count($ext)-1)];
		if(strlen($str)>15){
			$str = substr($str, 0, 15).".".$ex;
		}
		$uploadfile = $uploaddir . basename($str);
			
		if(move_uploaded_file($_FILES['userfile']['tmp_name'], $uploadfile)) {
			chmod($uploadfile, 0777);		
		}
		else {
			echo "UNABLE TO STORE ....";
		}
		exec ("ffmpeg -r 25 -f lavfi -i aevalsrc=0 -loop 1 -i ".$uploadfile." -t 15 -shortest -c:v copy -c:a aac -strict experimental \"".$_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/myMedia/Anim-".rand(10000,40000).".webm\"");
	
	}


	if($_POST['audio']=="yes"){

                $datime = date("Y-m-d-H.i.s", time() ) ; # - 3600*7
                $uploadDir = $_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/myMediaAudio";
                $uploaddir = $uploadDir."/";
                $str=str_replace(" ", "_",$_FILES['userfile']['name']);
                $ext=explode(".", $str);
                $ex=$ext[(count($ext)-1)];
                if(strlen($str)>15){
                        $str = substr($str, 0, 15).".".$ex;
                }
                $uploadfile = $uploaddir . basename($str);

                if(move_uploaded_file($_FILES['userfile']['tmp_name'], $uploadfile)) {
                        chmod($uploadfile, 0777);
                }
                else {
                        echo "UNABLE TO STORE ....";
                }


	}

}



if( $_POST['userid']!=""){
	$rawData = $_POST['imgBase64'];
	$filteredData = explode(',', $rawData);
	$unencoded = base64_decode($filteredData[1]);
	$datime = date("Y-m-d-H.i.s", time() ) ; # - 3600*7
	$userid  = $_POST['userid'] ;
	$fp = fopen($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/".$datime."-".$userid."xx.jpg", "w");
	fwrite($fp, $unencoded);
	fclose($fp);
	exec("ffmpeg -f lavfi -i aevalsrc=0 -t 15  -q:a 9 -acodec libmp3lame 30sec.mp3");
	exec("ffmpeg -loop 1 -t 15  -y -i \"".$_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/".$datime."-".$userid."xx.jpg\" -i 30sec.mp3 \"".$_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/myMedia/".$datime."-".$userid.".webm\"");
}
if($_POST['txtName']!=""){
	$data=str_replace("\\", "",$_POST['text'])."<next>".str_replace("\\", "", $_POST['hal'])."<next>".str_replace("\\", "",$_POST['val'])."<next>".str_replace("\\", "",$_POST['fontSize'])."<next>".str_replace("\\", "",$_POST['red']).
	"<next>".str_replace("\\", "",$_POST['green'])."<next>".str_replace("\\", "",$_POST['blue'])."<next>".str_replace("\\", "",$_POST['startTime'])."<next>".str_replace("\\", "",$_POST['textDuration']);
	$f=fopen($_SERVER['DOCUMENT_ROOT']."/text/data[".$_SERVER['REMOTE_ADDR']."]/".$_POST['txtName'].".src.php", "w");
	fwrite($f, $data);
	fclose($f);
}
	
?>
