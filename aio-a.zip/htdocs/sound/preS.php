<?php

/*
 -i \"concat:";

  exec("ffmpeg -f lavfi -i aevalsrc=0 -t 15  -q:a 9 -acodec libmp3lame \"".$_SERVER['DOCUMENT_ROOT']."/temp/".$dirtysec."\"");

'/sound/preS.php?file=<?php echo $insNr;?>&secs='+ssi+'&f='+Math.random());

*/
$dirtysec="temp.mp3";
@unlink($_SERVER['DOCUMENT_ROOT']."/temp/".$dirtysec );
@unlink($_SERVER['DOCUMENT_ROOT']."/temp/out.mp3" );

exec("ffmpeg -f lavfi -i aevalsrc=0 -t ".$_GET['secs']."   -q:a 9 -acodec libmp3lame \"".$_SERVER['DOCUMENT_ROOT']."/temp/".$dirtysec."\"");
exec("ffmpeg -i \"concat:".$_SERVER['DOCUMENT_ROOT']."/temp/".$dirtysec."|".$_SERVER['DOCUMENT_ROOT']."/".$_GET['file']."\"   -filter:a \"atempo=".$_GET['speed']."\"    ".$_SERVER['DOCUMENT_ROOT']."/temp/out.mp3");
@unlink($_SERVER['DOCUMENT_ROOT']."/".$_GET['file'] );
@copy($_SERVER['DOCUMENT_ROOT']."/temp/out.mp3" , $_SERVER['DOCUMENT_ROOT']."/".$_GET['file']);



?>

