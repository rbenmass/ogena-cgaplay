<?php


	function getDrum($styl){
	
	if($styl==""){
	$style="*RANDOM*";
	}
	else{
	$style=$styl;
	}
	$list = array();

	$list[]= array("drummachines-loops.htm", "Drummachines");
	$list[]= array("african.htm","African drumloops");
	$list[]= array("ambient.htm","Ambient drumloops");
	$list[]= array("arab.htm","Arab drumloops");
	$list[]= array("blues.htm","Blues drumloops");
	$list[]= array("dance.htm","Dance drumloops");
	$list[]= array("disco.htm","Disco drumloops");
	$list[]= array("drumloops.htm","Other drumloops");
	$list[]= array("rumnbass.htm","Drumnbass loops");
	$list[]= array("electro.htm","Electro drumloops");
	$list[]= array("unk.htm","Funk drumloops");
	$list[]= array("hiphop.htm","Hiphop drumloops");
	$list[]= array("house-drumloops.htm","House drumloops");
	$list[]= array("jazz.htm","Jazz drumloops");
	$list[]= array("latin.htm","Latin drumloops");
	$list[]= array("metal.htm","Metal drumloops");
	$list[]= array("rap.htm","Rap drumloops");
	$list[]= array("reggae.htm","Regaae drumloops");
	$list[]= array("rnb.htm","RnB drumloops");
	$list[]= array("rock.htm","Rock drumloops");
	$list[]= array("samba.htm","Samba drumloops");
	$list[]= array("songo.htm","Songo drumloops");
	$list[]= array("techno.htm","Techno drumloops");
	$list[]= array("trance.htm","Trance drumloops");
	$list[]= array("triphop.htm","Triphop drumloops");
	$list[]= array("world.htm","World drumloops");

	$thegen=0;

	$st= strtolower($style);
	$ind=-1;
	
	$its=rand(0, (count($list)-1));
	$itz= $list[$its];
	$it = $itz[0];	
	
	for($i=0;$i<count($list);$i++){
		$next = $list[$i];
		$nurl = $next[0];
		$desc=" ".strtolower($next[1]);
		if(strpos($desc, $st)>0 ){
		$ind = $i;
		$it = $nurl;
		}
		

	}

	$page="http://eng.universal-soundbank.com/".$it;	
	$pg = file_get_contents($page);	
	$rando = rand(1, 10);
	
	$items=explode("mp3:\"http", $pg);
	$it = $items[$rando];
	
	
	$end = strpos($it, "\",");
	$url="http".substr($it, 0, $end);
		
	return $url;
}



echo getDrum($_GET['style']);


?>
