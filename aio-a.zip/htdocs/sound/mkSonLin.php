<?php
exec("php mkSon.php ".$_GET['time']);

?>
