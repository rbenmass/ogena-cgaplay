http://www.ogena.net/apps/data/sound/086_mello-triplet-feel-bass-thingy.mp3
