<?php

exec("c:\php\php.exe mkSong.php ".$_GET['time'] );

?>