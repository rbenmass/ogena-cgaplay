<?php
header('Access-Control-Allow-Origin: *');

	@mkdir("volume");
	$f = @fopen("volume/".$_SERVER['REMOTE_ADDR'].".volume.txt", "w");

	if($_GET['volume']>=0){
		@fwrite($f, $_GET['volume']);
	}
	else{
@fwrite($f, '0.6');

	}
	@fclose($f);
?>
