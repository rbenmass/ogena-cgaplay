<?php


	function getDrum($styl){
	
	if($styl==""){
	$style="*RANDOM*";
	}
	else{
	$style=$styl;
	}
	$list = array();

$list[]= array("synth-minimoog.htm", "Moog - Minimoog");
$list[]= array("synth-moog-prodigy.htm", "Moog - Prodigy");
$list[]= array("synth-matrix1000.htm", "Oberheim - Matrix 1000");
$list[]= array("synth-pro-one.htm", "Sequential Circuits - Pro One");
$list[]= array("synth-prophet-600.htm", "Sequential Circuits - Prophet 600");
$list[]= array("synth-gated-chords.htm", "Synths - Gated chords");
$list[]= array("synth-sequences.htm", "Synths   - Sequence loops ");
$list[]= array("synth-sequences-dance.htm", "Synths - Loops dance music");
$list[]= array("synthetisers.htm", "Synths  - others - Textures");

	$thegen=0;

	$st= strtolower($style);
	$ind=-1;
	
	$its=rand(0, (count($list)-1));
	$itz= $list[$its];
	$it = $itz[0];	
	
	for($i=0;$i<count($list);$i++){
		$next = $list[$i];
		$nurl = $next[0];
		$desc=" ".strtolower($next[1]);
		if(strpos($desc, $st)>0 ){
		$ind = $i;
		$it = $nurl;
		}
		

	}

	$page="http://eng.universal-soundbank.com/".$it;	
	$pg = file_get_contents($page);	

    $items=explode("mp3:\"http", $pg);


	$rando = rand(1, (count($items)-1));
	
	$items=explode("mp3:\"http", $pg);
	$it = $items[$rando];
	
	
	$end = strpos($it, "\",");
	$url="http".substr($it, 0, $end);
		
	return $url;
}



echo getDrum($_GET['style']);


?>
