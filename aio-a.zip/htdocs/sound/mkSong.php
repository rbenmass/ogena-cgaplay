<?php

	$docr="c:/Program Files/Apache Software Foundation/Apache2.2/htdocs";
	@unlink("".$docr."/htdocs/sound/t00.wav");
	@unlink("".$docr."/htdocs/sound/t01.wav");
	@unlink("".$docr."/htdocs/sound/t02.wav");
	@unlink("".$docr."/htdocs/sound/t03.wav");
	@unlink("".$docr."/htdocs/sound/t04.wav");
	@unlink("".$docr."/htdocs/sound/t44.wav");
	@unlink("".$docr."/htdocs/sound/t444.wav");
	@unlink("".$docr."/htdocs/sound/t0x.wav");
	@unlink("".$docr."/htdocs/images/frames/myClip_.wav");
	@unlink("".$docr."/htdocs/images/frames/myClip.mp3");	
	@mkdir("".$docr."/htdocs/sound/extra");


	@mkdir("".$docr."/htdocs/sound/melodyTemp");


	$dirim =scanDir("".$docr."/htdocs/sound/melodyTemp");
	for($ii=0;$ii<count($dirim);$ii++)
	{
		if($dirim[$ii]=="." || $dirim[$ii]=="."){
		}
		else{
		
			@unlink("".$docr."/htdocs/sound/melodyTemp/".$dirim[$ii]);
				
			}
		}

		$dirim =@scanDir("".$docr."/htdocs/sound/tuneTemp");
	for($ii=0;$ii<count($dirim);$ii++)
	{
		if($dirim[$ii]=="." || $dirim[$ii]=="."){
		}
		else{
		
		
				
			}
		}	
		
		
				function getXXX( $arg1,$ex,  $n, $d){
	$exec="";
		$hz=440;


		$a["a"]=$mainfr-$hz-$hz-$hz-$hz-$hz-$hz-$hz;
		$a["b"]=$mainfr-$hz-$hz-$hz-$hz-$hz-$hz;
		$a["c"]=$mainfr-$hz-$hz-$hz-$hz-$hz;
		$a["d"]=$mainfr-$hz-$hz-$hz-$hz;
		$a["e"]=$mainfr-$hz+$hz-$hz;

		$a["f"]=$mainfr-$hz-$hz;
		$a["g"]=$mainfr-$hz;
		$a["h"]=$mainfr;
		$a["i"]=$mainfr+$hz;
		$a["j"]=$mainfr+$hz+$hz;

		$a["k"]=$mainfr+$hz+$hz+$hz;
		$a["l"]=$mainfr+$hz+$hz+$hz+$hz;
		$a["m"]=$mainfr+$hz+$hz+$hz+$hz+$hz;
		$a["n"]=$mainfr+$hz+$hz+$hz+$hz+$hz+$hz;
		$a["o"]=$mainfr+$hz+$hz+$hz+$hz+$hz+$hz+$hz;
	
	
		$files = "\"".$arg1.".".$d.".".$ex."\"";	
		$file = "\"".$arg1.".".$d.".".$n.".".$ex."\"";

		$fileo = $arg1.".".$d.".".$n.".".$ex;




		return $fileo;

		}
		

		function getXX( $arg1,$ex,  $n, $d){
	$exec="";
		$hz=880;
		$mainfr = 36000;

		
		$docr="c:/Program Files/Apache Software Foundation/Apache2.2/htdocs";
		
		
		$drr= "ffmpeg.exe  -i  \"".$arg1."\"  2>&1   | find \"Duration\" > \"".$docr."/htdocs/images/raw_Durationn\" \necho cls > \"".$docr."/htdocs/scripts/sync/temp.bat\" ";
		echo $drr;
		exec($drr);
		echo $drr.".\n";
		

		
		$da = @file_get_contents("http://127.0.0.1/images/raw_Durationn");


			echo $da;
		$durrr= $da;
		
		echo $da."----------------------------------------";

		$str= strpos($da, "e:");
		$end= strpos($da, "kb");
		$fff = substr($da, (2+$str),($end-$str)); 
		$fgg = 	$fff+0;	
		$sec=$fgg*1000;


$mainfr = $sec;
$hz=ceil($sec/8);
echo ":".$sec;
		
		
		
		
		
		
		
		
		$a["a"]=$mainfr-$hz-$hz-$hz-$hz-$hz-$hz-$hz;
		$a["b"]=$mainfr-$hz-$hz-$hz-$hz-$hz-$hz;
		$a["c"]=$mainfr-$hz-$hz-$hz-$hz-$hz;
		$a["d"]=$mainfr-$hz-$hz-$hz-$hz;
		$a["e"]=$mainfr-$hz+$hz-$hz;

		$a["f"]=$mainfr-$hz-$hz;
		$a["g"]=$mainfr-$hz;
		$a["h"]=$mainfr;
		$a["i"]=$mainfr+$hz;
		$a["j"]=$mainfr+$hz+$hz;

		$a["k"]=$mainfr+$hz+$hz+$hz;
		$a["l"]=$mainfr+$hz+$hz+$hz+$hz;
		$a["m"]=$mainfr+$hz+$hz+$hz+$hz+$hz;
		$a["n"]=$mainfr+$hz+$hz+$hz+$hz+$hz+$hz;
		$a["o"]=$mainfr+$hz+$hz+$hz+$hz+$hz+$hz+$hz;
	
	
		$files = "\"".$arg1.".".$d.".".$ex."\"";	
		$file = "\"".$arg1.".".$d.".".$n.".".$ex."\"";

		$fileo = $arg1.".".$d.".".$n.".".$ex;

		$exec = "ffmpeg.exe -y -i \"".$arg1 . "\" -filter_complex \"asetrate=".$a[$n] ."\" ".$file. "\n ";		
		$exec.= "ffmpeg.exe  -y -i ".$file . " -i ".$files." -filter_complex \"amerge=inputs=2\" \"".$fileo."\" \n";


	echo $exec;
		exec($exec);

		return $exec;

		}



		
		function makeMeleody($arg_, $argout, $loops){
			
		$arg = $arg_.".mp3";
		exec("ffmpeg.exe -i \"".$arg_. "\" \"".$arg."\"");	
			
		$docr="c:/Program Files/Apache Software Foundation/Apache2.2/htdocs";	
			
		$drr= "ffmpeg.exe  -i  \"".$arg."\"  2>&1   | find \"Duration\" > \"".$docr."/htdocs/images/raw_Durationn\" \necho cls > \"".$docr."/htdocs/scripts/sync/temp.bat\" ";
		echo $drr;
		exec($drr);
		echo $drr."..................\n";
		

		$fitt  =fopen("".$docr."/htdocs/scripts/sync/temp.bat", "w");
		fwrite($fitt, $drr);
		fclose($fitt);
		$frw= file_exists("".$docr."/htdocs/images/raw_Durationn");
		while($frw==false){
			sleep(3);
			echo "A...\n";
		$frw= file_exists("".$docr."/htdocs/images/raw_Durationn");
		}
		
		$da = @file_get_contents("http://".getenv("HTTP_HOST")."/images/raw_Durationn");
		
		$durrr= $da;
		
		echo $da."----------------------------------------";

		$fi=explode(",", $durrr);
		$fff = explode(".",$fi[0] );
		
		$fgg = 	$fff[3];;	
		$sec=$fgg;

		$ic=" -i \"concat:";
		$r="";
		$extc = explode(".", $arg);
		$ex = $extc[(count($extc) -1)];

		$exec="";

		for($i=0;$i<8;$i++){
			$r.=$arg;
			$lsttm=$arg.".".$i.".".$ex;
			$exec.="ffmpeg.exe  -y ".$ic.$r ."\" -vol 0 \"".$arg.".".$i.".".$ex. "\" & ";
			$r.="|";		
		}

	
		 $drr= $exec." \necho cls > \"".$docr."/htdocs/scripts/sync/temp.bat\"";
		//echo $drr;
		exec($drr);
		$fi  =fopen("".$docr."/htdocs/scripts/sync/temp.bat", "w");
		fwrite($fi, $drr);
		fclose($fi);

		$frwt= file_exists($lsttm);
		while($frwt==false){
			sleep(3);
			$frwt= file_exists($lsttm);
			echo "B.....\n"; 
		}
		sleep(3);	
		$pattern="";
		for($j=1;$j<=$loops;$j++){
		$az[0]="a";
		$az[1]="b";
		$az[2]="c";
		$az[3]="d";
		$az[4]="e";


		$az[5]="f";
		$az[6]="g";
		$az[7]="h";
		$az[8]="j";
		$az[9]="j";


		$az[10]="k";
		$az[11]="l";
		$az[12]="m";
		$az[13]="n";
		$az[14]="o";

		$pattern.=$az[rand(0, (count($az)-1))].rand(1,7);

		}

	$exec="";
	
	$filesss= "";
	
	 for($i=0;$i<(strlen($pattern)-2);$i=$i+2 ){
			$note = substr($pattern, $i, 1 );
			$dur = substr($pattern, ($i+1), 1 );
			$filesss.= getXX($arg, $ex,  $note, $dur ). " \n";
			$rff[]=getXXX($arg, $ex,  $note, $dur);
			$filess[]=getXXX($arg, $ex,  $note, $dur);
		}

		$drr = $filesss." \necho cls > \"".$docr."/htdocs/scripts/sync/temp.bat\"";

		$fi  =fopen("".$docr."/htdocs/scripts/sync/temp.bat", "w");
		fwrite($fi, $drr);
		fclose($fi);
	                     
		$frwtnnat= false;

			
			
			
		$r=$ic;
		for($i=0;$i<count($rff);$i++){
			$r.=$rff[$i]."|";
			echo "...".$rff[$i]." \n";

			
				
		}
 
		
		
		$rr=substr($r, 0, (strlen($r)-1))."\" ";

	
		$exec= "ffmpeg.exe -y ".$rr . "  \"".$argout ."\"\n";

		echo $exec;
		
		 $drr= $exec." \necho cls > \"".$docr."/htdocs/scripts/sync/temp.bat\"";
		
		exec($exec);
		
		$fi  =fopen("".$docr."/htdocs/scripts/sync/temp.bat", "w");
		fwrite($fi, $drr);
		fclose($fi);

		sleep(1);	

	}







	function playInstr($path, $duration, $nrStops, $flnm, $silence){
		$instrm = scanDir($path);
		$drr="";
		
$docr="".$docr."/htdocs";


		$ktk=0;
		for($i=0;$i<count($instrm);$i++){
		echo "dsdsds";
			if($instrm[$i]=="." || $instrm[$i]==".." ){
			}
			else{
			
			if(strpos($instrm[$i], ".php")>0){
			
			}
			else{
			
			$inst[]=$instrm[$i];
			
			}
			}
			
			}
				


		$ttt=0;
		$star=0;
		$lpp=" -i \"concat:";
		
		
		$trp=0;
		while($ttt<$duration){
		
		if($trp>=count($inst)){
		$trp=0;
		}
		$stra = $trp;
		$trp++;
		
		$inin= $inst[$stra];
		$trs= $path."/".$inin."|";  
		
		echo "Choosing instr:".$inin."\n";

		
		exec("ffmpeg.exe -i  \"".$path."/".$inin."\"  2>&1   | find \"Duration\"  > \"".$docr."/htdocs/images/_rawDuration");
			
		
		$fc="";
		
		$handle = fopen("".$docr."/htdocs/images/_rawDuration", "r");
		if ($handle) {
				while (($line = fgets($handle)) !== false) {
					$fc.=$line;
				}
			} 
		else {
		
		}
		echo "........................................".$fc;
		$star=$star+1;
		$gf=explode(",", $fc);		
		$fi=explode(":", $gf[0]);
		$hr= $fi[1]*60*60;
		$mi= $fi[2]*60;
		$se = $fi[3]+1;
		$tot=$hr+$mi+$se;

		$nrOfLoops = rand(1,$nrStops); 

		
		for($k=0;$k<$nrOfLoops;$k++){
		if(false && rand(0,10)>4		&& $silence==true){
		$lpp.="".$docr."/htdocs/sound/silent/06sec.mp3|";
		$ttt+=6;
		}
		else{
		
		
		if(rand(0,10)>=5 || $silence==false){
		$lpp.=$trs;
		$ttt+=$tot;
		}
		else{
				$lpp.="".$docr."/htdocs/sound/silent/06sec.mp3|";
				$ttt+=6;
		}
		
		
		}
		}
		echo "time start".$ttt." ".$nrOfLoops. " sample:".$inin."\n";	
		}
		
		$llp = substr($lpp, 0, (strlen($lpp)-1))."\" ";
		
		
		$drr = "ffmpeg.exe ".$llp. "   \"".$docr."/htdocs/sound/".$flnm."\"";
	
		
		echo "\nTotal Seconds:".$ttt."\n";
	
		exec($drr);
	
	}
	
	
	$t="".$docr."/htdocs/sound/drums";
	$tr="t00.wav";
	playInstr($t, $argv[1], 8, $tr, false);
	$doo=file_exists("".$docr."/htdocs/sound/t00.wav");	
	while($doo==false){
	sleep(1);
	$doo=file_exists("".$docr."/htdocs/sound/t00.wav");	
	}

	$ta="".$docr."/htdocs/sound/vocals";
	$tra="t01.wav";
	playInstr($ta, $argv[1], 5, $tra, true);
	$doo1=file_exists("".$docr."/htdocs/sound/t01.wav");	
	while($doo1==false){
	sleep(1);
	$doo1=file_exists("".$docr."/htdocs/sound/t01.wav");	
	}

	$tb="".$docr."/htdocs/sound/instruments";
	$trb="t02.wav";

	playInstr($tb, $argv[1], 8, $trb, true);
	$doo2=file_exists("".$docr."/htdocs/sound/t02.wav");	
	while($doo2==false){
	sleep(1);
	$doo2=file_exists("".$docr."/htdocs/sound/t02.wav");	
	}
	
	$tbu="".$docr."/htdocs/sound/bases";
	$tru="t03.wav";
	playInstr($tbu, $argv[1], 5, $tru, true);
	$doo3=file_exists("".$docr."/htdocs/sound/t03.wav");			
	
	while($doo3==false){
	sleep(1);
	$doo3=file_exists("".$docr."/htdocs/sound/t03.wav");	
	}
	
	$tbu1="".$docr."/htdocs/sound/melody";
	$tbur="".$docr."/htdocs/sound/melodyTemp";
	$dsa = scanDir($tbu1);
	for($h=0;$h<count($dsa);$h++){
	
		if($dsa[$h]=="." || $dsa[$h]==".."){
		}
		else{
		exec("ffmpeg -i \"".$tbu1."/".$dsa[$h]. "\" \"".$tbur."/sample.".$h.".mp3\"");
		}
	
	}
	
	
	
		$tbu1="".$docr."/htdocs/sound/tune";
	$tbur="".$docr."/htdocs/sound/tuneTemp";
	$dsa = scanDir($tbu1);
	for($h=0;$h<count($dsa);$h++){
	
		if($dsa[$h]=="." || $dsa[$h]==".."){
		}
		else{
		exec("ffmpeg -i \"".$tbu1."/".$dsa[$h]. "\" \"".$tbur."/sample.".$h.".mp3\"");
		}
	
	}
	
	
	
	sleep(2);
	
	$t="".$docr."/htdocs/sound/melodyTemp";
	$tr="t0x.wav";
	playInstr($t, $argv[1], 3, $tr, true);
	$doo=file_exists("".$docr."/htdocs/sound/t0x.wav");	
	while($doo==false){
	sleep(1);
	$doo=file_exists("".$docr."/htdocs/sound/t0x.wav");	
	}
	



	$dirf = scandir("".$docr."/htdocs/sound/tuneTemp");
	for($j=0;$j<count($dirf);$j++){
		if($dirf[$j]=="." || $dirf[$j]==".."){

		}
		else{
			$fll=$dirf[$j];
			$has=true;
			$convert= "ffmpeg.exe  -i \"".$docr."/htdocs/sound/tuneTemp/".$dirf[$j]."\" \"".$docr."/htdocs/sound/tuneTemp/melodyTemp.wav\" & ";
		}

	}
	
	$melodyh="";
	
	
		if($has==true){
	$melodyh ="  -i \"".$docr."/htdocs/sound/t55.wav\" ";
		echo $drr;
		
		$drr=$convert;
		exec($drr);

	$doo44=file_exists("".$docr."/htdocs/sound/tuneTemp/melodyTemp.wav");			
	
	while($doo44==false){
	sleep(3);
	$doo44=file_exists("".$docr."/htdocs/sound/tuneTemp/melodyTemp.wav");
	}
	sleep(3);
	@makeMeleody("".$docr."/htdocs/sound/tuneTemp/melodyTemp.wav", "".$docr."/htdocs/sound/tuneTemp/melody.wav", rand(6, 12));
@copy("".$docr."/htdocs/sound/tuneTemp/melody.wav", "".$docr."/htdocs/sound/tune/melody.wav");
	
		$dirim =scanDir("".$docr."/htdocs/sound/tuneTemp");
	for($ii=0;$ii<count($dirim);$ii++)
	{
		if($dirim[$ii]=="." || $dirim[$ii]=="."){
		}
		else{
		
			
				
			}
		}

	
		sleep(1);	
	
		$tbd4="".$docr."/htdocs/sound/tune";
	$trd4="t444.wav";
		
	playInstr($tbd4, $argv[1], 3, $trd4, true);
	$doo44=file_exists("".$docr."/htdocs/sound/t444.wav");			
	while($doo44==false){
	sleep(7);
	$doo44=file_exists("".$docr."/htdocs/sound/t444.wav");	
	}
	
		}



















	$tbd="".$docr."/htdocs/sound/samples";
	$trd="t04.wav";
		
	playInstr($tbd, $argv[1], 3, $trd, true);
	$doo4=file_exists("".$docr."/htdocs/sound/t04.wav");			
	while($doo4==false){
	sleep(3);
	$doo4=file_exists("".$docr."/htdocs/sound/t04.wav");	
	}

	
	
	$drr = "ffmpeg.exe -i \"".$docr."/htdocs/sound/t00.wav\"  -i \"".$docr."/htdocs/sound/t01.wav\"  -i \"".$docr."/htdocs/sound/t02.wav\"   -i \"".$docr."/htdocs/sound/t03.wav\"  -i \"".$docr."/htdocs/sound/t0x.wav\"  -i \"".$docr."/htdocs/sound/t04.wav\"  -i \"".$docr."/htdocs/sound/t444.wav\" -ar 22050  -filter_complex amix=inputs=7  \"".$docr."/htdocs/images/frames/myClip_.wav\"";
	@exec($drr);
	
		$drr = "ffmpeg.exe   -t ".$argv[1]." -i \"".$docr."/htdocs/images/frames/myClip_.wav\" \"".$docr."/htdocs/images/frames/myClip.mp3\"";
	@exec($drr);
	


	
	$fwi  =fopen("".$docr."/htdocs/images/frames/strec", "w");

	fwrite($fwi, "2");
	@chmod("".$docr."/htdocs/sound/strec", 0777);
	fclose($fwi);
	die();
	


	

	
?>
