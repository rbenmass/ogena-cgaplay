sudo cp /home/Users/Public/.config/user-dirs.dirs /var/www/html/sound/environment.txt
