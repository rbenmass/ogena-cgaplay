<?php

	$docr="/var/www/html";
	

	@unlink("t00.wav");
	@unlink("t01.wav");
	@unlink("t02.wav");
	@unlink("t03.wav");

	@unlink("t44.wav");
	@unlink("t04.wav");

	@unlink("t05.wav");

       @unlink("t06.wav");


	@unlink("myClip_.wav");
	@unlink("myClipy.wav");
	@unlink("myClip.wav");	
	
	$ar = $argv[1];
	$argv[1]=2*$ar;
	@mkdir("".$docr."/sound/melodyTemp");


	$dirim =scanDir("".$docr."/sound/melodyTemp");
	for($ii=0;$ii<count($dirim);$ii++)
	{
		if($dirim[$ii]=="." || $dirim[$ii]=="."){
		}
		else{
		
			@unlink("".$docr."/sound/melodyTemp/".$dirim[$ii]);
				
			}
		}


		function getXX( $arg1,$ex,  $n, $d){

		$hz=880;


		$a["a"]=30/30*.5; 
		$a["b"]=34/30*.5;
		$a["c"]=38/30*.5;
		$a["d"]=42/30*.5;
		$a["e"]=46/30*.5;

		$a["f"]=50/30*.5;;
		$a["g"]=54/30*.5;

		$a["h"]=1;  

		$a["i"]=68.5/30*.5;
		$a["j"]=77/30*.5;

		$a["k"]=85.5/30*.5;
		$a["l"]=94/30*.5;;
		$a["m"]=102.5/30*.5;
		$a["n"]=111/30*.5;
		$a["o"]=119.5/30*.5;
		 
	



	
		$files = $arg1.".".$d.".".$ex;	
		$file = $arg1.".".$d.".".$n.".".$ex;
                $file1 = $arg1.".".$d.".1.".$n.".".$ex;



		$fileo = $arg1.".".$d.".".$n.".o.".$ex;

		exec("ffmpeg -y -i ".$arg1 . " -filter:a atempo=".$a[$n] ." ".$file1);

		 exec("ffmpeg -y -i ".$file1 . " -filter:a atempo=".$a[$n] ." ".$file);


		exec("ffmpeg -y -i ".$file . " -i ".$files." -filter_complex amerge=inputs=2 ".$fileo);

		return $fileo;

		}



		
		function makeMeleody($arg_, $argout, $loops){
		$arg = $arg_.".mp3";
		exec("ffmpeg -i ".$arg_ ." ".$arg);

                $sysroot="".$docr.""; //"c:/program files/apache software foundation/apache2.2/htdocs";
                $ffmpegbin = "ffmpeg";  //"c:/program files/apache software foundation/apache2.2/cgi-bin/bin/ffmpeg.exe";
                $zoek= "grep"; //"find";
                $duur = "Duration"; // "\"Duration\"";
                $extr = " | cut -d ' ' -f 4 | sed s/,// ";  //"";
                $schoon = "clear"; // "cls";
                $tmpexe = "temp.sh"; //"temp.bat";
                $stopp = "killall"; //"taskkill /f /im";
                $exeffm ="ffmpeg"; //"ffmpeg.exe";
                $phpexe ="php"; // "php.exe";
                $kopieer= "cp"; // "copy";
                $verwijder = "rm"; //"del";


		$drri= " ".$ffmpegbin." -i  \"".$arg."\"  2>&1   | ".$zoek." ".$duur." ".$extr." ";
		$durrr= exec($drri);



		echo $durrr;

		$fi=explode(":", $durrr);
		$fff = explode(".",$fi[2] );
		$fgg = 	substr($fff[1], 0,1);	
		$sec=(float)$fff[0]+(0.01+1-(1/(float)$fgg));

		$ic=" -i \"concat:";
		$r="";
		$extc = explode(".", $arg);
		$ex = $extc[(count($extc) -1)];

		for($i=0;$i<3;$i++){
			$r.=$arg;
			exec("ffmpeg -y ".$ic.$r ."\" -vol 0 ".$arg.".".$i.".".$ex. "\n");
			$r.="|";		
		}

		$pattern="";
		for($j=1;$j<=$loops;$j++){
		$az[0]="a";
		$az[1]="b";
		$az[2]="c";
		$az[3]="d";
		$az[4]="e";


		$az[5]="f";
		$az[6]="g";
		$az[7]="h";
		$az[8]="j";
		$az[9]="j";


		$az[10]="k";
		$az[11]="l";
		$az[12]="m";
		$az[13]="n";
		$az[14]="o";
		

		$pattern.=$az[rand(0, (count($az)-1))].rand(1,7);

		}

	
		
	 for($i=0;$i<(strlen($pattern)-2);$i=$i+2 ){
			$note = substr($pattern, $i, 1 );
			$dur = substr($pattern, ($i+1), 1 );
			$filess[]= getXX($arg, $ex,  $note, $dur );
		}


		$r=$ic;
		for($i=0;$i<count($filess);$i++){
			$r.=$filess[$i]."|";
		
				
		}

	$tp=$ic;
	$rr0=$ic;

		$rr=substr($r, 0, (strlen($r)-1)) ;

	  $lpp=" -i \"concat:";


		$dira = scandir($sysroot."/sound");

		for($j=0;$j<count($dira);$j++){
		echo "....".$j;

		if($dira[$j]=="." || $dira[$j]==".."){
		}
	else{

		if(substr($dira[$j], 0, strlen($arg))==$arg) {
			$dd[]=$dira[$j];

		}
}

		}




		for($j=0;$j<$loops;$j++){
			$tr = rand(10,30);
			for($i=0;$i<$tr;$i++){
				$lpp.=$sysroot."/sound/".$dd[rand(0, (count($dd)-1))]."|";
		

			}
		}
	
	$nex = substr($lpp, 0, (strlen($lpp)-1))."\"";
	echo $nex;


	
		exec("ffmpeg  ".$nex." ".$argout);




	}

//makeMeleody("nylo-re.wav", "out.wav" , 5);
//die();


		$sysroot="".$docr.""; //"c:/program files/apache software foundation/apache2.2/htdocs";
		$ffmpegbin = "ffmpeg";  //"c:/program files/apache software foundation/apache2.2/cgi-bin/bin/ffmpeg.exe";
		$zoek= "grep"; //"find";
		$duur = "Duration"; // "\"Duration\"";
		$extr = " | cut -d ' ' -f 4 | sed s/,// ";  //"";
		$schoon = "clear"; // "cls";
		$tmpexe = "temp.sh"; //"temp.bat";
		$stopp = "killall"; //"taskkill /f /im";
		$exeffm ="ffmpeg"; //"ffmpeg.exe";
		$phpexe ="php"; // "php.exe";
		$kopieer= "cp"; // "copy";
		$verwijder = "rm"; //"del";
	
	function playInstr($path, $duration, $nrStops, $flnm, $silence, $ttx){

	$docr="/var/www/html";

		$instrm = scanDir($path);
		$drr="";
		
		$sysroot="".$docr.""; //"c:/program files/apache software foundation/apache2.2/htdocs";
		$ffmpegbin = "ffmpeg";  //"c:/program files/apache software foundation/apache2.2/cgi-bin/bin/ffmpeg.exe";
		$zoek= "grep"; //"find";
		$duur = "Duration"; // "\"Duration\"";
		$extr = " | cut -d ' ' -f 4 | sed s/,// ";  //"";
		$schoon = "clear"; // "cls";
		$tmpexe = "temp.sh"; //"temp.bat";
		$stopp = "killall"; //"taskkill /f /im";
		$exeffm ="ffmpeg"; //"ffmpeg.exe";
		$phpexe ="php"; // "php.exe";
		$kopieer= "cp"; // "copy";
		$verwijder = "rm"; //"del";

		
		$dirim =scanDir("/var/www/images");
		for($ii=0;$ii<count($dirim);$ii++)
		{
			if($dirim[$ii]=="." || $dirim[$ii]=="."){
			}
			else{
				if(substr($dirim[$ii], 0, 4)=="_raw"){
				@unlink("/var/www/images/".$dirim[$ii]);
				}
			}
		}


		$ktk=0;
$durrr="";
		for($i=0;$i<count($instrm);$i++){

			if($instrm[$i]=="." || $instrm[$i]==".." ){
			}
			else{
			
			if(!(strpos($instrm[$i], ".mp3")  ||  strpos($instrm[$i], ".wav")  )>0){
			
			}
			else{
			$inst[]=$instrm[$i];
		 $drri= " ".$ffmpegbin." -i  \"".$path."/".$instrm[$i]."\"  2>&1   | ".$zoek." ".$duur." ".$extr." & ";
			$ktk=$ktk+1;


			$durrr= exec($drri);

		$durrr.=" , ;";


			}
			}
			
			}



		$ttt=0;
		$star=0;
		$lpp=" -i \"concat:";
		$iii=0;
		$dd=explode(";", $durrr);
		$trp=0;

		$gt=0;
	$ttt=0;
		while($ttt<$duration){
		
		
		$trp++;

		if($trp>=count($inst)){
		$trp=0;
		}
		
		$inin= $inst[$trp];
		$trs= $path."/".$inin."|";  
		
		echo "Choosing instr:".$inin."\n";

		$fc="";



		$tot=1.2;

	

		$nrOfLoops = rand(1,3); 

			
		for($k=0;$k<$nrOfLoops;$k++){
	

		if(rand(0,10)>$ttx && $silence==true){
		$lpp.="".$docr."/sound/silent/06sec.mp3|";
		$ttt+=6;
		}
		else{
		$lpp.=$trs;
		$ttt+=$tot;
		}

		//}
		}


		echo "time start".$ttt." ".$nrOfLoops. " sample:".$inin."\n";	
		}
		
		$llp = substr($lpp, 0, (strlen($lpp)-1))."\" ";
		$drr0 = $ffmpegbin."   ". $llp." -acodec copy  ".$docr."/sound/" .$flnm;


	
		

	echo $drr0.";";
	exec($drr0);

  //     exec($drr00);

	sleep(1);
	
	}
	



	$dr=scandir($sysroot);

	for($d=0;$d<count($dr);$d++){

		if($dr[$d] =="." || $dr[$d]==".."){
		}
		else{

			if(substr($dr[$d], 0, 5)=="defin"){
				exec("mv ".$sysroot."/".$dr[$d]. " ".$sysroot."/sound/vocals/".$dr[$d]);
			}

		}
	}





	
	$ta=$sysroot."/sound/drums";
	$tra="t00.wav";
	playInstr($ta, $argv[1], 8, $tra, false, 6);
	$dooa=file_exists("".$docr."/sound/t00.wav");	
	while($dooa==false){
	sleep(5);
	$dooa=file_exists("".$docr."/sound/t00.wav");	
	}


	$ta=$sysroot."/sound/vocals";
	$tra="t01.wav";
	playInstr($ta, $argv[1], 5, $tra, true, 3);
	$doo1=file_exists("".$docr."/sound/t01.wav");	
	while($doo1==false){
	sleep(5);
	$doo1=file_exists("".$docr."/sound/t01.wav");	
	}

	$tb=$sysroot."/sound/instruments";
	$trb="t02.wav";

	playInstr($tb, $argv[1], 5, $trb, true, 3);
	$doo2=file_exists($sysroot."/sound/t02.wav");	
	while($doo2==false){
	sleep(5);
	$doo2=file_exists($sysroot."/sound/t02.wav");	
	}
	
	$tbu=$sysroot."/sound/bases";
	$tru="t03.wav";
	playInstr($tbu, (2*$argv[1]), 5, $tru, true, 3);
	$doo3=file_exists($sysroot."/sound/t03.wav");			
	
	while($doo3==false){
	sleep(5);
	$doo3=file_exists($sysroot."/sound/t03.wav");	
	}
	








        $instrmr = scanDir("".$docr."/sound/searched");
                for($i=0;$i<count($instrmr);$i++){
                        if($instrmr[$i]=="." || $instrmr[$i]==".."){
                        }
                        else{
                        $inster[]=$instrmr[$i];
                        }

                }

                $instrmrq = scanDir("".$docr."/sound/extra");
                for($i=0;$i<count($instrmrq);$i++){
                        if($instrmrq[$i]=="." || $instrmrq[$i]==".."){
                        }
                        else{
                        @unlink("".$docr."/sound/extra/".$instrmrq[$i]);
                        }

                }
        $d0=false;
        $convert="";
        if(count($inster)>0){
                        for($n=0;$n<count($inster);$n++){
                        $nfile = "soundSample.".rand(10000,90000).".mp3";
                                $convert= $ffmpegbin."  -i ".$docr."/sound/searched/".$inster[$n]." ".$docr."/sound/extra/".$nfile;
                                exec($convert);
                                chmod("".$docr."/sound/extra/".$nfile, 0777);
                }







        $tbu1=$sysroot."/sound/extra";
        $tru1="t06.wav";
        playInstr($tbu1, (1*$argv[1]), 4, $tru1, true, 4);
        $doo31=file_exists($sysroot."/sound/t06.wav");

        while($doo31==false){
        sleep(5);
        $doo31=file_exists($sysroot."/sound/t06.wav");
        }









	$dirf = scandir("".$docr."/sound/searched");
	$convert="";
	for($j=0;$j<count($dirf);$j++){
		if($dirf[$j]=="." || $dirf[$j]==".."){

		}
		else{
			$fll=$dirf[$j];
			$convert.= " ".$ffmpegbin."  -i ".$docr."/sound/searched/".$fll." ".$docr."/sound/extra/extra".$j.".wav";
		}

	}
	@exec($convert);
}	




	
	$tbd=$sysroot."/sound/samples";
	$trd="t04.wav";
		
	playInstr($tbd, $argv[1], 7, $trd, true, 4);
	$doo4=file_exists($sysroot."/sound/t04.wav");			
	while($doo4==false){
	sleep(5);
	$doo4=file_exists($sysroot."/sound/t04.wav");	
	}

	$inster = array();
	$instrmr = scanDir("".$docr."/sound/searched");
		for($i=0;$i<count($instrmr);$i++){
			if($instrmr[$i]=="." || $instrmr[$i]==".."){
			}
			else{
			$inster[]=$instrmr[$i];
			}
			
		}
	
		$instrmrq = scanDir("".$docr."/sound/extra");
		for($i=0;$i<count($instrmrq);$i++){
			if($instrmrq[$i]=="." || $instrmrq[$i]==".."){
			}
			else{
			@unlink("".$docr."/sound/extra/".$instrmrq[$i]);
			}
			
		}
	$d0=false;
	$convert="";
	if(count($inster)>0){
			for($n=0;$n<count($inster);$n++){	
			$nfile = "soundSample.".rand(10000,90000).".mp3";
				$convert= $ffmpegbin."  -i ".$docr."/sound/searched/".$inster[$n]." ".$docr."/sound/extra/".$nfile;
				exec($convert);
				chmod("".$docr."/sound/extra/".$nfile, 0777);
		}
		

	
		$doo5=file_exists($sysroot."/sound/extra/".$nfile);			
		while($doo5==false){
		sleep(1);
		$doo5=file_exists($sysroot."/sound/extra/".$nfile);	
		}
		sleep(8);
	
	
		
		$tbeq=$sysroot."/sound/extra";
		$treq="t05.wav";
			
		playInstr($tbeq, $argv[1], 4, $treq, true, 6);
		$door=file_exists($sysroot."/sound/t05.wav");			
		while($door==false){
		sleep(6);
		$door=file_exists($sysroot."/sound/t05.wav");	
		}
		
		if(!file_exists($sysroot."/sound/t05.wav")){
		@copy($sysroot."/sound/t04.wav", "".$sysroot."/sound/t05.wav");
		}	
		$d0 = true;	
	}
	



	$d0= true;
	
	if($d0==false){
	$drr = $ffmpegbin." -t ".$argv[1]." -i ".$docr."/sound/t00.wav -i ".$docr."/sound/t01.wav  -i ".$docr."/sound/t02.wav   -i ".$docr."/sound/t03.wav  -i ".$docr."/sound/t04.wav  -filter_complex amerge=inputs=5   ".$docr."/images/frames/myClip_.mp3 ";
	}
	else{
	$drr = $ffmpegbin." -t ".$argv[1]." -i ".$docr."/sound/t00.wav -i ".$docr."/sound/t01.wav -i ".$docr."/sound/t02.wav  -i ".$docr."/sound/t03.wav  -i ".$docr."/sound/t04.wav      -i ".$docr."/sound/t06.wav -filter_complex amerge=inputs=6     ".$docr."/images/frames/myClip_.mp3";
	}
	

exec($drr);

	

	sleep(4);

	copy( "".$docr."/images/frames/myClip_.mp3" ,  "".$docr."/images/frames/myClip.mp3" );

	


	$fwi  =fopen($sysroot."/images/frames/strec_", "w");
	fwrite($fwi, "2");
	fclose($fwi);
	
        $fwi  =fopen($sysroot."/images/frames/strec", "w");
        fwrite($fwi, "2");
        fclose($fwi);


?>
