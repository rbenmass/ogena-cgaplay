<?php

if(file_exists($_SERVER['DOCUMENT_ROOT']."/".$_GET['file']) ){

//exec("echo  ".$_GET['value']." > ".$_GET['output']);
echo  "2";

}
?>
