<?php

	if(file_exists("/var") ){

		$file = $_GET['request'];
		
		@copy($file, $_SERVER['DOCUMENT_ROOT']."/images/frames/myClip.mp3");
		$opy = "chmod 777 ".$_SERVER['DOCUMENT_ROOT']."/images/frames/myClip.mp3 \nffmpeg -i ".$_SERVER['DOCUMENT_ROOT']."/images/frames/myClip.mp3 2>&1 | grep Duration | cut -d ' ' -f 4 | sed s/,// > ".$_SERVER['DOCUMENT_ROOT']."/images/frames/_rawDuration \nchmod 777 ".$_SERVER['DOCUMENT_ROOT']."/images/frames/_rawDuration \necho 2 > ".$_SERVER['DOCUMENT_ROOT']."/images/frames/strec \nchmod 777 ".$_SERVER['DOCUMENT_ROOT']."/images/frames/strec \nrm ".$_SERVER['DOCUMENT_ROOT']."/images/frames/cp.sh";
		@exec($opy);
		$tot =0;
		$data= file_get_contents("http://".getenv("HTTP_HOST")."/images/frames/_rawDuration");
		$fi=explode(":", $data);
		$hr= intval($fi[0])*60*60;
		$mi= intval($fi[1])*60;
		$se = intval($fi[2]);
		$tot=$hr+$mi+$se;
		echo $tot;
	}
	else
	{
		$tot =0;
		set_time_limit(60);
		$file = $_GET['request'];
		@copy($file,   "c:/program files/apache software foundation/apache2.2/htdocs/images/frames/myClip.mp3" );
		
		exec("ffmpeg -i \"c:/program files/apache software foundation/apache2.2/htdocs/images/frames/myClip.mp3\"  2>&1   | find \"Duration\"  > \"c:/program files/apache software foundation/apache2.2/htdocs/images/_rawDuration\" \necho 2 > \"c:/program files/apache software foundation/apache2.2/htdocs/images/frames/strec\"");
		$data= @file_get_contents("http://".getenv("HTTP_HOST")."/images/_rawDuration");
		$first = @explode(",", $data);
		$fir = $first[0];
	
		$fi=@explode(":", $fir);
		$hr= @intval($fi[1])*60*60;
		$mi= @intval($fi[2])*60;
		$se = @intval($fi[3]);
		$tot=$hr+$mi+$se;
		echo $tot;
	}
	
	$fa = fopen("".$_SERVER['DOCUMENT_ROOT']."/images/time", "w");
	@fwrite($fa, $tot);
	@fclose($fa);
	
	$file  = @fopen($_SERVER['DOCUMENT_ROOT']."/images/frames/strec", "w");
	@fwrite($file, "2");
	@fclose($file);
?>
