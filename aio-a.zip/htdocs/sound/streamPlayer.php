

<div id=myDiv></div>

<div id="player">
   <object type="application/x-vlc-plugin" 
       id="vlcplayer" 
       width="1"
       height="2" 
       classid="clsid:9BE31822-FDAD-461B-AD51-BE1D1C159921">    
       <param name="MRL" value="<?php echo $_GET['stream']; ?>" />
       <param name="volume" value="100" />
       <param name="autoplay" value="true" />
       <param name="loop" value="false" />
       <param name="fullscreen" value="false" />
   </object>
</div>

<embed type="application/x-vlc-plugin" name="VLC" autoplay="yes"
loop="no" volume="100" width="1" height="2" target="<?php echo $_GET['stream']; ?>">
