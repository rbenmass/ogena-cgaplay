<div id='audrad'></div>

<script type='text/javascript'>

var scanStream=true; 

var xmlhttpvol = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
var xmlhttpat = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");

function triggerStream() {


try{
	if ((xmlhttpvol.readyState == 4) && (xmlhttpvol.status == 200)) {	
		dosou = document.getElementById('music');
		dot=xmlhttpvol.responseText;
		if(dot.length>5){
		scanStream = false;
		//alert("Ok");

aa=document.getElementById('audrad');
aa.innerHTML="<audio id='music' width='0' height='0' autoplay style='visibility:hidden' ><source src=\"<?php $stat= @file_get_contents('http://'.getenv('HTTP_HOST').'/scripts/sync/station.txt');

echo $stat;

 ?>\"   type=\"audio/mpeg\">This player do not work on this browser</audio>";

		
		var audio = document.getElementById('music');
if(audio.src!=''){
audio.play();

// Sometime Later
audio.src = "<?php $stat= @file_get_contents('http://'.getenv('HTTP_HOST').'/scripts/sync/station.txt'); 
echo $stat;

?>";
audio.play();


		}
		
	}
		
	}
}
catch(err){

}
}

function getStreamer() {

	if(scanStream==true){

	try {
		xmlhttpvol = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
		} catch (e) {

	}
	xmlhttpvol.onreadystatechange=triggerStream;
	xmlhttpvol.open("GET", "http://<?php echo getenv("HTTP_HOST"); ?>/scripts/sync/station.txt?p="+Math.random());
	xmlhttpvol.send(null);
setTimeout("getStreamer()", 6000);
	}
	else{
		
	}

}
getStreamer();




function triggerSub() {
	if ((xmlhttpat.readyState == 4) && (xmlhttpat.status == 200)) {
	
		newpneww=xmlhttpat.responseText;
		
		ttu=newpneww.split(" - ");
		if(Math.random()>=.5){
		newpnew=ttu[0];
		}
		else{
		newpnew=ttu[1];
		}
		
		
		
		document.title=""+newpnew;
	}
}	




function getTitleArtist(){

	try {
		xmlhttpat = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
		} catch (e) {

	}
	xmlhttpat.onreadystatechange=triggerSub;
	xmlhttpat.open("GET", "/scripts/sync/titler.txt?p="+Math.random());
	xmlhttpat.send(null);

	setTimeout("getTitleArtist()", 6000);
	
}
getTitleArtist();



</script>

