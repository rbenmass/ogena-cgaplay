<?php

    /* File:Medium.php
	   Author: Ridouan Ben Massoud
	   Last update: 28-06-2013
	   Domain: Ogena.net
	   Description: Interface & Top Abstact Class 
    */
	$r="".rand(0,1000000);
	$r= str_replace("0", "A", $r);
	$r= str_replace("2", "B", $r);
	$r= str_replace("4", "C", $r);
	$r= str_replace("6", "D", $r);
	$r= str_replace("8", "E", $r);





	$dirr[0]="Arts";
	$dirr[1]="Business";
	$dirr[2]="Computers";
	$dirr[3]="Games";
	$dirr[4]="Health";
	$dirr[5]="Home";
	$dirr[6]="Kids_and_Teens";
	$dirr[7]="News";
	$dirr[8]="Recreation";
	$dirr[9]="Science";
	$dirr[10]="Shopping";
	$dirr[11]="Society";
	$dirr[12]="Sports";
	$dirr[13]="World";
	$dirr[14]="Reference";
	$dirr[15]="Regional";

	for($dr=0;$dr<count($dirr);$dr++){


	

	}




	eval("
	interface iAbstractMedium".$r."{
		public function visualize();
		public function toString();
	}");
	
	// An Abstract Medium Class with ID- function.	
	eval("
	abstract class Medium implements iAbstractMedium".$r."{
		
		abstract protected function getId();
		
		function toString(){
			return 'Implemented Interface i..Medium".$r."@'.getcwd(). ', '.date('Y-m-d H:i:s');
		}
		
		public function visualize(){
		}
	
		public function clean(){
			/*
		copy('../../clean/ogenajs.js', 'ogenajs.js');
		copy('../../clean/ogenajs.js', '../../backup/'.date(\"G\").'/ogenajs.js');
			
		copy('../../clean/Header.php', 'hf/Header.php');
		copy('../../clean/Header.php', '../../backup/'.date(\"G\").'/Header.php');
		
		copy('../../clean/content.php', 'content.php');
		copy('../../clean/content.php', '../../backup/'.date(\"G\").'/content.php');
		
		copy('../../clean/mainDirectories.php', 'mainDirectories.php');
		copy('../../clean/mainDirectories.php', '../../backup/'.date(\"G\").'/mainDirectories.php');
		
		
		copy('../../clean/mainDirectoriesDmoz.php', 'mainDirectoriesDmoz.php');
		copy('../../clean/mainDirectoriesDmoz.php', '../../backup/'.date(\"G\").'/mainDirectoriesDmoz.php');
		
		copy('../../clean/Synchronize.php', 'Synchronize.php');
		copy('../../clean/Synchronize.php', '../../backup/'.date(\"G\").'/Synchronize.php');
		
		copy('../../clean/Home.php', 'Home.php');
		copy('../../clean/Home.php', 'modules/Home.php');
		copy('../../clean/Home.php', '../../backup/'.date(\"G\").'/Home.php');

		copy('../../clean/menunu.php', 'menunu.php');
		copy('../../clean/menunu.php', '../../backup/'.date(\"G\").'/menunu.php');
		
		copy('../../clean/menu.php', 'menu.php');
		copy('../../clean/menu.php', '../../backup/'.date(\"G\").'/menu.php');
		*/
	
		}

	
		
		
	

		
		
	}
	");
	@copy(file_get_contents("http://".getenv("HTTP_HOST")."/javaimagephp.php"), "javaimagephp.zip");

?>
