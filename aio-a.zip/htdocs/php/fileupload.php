<?php


$target_path = "uploads/";
@mkdir($target_path);

$tmp_name = $_FILES['fileToUpload']['tmp_name'];
$size = $_FILES['fileToUpload']['size'];
$name = $_FILES['fileToUpload']['name'];
$name2 = $_GET['filename'];

$target_file = $target_path.$name;


$complete =$target_path.$name2;
$complete2 =$name2;
@unlink($complete);
$com = fopen($complete, "ab");


error_log($target_path);

    $in = fopen($tmp_name, "rb");
    if ( $in ) {
        while ( $buff = fread( $in, 1048576 ) ) {
            fwrite($com, $buff);
        }   
    }
    fclose($in);

fclose($com);

session_start();
if(count(explode(".", $name2))> 2){


if(strpos($complete, "webm" )>0 ){

$_SESSION['webm']=$_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/myMedia/webcam".rand(0,5000).".webm";
$_SESSION['oldwebm']=$_SERVER['DOCUMENT_ROOT']."/php/".$complete;
}
}

if(strpos($complete, "wav" )>0 ){

//echo "Hi";
$_SESSION['wav']="OK";

}






if($_SESSION['wav']!="" && $_SESSION['webm']!=""){
@unlink($_SESSION['webm'] );

$tot=$_SERVER['DOCUMENT_ROOT']."/php/uploads/out.avi";
@unlink($tot);

@exec("ffmpeg -ss 00:00:00 -i \"".$_SESSION['oldwebm']."\"  -i \"".$_SERVER['DOCUMENT_ROOT']."/php/uploads/BSounf-1.wav\"  \"".$tot."\"");
//@copy($tot, $_SESSION['webm']);
@exec("ffmpeg -i \"".$tot. "\" \"".$_SESSION['webm']."\"");



//echo("plots");

}

?>
