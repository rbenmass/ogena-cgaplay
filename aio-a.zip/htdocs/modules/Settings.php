<!--
	Title: Web Based Video Maker / Editor 
	Description: General Purpose Graphics / Animation & Movie Editing
	Author:Lofti & Ridouan Ben Massoud
	Domain: soccer-kids.nl, ogena.net & e-rogen.eu
	Date: 20-01-2015
	File: /modules/Text.php (Text Tab)
-->
<?php
if($_GET['videoQuality']!=""){

	@mkdir($_SERVER['DOCUMENT_ROOT']."/settings[".$_SERVER['REMOTE_ADDR']."]");
	$f=@fopen($_SERVER['DOCUMENT_ROOT']."/settings[".$_SERVER['REMOTE_ADDR']."]/videoQuality.html", "w");
	@fwrite($f, $_GET['videoQuality']);
	@fclose($f);

	$f=@fopen($_SERVER['DOCUMENT_ROOT']."/settings[".$_SERVER['REMOTE_ADDR']."]/widthDownload.html", "w");
	@fwrite($f, $_GET['widthDownload']);
	@fclose($f);
	
	$f=@fopen($_SERVER['DOCUMENT_ROOT']."/settings[".$_SERVER['REMOTE_ADDR']."]/heightDownload.html", "w");
	@fwrite($f, $_GET['heightDownload']);
	@fclose($f);
	
	
	
        @mkdir($_SERVER['DOCUMENT_ROOT']."/settings[".$_SERVER['REMOTE_ADDR']."]");
        $f=@fopen($_SERVER['DOCUMENT_ROOT']."/settings[".$_SERVER['REMOTE_ADDR']."]/videoQualityYou.html", "w");
        @fwrite($f, $_GET['videoQualityYou']);
        @fclose($f);

	
	$f=@fopen($_SERVER['DOCUMENT_ROOT']."/settings[".$_SERVER['REMOTE_ADDR']."]/screenCaptureMS.html", "w");
	@fwrite($f, $_GET['screenCaptureMS']);
	@fclose($f);
	
}
?>
</form>



<form action='https://www.paypal.com/cgi-bin/webscr' method='post' target='_blank' id='formPaypal'>
<input type='hidden' name='cmd' value='_s-xclick'>
<input type='hidden' name='hosted_button_id' value='CW6LXKEPSE2X8'>
<input type='hidden' name='on0' value='Multi-Media server/client Studio'>
<input type='hidden' name='os0' id='os0' value='<?php echo $_SERVER['SERVER_NAME']; ?>'  > 






<script type='text/javascript'>
function getKeys(){
d=document.geElemenById('formPaypal');
d.submit();
return true;
}

function onChangeServerName(){
c.document.getElementById('serverName');
cc=c.value;
d=document.getElementById('os0');
d.value=cc;
}

</script>
<input type='hidden' name='p' value='Settings'>
<table width='100%'>
<tr>
<td colspan=2><H1>settings[<?php echo $_SERVER['REMOTE_ADDR']; ?>]</h1></td>
</tr>

<tr>
<?php  if(file_exists("cgi.future") ){
echo "<td colspan=2><span style='color:green'>Application Registered &amp; Genuine";
}
else{
	$stats= 0+str_replace("\n", "", file_get_contents("http://".getenv("HTTP_HOST")."/scripts/sync/tff.txt"));
	if($stats<5){
		echo "<td><span style='color:red'>Unregistered, past Trial Period></td><td><input type='text' style='width:77px' id='Host-Name' value='".$_SERVER['SERVER_NAME']."'   onchange='onChangeServerName()'   readonly=readonly  ><button onclick='getKeys()'>Register met Paypal</button>";
	}
	else{
		echo "<td><span style='color: orange'>Unregistered, In 5 Day Trial Period></td><td><input type='text' style='width:77px;background:#A0A0ff;color:white' id='Host-Name' readonly=readonly onchange='onChangeServerName()'  value='".$_SERVER['SERVER_NAME']."'><button onclick='getKeys()'>Register met Paypal</button>";
	}


}


 ?></span></td>
</tr>
</form>
<form action='/index.php' method='GET'>
<input type='hidden' name='p' value="Settings" >
<tr>
<td>Full Name</td><td><input type='text' id='fullName' name='fullName' style='width:200px' 
value="<?php $d=@file_get_contents("http://".getenv( 'HTTP_HOST')."/settings[".$_SERVER['REMOTE_ADDR']."]/fullName.html"); echo $d; ?>"></td>
</tr>
<tr><td colspan=2>&nbsp;</td></tr>




<tr>
<td>Directory Image Array</td><td><input type='text' id='directoryImageArray' name='directoryImageArray' style='width:145px' 
value="<?php $d=@file_get_contents("http://".getenv( 'HTTP_HOST')."/settings[".$_SERVER['REMOTE_ADDR']."]/directoryImageArray.html"); echo $d; ?>">
FPS<input type='text' id='directoryImageArrayFps' name='directoryImageArrayFps' style='width:20px' 
value="<?php $d=@file_get_contents("http://".getenv( 'HTTP_HOST')."/settings[".$_SERVER['REMOTE_ADDR']."]/directoryImageArrayFps.html"); echo $d; ?>">

</td>
</tr>
<tr><td colspan=2>&nbsp;</td></tr>

<tr>
<td>Youtube Username</td><td><input  name='youtubeUserName' id='youtubeUserName' type='text' style='width:200px' 
value="<?php $d=@file_get_contents("http://".getenv( 'HTTP_HOST')."/settings[".$_SERVER['REMOTE_ADDR']."]/youtubeUserName.html"); echo $d; ?>"></td>
</tr>

<tr><td colspan=2>&nbsp;</td></tr>

<tr>
<td>Youtube Password</td><td><input  name='youtubePassword' id='youtubePassword' type='password' style='width:200px' 
value="<?php $d=@file_get_contents("http://".getenv( 'HTTP_HOST')."/settings[".$_SERVER['REMOTE_ADDR']."]/youtubePassword.html"); echo $d; ?>"></td>
</tr>





<tr>
<td>Video Quality</td><td>
Scale 0: Best, 31 Worst Quality
<br>
<input type='text' id='videoQuality' name='videoQuality' style='width:200px' 
value="<?php $d=@file_get_contents("http://".getenv( 'HTTP_HOST')."/settings[".$_SERVER['REMOTE_ADDR']."]/videoQuality.html"); if($d=="") {  
echo "5"; } else {  echo $d; } ?>"></td>
</tr>
<tr><td colspan=2>&nbsp;</td></tr>


<tr>
<td>Video Quality (Youtube)</td><td>
Scale 0: Best, 31 Worst Quality
<br>
<input type='text' id='videoQuality' name='videoQualityYou' style='width:200px'
value="<?php $d=@file_get_contents("http://".getenv( 'HTTP_HOST')."/settings[".$_SERVER['REMOTE_ADDR']."]/videoQualityYou.html"); if($d=="") {
echo "5"; } else {  echo $d; } ?>"></td>
</tr>
<tr><td colspan=2>&nbsp;</td></tr>


<tr>
<td>Video Dimensions</td><td align=left>

<br>Width: 
<input type='text' id='widthDownload' name='widthDownload' style='width:50px'
value="<?php $d=@file_get_contents("http://".getenv( 'HTTP_HOST')."/settings[".$_SERVER['REMOTE_ADDR']."]/widthDownload.html"); if($d=="") {
echo "800"; } else {  echo $d; } ?>">
 Height:
<input type='text' id='heightDownload' name='heightDownload' style='width:50px'
value="<?php $d=@file_get_contents("http://".getenv( 'HTTP_HOST')."/settings[".$_SERVER['REMOTE_ADDR']."]/heightDownload.html"); if($d=="") {
echo "600"; } else {  echo $d; } ?>">


</td>
</tr>
<tr><td colspan=2>&nbsp;</td></tr>




<tr>
<td>Screencapture: length in millimesconds</td><td>

<br>
<input type='text' id='screenCaptureMS' name='screenCaptureMS' style='width:200px' 
value="<?php $d=@file_get_contents("http://".getenv( 'HTTP_HOST')."/settings[".$_SERVER['REMOTE_ADDR']."]/screenCaptureMS.html"); if($d=="") {  echo "10000"; } else {  echo $d; } ?>"></td>
</tr>
<tr><td colspan=2>&nbsp;</td></tr>


<tr><td colspan=2>&nbsp;</td></tr>



<tr>
<td></td><td><input type='submit' value= 'Save' ></td>
</tr>

</table>
</form>
