<script type='text/javascript'>
var _width=800;
var _height=600;

</script>
<!--
	Title: Web Based Video Maker / Editor 
	Description: General Purpose Graphics / Animation & Movie Editing
	Author:Lofti & Ridouan Ben Massoud
	Domain: soccer-kids.nl, ogena.net & e-rogen.eu
	Date: 20-01-2015
	File: /modules/Text.php (Text Tab)
-->
<table width='90%'><tr><td>
<?php

$dataDir = "text/data[".$_SERVER['REMOTE_ADDR']."]";  
@mkdir($_SERVER['DOCUMENT_ROOT']."/".$dataDir );
@mkdir($_SERVER['DOCUMENT_ROOT']."/".$dataDir."/temp" );

@chmod("../text/data[".$_SERVER['REMOTE_ADDR']."]/output.png" , 0777);
@chmod("../text/data[".$_SERVER['REMOTE_ADDR']."]/preview.jpg", 0777);
@chmod("../text/data[".$_SERVER['REMOTE_ADDR']."]/data.html", 0777);


@unlink($_SERVER['DOCUMENT_ROOT']."/text/data[".$_SERVER['REMOTE_ADDR']."]/output.png");
@unlink($_SERVER['DOCUMENT_ROOT']."/text/data[".$_SERVER['REMOTE_ADDR']."]/preview.jpg");
@unlink($_SERVER['DOCUMENT_ROOT']."/text/data[".$_SERVER['REMOTE_ADDR']."]/data.html");

$dirfr = scandir($_SERVER['DOCUMENT_ROOT']."/text/data[".$_SERVER['REMOTE_ADDR']."]/temp" );
for($i=0;$i<count($dirfr);$i++){
	if($dirfr[$i]=="." || $dirfr[$i]==".."){
	}
	else{
		@unlink($_SERVER['DOCUMENT_ROOT']."/text/data[".$_SERVER['REMOTE_ADDR']."]/temp/".$dirfr[$i] );
	}


}



$files = scanDir($dataDir);
$html="<h4>Select Text To Preview or Render</h4><center><select id=selectedText>";
$ii=0;
for($i=0;$i<count($files);$i++){

if($files[$i]=="." || $files[$i]==".." ){
}
else{

		
		
		$ext = explode('.', $files[i]);

		//if(count($ext)>2){
		
		if(strpos($files[$i], ".src")>0 ){
			$html.="<option value='".$dataDir."/".$files[$i]."'>".$files[$i]. "</option>";
			}

		//}
		}
		
}
$html.="</select> &nbsp;<button onclick='editText()'>Edit </button>  <button onclick='previewText()'>Preview</button> &nbsp; <button onclick='renderText()'>Render</button><br><span id=renprev><span></center>";


?>
<?php
include_once($_SERVER['DOCUMENT_ROOT']."/scripts/phpstudio/workerScripts.php");
?>

<table border='0' width='100%'  >
<tr>
<td bgcolor='#fafafa'  style="width:80;border-width:1px;	   border-right-style:dotted;">
<center>
<img src='/pictures/icons/folder.gif' height='30px'><br>
<a href='#' onclick="showFiles()">My Media</a>
<br>
<br>
<center>
<img src='/pictures/icons/folder2.gif' height='30px'><br>
<a href=''>Project</a>

<br>
<br>
<center>
<img src='/pictures/icons/mmedia.gif' height='30px'><br>
<a onclick="newProject();" href='#'>New / Clear</a>

</td>
<td>
<div id="right">
<table width='100%' cellspacing='4' cellpadding='4'><tr><td>
<ul>
<li><a href='#' onclick="text(0)">Create Default Text</a></li>
<li><a href='#' onclick="text(1)">Create Text With Background Color or Image</a></li>
<li><a href='#' onclick="text(3)">Create Scrolling Text..</a></li>

</ul>
</td><td width='10%'>

<table width='100%' >
<tr><td colspan=2>&nbsp;</td></tr>
<tr><td>  </td><td></td><td><button style='width:100px;color:white;background-color:#c11010;height:30px'  value='Search'  onclick="text(0)" >Plain</button></td>
</tr>

<tr><td colspan=2>&nbsp;</td></tr>
<tr><td>&nbsp</td><td></td><td><button style='width:100px;color:white;background-color:green;height:30px'  value='Search'  onclick="text(1)" >HTML</td>
</tr>

<tr><td colspan=2>&nbsp;</td></tr>



<tr><td width='50%'>&nbsp;  </td><td></td><td><button style='width:100px;color:white;background-color:blue;height:30px'  value='Search'  onclick="text(2)" >Scroll</td>
</tr>


</table>
</td>
</tr>
</table>

<div id=texto>
</div>

</div>

</td>
</tr>
</table>
</td>
</tr>
</table>
<div id=ifr style='visibility:hidden;width:1px;height:1px'>
</div>
