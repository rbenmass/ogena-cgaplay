<h1>
Future Animation Form
</h1>
<br/><br/>
<?php
@mkdir($_SERVER['DOCUMENT_ROOT']."/images/Preview");

@exec("killall java");
@exec("taskkill /f /im java.exe");
@exec("killall java");
@exec("taskkill /f /im java.exe");

?>
<script type='text/javascript'>



	var effectNames = new Array();
	var sFile= "";
	var nFile= "";
	var imtel=-1;
	var imte=0;
	var indexIm = new Array();
	var indexEff = new Array();
	var imprevStore="";
	var effectNames = new Array();
	var previews= false;
	var insc=0;
	var imprev=false;
	var telp=0;
	var animStartss = false;

		
	<?php
	
	$dirim =scanDir("images/Preview");
for($ii=0;$ii<count($dirim);$ii++)
{
	if($dirim[$ii]=="." || $dirim[$ii]=="."){
	}
	else{
		@unlink("images/Preview/".$dirim[$ii]);
	}
}
	
	//exec("java Signature 1800 1600 50 javaimagephp.jpg ".rand(220,250)." ".rand(220,250)." ".rand(220,250));
			$fc="";
			$handle = fopen($_SERVER['DOCUMENT_ROOT']."/scripts/php/jip-scripts.php", "r");
			if ($handle) {
				while (($line = fgets($handle)) !== false) {
					$fc.=$line;
				}
			} else {
		
			} 
			$dfg = explode("tr ==", $fc);
			for($i=1;$i<count($dfg);$i++){
				$next = $dfg[$i];
				$dosc=true;
				$tl=0;
				while($dosc==true){
				$ch=$next[$tl];
				
				if($ch==')'){
				$dosc=false;
				}
				$tl++;
				
				}
				$stt = strpos($next, "scripts/");
				
				$stte = strpos($next, "?");
				$eff=substr($next, ($stt+8), ($stte-$stt-12));
				
				if(strlen($eff)<25){
				
				echo "effectNames[".str_replace(" ", "",substr($next, 1, ($tl-2)))."]='".$eff."'; \n";
				}
			}
			
			
			
			
			fclose($handle);
?>
	
	
	function updateEffect(src){
	effe=document.getElementById('tr').value;
	//alert(src+effe);
        getdatass("/scripts/image-io/upImage.php?src="+src+"&effe="+effe+"&pp="+Math.random());
        syncImg();
        telp=0;




	}


	
	function recordi(){
		anim = document.getElementById('animName');
		widthh = document.getElementById('width');
		heightt = document.getElementById('height');
		frr = document.getElementById('fr');
		soundd = document.getElementById('sound');
	 	drumss = document.getElementById('drums');

		soundfxx = document.getElementById('soundfx');
		checkZoom=document.getElementById("zoom").checked;
		

		
		if(checkZoom){
		zoom="&zoom=no";
		}
		
		
		musicc="";
		sou="";
		if(soundd.value!=""){
		musicc="&sound="+soundd.value;
		}
		sou="";
		if(soundfxx.value!=""){
		musicc="&lang=en&music=yes";
		
		sou="soundfx="+soundfxx.value+"&drums="+drumss.value;
		}
		

melodiy = document.getElementById('melody').value;		
timee = document.getElementById('time');

		window.location.href='http://<?php echo getenv("HTTP_HOST"); ?>/watch.php?p=Preview&asname='+anim.value+'&width='+widthh.value+"&height="+heightt.value+'&time='+timee.value+'&melody='+melodiy+musicc+'&'+sou;
		
		

		return false;

		}




		
		function removeIndex(index){
		alert("Id"+inedx+ " to delete from list");
		}

	var lst = new Array();		


	function triggereds() {

		if ((xmlhttps.readyState == 4) && (xmlhttps.status == 200)) {	
		
			imgsss =xmlhttps.responseText;
			
			lst = imgsss.split("#");


			//if(lsts.length>3){
			for(i=0;i<(lst.length-1);i++){
			
				//if(document.getElementById('imgs'+(i+1))){
				dd=document.getElementById('imgs'+(i+1));
				//dd.src=lsts[i];
				

				ls = lst[i];
				fs=ls.split("_");
				
				ffe="Random";
				reds=fs[(fs.length-1)];
				rf=reds.indexOf(".jpg");
				trf=reds.substring(0, rf);
				//alert(trf);
				
				if(trf>-1){
				ffe=	effectNames[trf];	
				}
				dd.innerHTML="<a href='#' onclick=updateEffect('"+lst[i]+"')>Update "+ffe+"</a><br><img width=100 src='"+lst[i]+"'>";
				//}
				
			}
			
			
	}	
		}		
	
	
	function getdatas(dest, ob) {
		try {
			xmlhttps = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
			} catch (e) {

		}
		xmlhttps.onreadystatechange = triggereds;
		xmlhttps.open("GET", dest);
		xmlhttps.send(null);
	
	}
	

        function getdatass(dest, ob) {
                try {
                        xmlhttpss = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
                        } catch (e) {

                }
                xmlhttpss.onreadystatechange = triggereds;
                xmlhttpss.open("GET", dest);
                xmlhttpss.send(null);

        }


	

	function syncImg(){
	
		 indexIm = new Array();
	 indexEff = new Array();
	 //imprevStore="";
	 lst = new Array();
	 
	 
	 			for(i=0;i<(120);i++){
			
				//if(document.getElementById('imgs'+(i+1))){
				if(document.getElementById('imgs'+i)){
				//dd.src=lsts[i];
				document.getElementById('imgs'+i).innerHTML="";
				}
				//}
				
			}
			
			
			
	 
	 
	
		getdatas("/scripts/image-io/listImage.php?l="+Math.random(), "");
		
		
		

		

		
		
		if(telp>1){
		}
		else{
		telp++;
		setTimeout("syncImg()", 5000);
		}
		
		
	
	}
	
	

	

	
	function triggered() {
	if ((xmlhttp.readyState == 4) && (xmlhttp.status == 200)) {	
	
		nFile =xmlhttp.responseText;
		
		doc = document.getElementById('imurl');
	dsrc=doc.value;
	docef = document.getElementById('tr');
	dsrcef=docef.value;
	


	if(nFile!=""){
	
	fls = nFile.split("*#*")
	for(n=0;n<(fls.length-1);n++){
	
	nnFile = fls[n];
	
	

	if(insc>0){

	insc=0;
	}
	else{
	imtel = imte;	
	imtel=imtel+1;
	imte = imtel;
	
	}
	if(document.getElementById('imgs'+imtel)){
		dd=document.getElementById('imgs'+imtel);
	//}
	//else{
	dd.innerHTML="<img width=100 src='"+nnFile+"'><br> "+effectNames[dsrcef]+"<br>";
	indexIm[imtel]=nnFile;
	indexEff[imtel]=dsrcef;
	}
	
	
	}
	doc.value="";
	
	//	getdataip("/scripts/php/syncPreview.php?reset=reset", null);
	
	for(h=1;h<=imtel;h++){
	//h=imtel;

		getdataip("/scripts/php/syncPreview.php?imurl="+indexIm[h]+"&tr="+indexEff[h]+"&imageIndex="+h, null);
		
		if(previews==false && h>3){
		previews = true;
		dpr = document.getElementById('preview');
		wwa=document.getElementById('width');
		hha=document.getElementById('height');

var x = document.getElementById("PrevCheck").checked;
if(x==true){

		dpr.innerHTML="<iframe src='http://<?php echo getenv("HTTP_HOST"); ?>/watch.php?width="+wwa.value+"&height="+hha.value+"&p=Preview' width='140' height='100'  style='overflow:hidden' scrolling=no frameborder='0'></iframe>";
	
}

	}
	
	}

	//}
}

}

}

	function triggeredi() {
	if ((xmlhttpi.readyState == 4) && (xmlhttpi.status == 200)) {	
	
		sFile =xmlhttpi.responseText;
		
		
			if(sFile!=""){
	ddd = document.getElementById("imprev");
	
	if(imprev==false){
	imprevStore = ddd.innerHTML;
	imprev = true;
	}
	
	eee = document.getElementById("imprev");

	img = sFile.split("*#*");
	ddd.innerHTML="";
	dtt="<table cellspacing=10 cellpadding=10 width='100%' border=0 >";
	
	for(f=0;f<img.length;f++){
		nim = img[f];
		
		if((f%5)==0){
		dtt=dtt+"</tr>";
		}
		
		wim = nim.split("@");
		tb = wim[0];
		imu = wim[1];
		
		dtt=dtt+"<td><a onclick=\"setGoogleImg('"+imu+"')\" href='#'><img width='100' src='"+tb+"'></a></td>";
		
		
		if((f%5)==4){
		dtt=dtt+"<tr>";
		}
		
	
	}
		dtt=dtt+"</table>";
		eee.innerHTML=dtt;
	
	sFile="";

	}
		


	}
}

	function triggeredip() {
	if ((xmlhttpip.readyState == 4) && (xmlhttpip.status == 200)) {	
	
		
	}
}

function editIndex(ind){
	//doc = document.getElementById('imurl');
	//getdataip("/scripts/php/syncPreview.php?reset=reset", null);
	//doc.value=indexIm[ind];
//	alert('delimage'+ind);

	getdatas("/scripts/image-io/delImage.php?index="+(ind-1), "");
	syncImg();
	telp=0;

}

function getdata(dest, ob) {



		xmlhttp = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");

	xmlhttp.onreadystatechange = triggered;
	xmlhttp.open("GET", dest);
	xmlhttp.send(null);
	return 1;



}


function getdatai(dest, ob) {
	
		xmlhttpi = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
		

	
	xmlhttpi.onreadystatechange = triggeredi;
	xmlhttpi.open("GET", dest);
	xmlhttpi.send(null);
	



}


function getdataip(dest, ob) {
	try {
		xmlhttpip = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
		} catch (e) {

	}
	xmlhttpip.onreadystatechange = triggeredip;
	xmlhttpip.open("GET", dest);
	xmlhttpip.send(null);



}


function setGoogleImg(str){
	ddd = document.getElementById("imprev");
	ddd.innerHTML=imprevStore;
	imprev = false;
	doc = document.getElementById('imurl');
	doc.value=str;

}

function searchGoogle(){

	doc = document.getElementById('imurl');

	dsrc=doc.value;
	if(dsrc==""){
	alert("Type a description first..");
	}
	else{
	
	getdatai("/scripts/image-io/getImg.php?search="+dsrc+"&page=1&t="+Math.random(), null);
//alert("/scripts/image-io/getImg.php?search="+dsrc+"&page="+document.getElementById('page').value );
	}
}

	
function setNextImage(){


	

	doc = document.getElementById('imurl');
	dsrc=doc.value;
	docef = document.getElementById('tr');
	dsrcef=docef.value;
	effe=document.getElementById('tr').value;
	getdata("/scripts/php/copyTo.php?source="+dsrc+"&page=1&tr="+effe+"&ttt="+Math.random(), null );
//alert("/scripts/php/copyTo.php?source="+dsrc+"&page="+document.getElementById('page').value+"&ttt="+Math.random() );
	//telp=0;
	syncImg();

}

</script><center>
<table style='border:0;width:95%;height:98%' background="javaimagephp.jpg_">
<tr>
<td>Name of Video Animation</td><td colspan='2'><input type='text' name='animName' id='animName' value='AnimA<?php 

$rai[0]="0";
$rai[1]="2";
$rai[2]="4";
$rai[3]="6";
$rai[4]="8";
$rai[6]="B";
$rai[7]="D";
$rai[8]="F";
$rai[9]="H";

$rnma= "";
for($j=0;$j<5;$j++){
$rnma.=$rai[rand(0, (count($rai)-1))];
}
echo "".$rnma;

?>' size='10' style='width:100%'></td>
</tr>
<tr>
<td>Resolution in Pixels</td><td>Width</td><td>Height</td>
</tr>
<tr>
<td>&nbsp;</td><td collspan='2'><input type='text' size='10' value='512' id='width' name='width' style='width:100%'></td>
<td collspan='2'><input type='text' size='10' name='height' value= '360' id= 'height' style='width:100%'></td>
</tr>
<tr>
<td>Animation Framerate/Speed</td><td colspan='2'><input type='text' value='16' id='fr' name='frameRate' size='10' style='width:100%'></td>
</tr>

<tr>
<td>Duration (time in seconds) </td><td colspan='2'><input type='text' value='180' id='time' name='time' size='10' style='width:100%'></td>
</tr>


<tr>
<tr>
<td>Mp3 Sound File, youtubeid or Youtube Search</td><td colspan='2' style='text-align:right'>Music<input type='text' id='sound' name='sound' size='10' style='width:75%'><BR>
Sounds <input type='text' id='soundfx' name='soundfx' size='10' style='width:75%'><BR>

Melody <input type='text' id='melody' name='melody' size='10' style='width:75%'><BR>

Drums <input type='text' id='drums' name='drums' size='10' style='width:75%'>


</td>
</tr>
<tr>

<tr>
<td align=right>
<table style='border:0;width:100%;height:100%'><tr><td align=center>
<input type='checkbox' id='PrevCheck' name='PrevCheck' value='true' ><b>Preview Animation</b>

<br>
<?php




?>


<span id='preview'>
</span>
</td></tr></table> 
</td>
<td><button  id='saveImageBtn'  name='saveImageBtn' onmousedown='setNextImage()' >Use and Next</button> URL / File</td><td><input type='text' id='imurl' name='imurl' size='20' style='width:70%'> Page <input type='text' style='width:10%' size=1 id=page name=page value='1'> <BR><A onclick='searchGoogle()' HREF='#'>Search Image on Google</a></td>
</tr>


<tr>
<td>Transition / Special Effect</td><td colspan='2'>
<select  id='tr' name='tr'>
<option value='-1'>Default</option>

<?php
			$fc="";
			$handle = fopen($_SERVER['DOCUMENT_ROOT']."/scripts/php/jip-scripts.php", "r");
			if ($handle) {
				while (($line = fgets($handle)) !== false) {
					$fc.=$line;
				}
			} else {
		
			} 
			$dfg = explode("tr ==", $fc);
			for($i=1;$i<count($dfg);$i++){
				$next = $dfg[$i];
				$dosc=true;
				$tl=0;
				while($dosc==true){
				$ch=$next[$tl];
				
				if($ch==')'){
				$dosc=false;
				}
				$tl++;
				
				}
				$stt = strpos($next, "scripts/");
				
				$stte = strpos($next, "?");
				$eff=substr($next, ($stt+8), ($stte-$stt-12));
				
				if(strlen($eff)<25){
				
				echo "<option value='".str_replace(" ", "",substr($next, 1, ($tl-2)))."'>".$eff."</option>";
				}
			}
			
			
			
			
			fclose($handle);
?>

</select>
</td>

</tr>

<tr>
<td colspan='3'>
<span id="imprev">
<table cellspacing=5 cellpadding=5 width='100%' border=0 >


<?php
	$it=1;

	for($t=1;$t<=10;$t++){
	
	
		echo "<tr>";

		for($i=1;$i<=5;$i++){
	

			echo "<td style='width:20%' bgcolor='#eeeeee' style='opacity:0.8;text-align:center' ><span id=imgs".$it."></span><br/><a href='#' onclick='editIndex(".$it.")'>".$it."</a></td>";
			$it++;
		}
		
		echo "</tr>";
	}
?>

</table>
</span>
</tr>


<tr>
<td colspan=3>
<input type='checkbox' value =''  id='zoom'>

<button id='refresh' onclick='syncImg()'> Refresh</button>

<button onclick='recordi()'> Record</button> 

</td>
</tr>




</table>
<script type='text/javascript'>
		function enabledisableButton(){
			but = document.getElementById('saveImageBtn');
		doc = document.getElementById('imurl');
		dv=doc.value;
		if(dv==""){
		but.disabled=true;
		}
		else{
		but.disabled=false;
		
		}
		
		setTimeout("enabledisableButton()", 1000);
	}
	enabledisableButton();






function showAnimadz(){

                      var xa = document.getElementById("PrevCheck").checked;
                        if(xa==true && animStartss==false){
                                animStartss = true;
                                dpr = document.getElementById('video');
                        dpr.innerHTML="<iframe src='http://<?php echo getenv("HTTP_HOST"); ?>/watch.php?p=Preview' width='240' height='130'>NOT Supported</iframe>";
                        }
                        setTimeout("showAnimadz()", 1000);
}
showAnimadz();
d=document.getElementById('imurl');
d.focus();
d.select();

</script>
