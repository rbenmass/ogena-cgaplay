<?php
 if($_GET['q']=="Graphics"){
 $s1="Backgrounds";
 $s2="Solids";
 }
  if($_GET['q']=="Audio"){
  $s1="Music";
 $s2="Sound Effects";
 }
  if($_GET['q']=="Text"){
  $s1="Text";
 $s2="Annotations";
 }
?>
<table border='0' width='100%'>
<tr>
<td bgcolor='#fafafa' style="border-width:1px;	   border-right-style:dotted;">
<center>
<img src='/img/folder.png' height='30px'><br>
<a href=''><?php echo $s1; ?></a>
<br>
<br>
<center>
<img src='/img/folder2.png' height='30px'><br> 
<a href=''><?php echo $s2; ?></a>
</td>
<td>
DATA
</td>
</tr>
</table>
