<table border=0 width='100%'><tr> <?php
$q=$_GET['p']." site:youtube.com ";
$url2= "http://search.yahoo.com/search?p=".urlencode($q);
$datah= file_get_contents($url2);
$rs=10;
$ff=false;
        $ex=explode("Cached", $datah);
for($i=0;$i<3;$i++){
        $e=$ex[$i];
        $start=0;
        $end=0;
        for($jj=0;$jj<(strlen($e)-6);$jj++){
                $wo=substr($e, $jj, 5);
                if($wo=="<h3 c"){

                        $start=$jj;
                }
                if($wo=="</h3>"){

                        $end=$jj+5;
                }
        }
$thetit=        str_replace(" - YouTube", "", strip_tags(substr($e, $start, ($end-$start))));

        $ef=explode("www.youtube.com/watch?v=", $e);
        $st=strpos($ef[1], "v=");
        $end=strpos($ef[1], "</span>");
        $st=  substr($ef[1], ($st+2), ($end-$st-2));
        $title2= "http://img.youtube.com/vi/".$st."/mqdefault.jpg";
        $p=$thetit;

  echo "<td align=center><font size=1> ".$p."</font><br><a title='Click for Preview' onclick=playYou('".$st."')>Play..
 </a><br><a onClick=down('".$st."') target=_blank hre='".$title2q       ."'><img title='Click to Grab & use' width=80 src='".$title2."'></a></td>";


}


?> </tr> </table>
