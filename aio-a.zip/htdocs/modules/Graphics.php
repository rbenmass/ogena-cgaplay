<div id='con'>
</div>
<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?sensor=false"></script> 
<script type="text/javascript"> 

function pic(ob, data, start, end){

d=document.getElementById(ob);
pics=data.split('<br>');
urli=start+Math.floor((end-start)*Math.random());
d.src=pics[urli];


}

var t1= new Array();

t1[0]=0;
t1[1]=0;
t1[2]=0;
t1[3]=0;
t1[4]=0;
t1[5]=0;
function rotateThumbs(intt, ob, data, start, end, to){

if((t1[intt]*1000)==to){


d=document.getElementById(ob);
pics=data.split('<br>');
urli=start+Math.floor((end-start)*Math.random());
d.src=pics[urli];

//setTimeout("rotateThumbs("+ob+","+data+","+start+","+end+","+to+")", to);
t1[intt]=0;
}
else{
t1[intt]=t1[intt]+1;
setTimeout("rotateThumbs("+intt+",'"+ob+"','"+data+"',"+start+","+end+","+to+")", 1000);
}

}





function vwv(wrd, plc){
	
	sear = document.getElementById('search');
	zoek=sear.value;
	q="";
	if(zoek!="Search"){
	q=zoek +" "+plc;
	}
	else{
	q=wrd +" "+plc;

	}
	v=document.getElementById('video');
	v.innerHTML="<iframe src='/watch.php?p="+encodeURIComponent(q)+"&sound="+encodeURIComponent(plc+" Music Band")+"&randomTrack=true' width=300 height=200 scrolling=no scrollbars=no border=0>No Iframe Support</iframe>";
	
	//alert(q);
	
}



var 	xmlhttip = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
  var geocoder;
	var plaats="";
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(successFunction, errorFunction);
} 
//Get the latitude and the longitude;
function successFunction(position) {
    var lat = position.coords.latitude;
    var lng = position.coords.longitude;
    codeLatLng(lat, lng)
}

function errorFunction(){
    alert("Geocoder failed");
}

  function initialize() {
    geocoder = new google.maps.Geocoder();



  }

  function codeLatLng(lat, lng) {

    var latlng = new google.maps.LatLng(lat, lng);
    geocoder.geocode({'latLng': latlng}, function(results, status) {
      if (status == google.maps.GeocoderStatus.OK) {
      console.log(results)
        if (results[1]) {
         //formatted address
         plaats=(results[0].address_components[2].long_name);
        //find country name
             for (var i=0; i<results[0].address_components.length; i++) {
            for (var b=0;b<results[0].address_components[i].types.length;b++) {

            //there are different types that might hold a city admin_area_lvl_1 usually does in come cases looking for sublocality type will be more appropriate
                if (results[0].address_components[i].types[b] == "administrative_area_level_1") {
                    //this is the object you are looking for
                    city= results[0].address_components[i];
                    break;
                }
            }
        }
        //city data
        //alert(city.short_name + " " + city.long_name)


        } else {
          alert("No results found");
        }
      } else {
        alert("Geocoder failed due to: " + status);
      }
    });
  }
</script> 
<script>
initialize();

 

function triggeredip() {
	if ((xmlhttip.readyState == 4) && (xmlhttip.status == 200)) {	
		dosou = document.getElementById('con');
		//alert('Ok');
		dosou.innerHTML=xmlhttip.responseText;
		


	}
}

var teller=0;


function pl(){
	if(plaats==""){

	teller++;
	
	if(teller>10){
	
	var cit = prompt("Please enter a city name", "");

if (cit != null) {
	plaats=cit;
	
	}
	else{
	plaats="Utrecht";
	}
	}
	
	setTimeout("pl()", 500);
	}
	else{
	
	
	xmlhttip = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
	
	xmlhttip.onreadystatechange = triggeredip;
	xmlhttip.open("GET", '/modules/_Graphics.php?ii='+Math.random()+'&plaats='+plaats, true);
	xmlhttip.send(null);
	
	
	
	
	
	
	}
}
pl();

</script>