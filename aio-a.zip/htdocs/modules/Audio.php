<!--
	Title: Web Based Video Maker / Editor 
	Description: General Purpose Graphics / Animation & Movie Editing
	Author:Lofti & Ridouan Ben Massoud
	Domain: soccer-kids.nl, ogena.net & e-rogen.eu
	Date: 20-01-2015
	File: /modules/Audio.php (Audio Tab)
-->
<script type='text/javascript'>
function downloadAudio(clipAudio, path_ ){

window.open('/scripts/phpstudio/saveDownloadClip.php?file='+clipAudio+'&path='+path_+'&e='+Math.random(), 'Download');
}


</script>

<table width='100%'><tr><td>
<?php

$dataDir = "data[".$_SERVER['REMOTE_ADDR']."]/myMediaAudio";  


$files = scanDir($dataDir);



$htmlaudio="<div  style='text-align:center'><h4>Click on Audio for Preview</h4>";


$ii=0;
for($i=0;$i<count($files);$i++){

if($files[$i]=="." || $files[$i]==".." ){
}
else{
		$nFil = $files[$i];
		$ii++;
		if($ii%5==1){
		$html.= "<br>";
		}
		
		
//@mkdir($dataDirt."/temp");
		
		@unlink($_SERVER['DOCUMENT_ROOT']."/".$_SERVER['REMOTE_ADDR']."/".$files[$i].".wav");	
		@exec("ffmpeg -i \"".$_SERVER['DOCUMENT_ROOT']."/".$dataDir."/".$files[$i]. "\"  \"".$_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/".$files[$i].".wav\"" );
		@unlink($_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/".$files[$i].".gif");
		exec("java -cp \"".$_SERVER['DOCUMENT_ROOT']."/scripts/java\" AudioWaveformCreator \"".$_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/".$files[$i].".wav\"  \"".$_SERVER['DOCUMENT_ROOT']."/data[".$_SERVER['REMOTE_ADDR']."]/".$files[$i].".gif\" 100 100 100");
		$htmlaudio.="<span id='divAudio".$i."'><a href='#' onclick=playItem('".$dataDir."/".$files[$i]."')><img src='/pictures/icons/audio.gif' width=25></a><a href='#' onclick=addItemA(".$i.",'".$dataDir."/".$files[$i]."')>Add</a><img src='/data[".$_SERVER['REMOTE_ADDR']."]/".$files[$i].".gif' width='230px' height='20'><button onclick=\"downloadAudio('".$files[$i]."', 'data[".$_SERVER['REMOTE_ADDR']."]/myMediaAudio');\">Download</button>,  Start at <input type='text' id='preSec' value='0' style='width:30px'> Secs. Speed:<input type='text' id='speedSound' value='100' style='width:30px'>%<br/></span>" ;
		}
		
}



?>

</div>
<?php
include_once($_SERVER['DOCUMENT_ROOT'].'/scripts/phpstudio/workerScripts.php');



?>

<table border='0' width='100%'  >
<tr>
<td bgcolor='#fafafa'  style="border-width:1px;	   border-right-style:dotted;">
<center>
<img src='/pictures/icons/folder.gif' height='30px'><br>
<a href='#' onclick="showFiles()">My Media</a>
<br>
<br>
<center>
<img src='/pictures/icons/folder2.gif' height='30px'><br>
<a href=''>Project</a>
</td>
<td>
<div id="right">
<table width='100%' ><form action="/index.php" method="POST" enctype="multipart/form-data">
<input type="hidden" name="MAX_FILE_SIZE" value="400000000" />
<input type="hidden" name="audio" value="yes" />

<tr><td>Upload </td><td><input type='file' name="userfile"/></td><td><input type='submit' value='Add'  style='width:80px'></td></tr>
</form>
<tr><td colspan=2>&nbsp;</td></tr>
<tr><td> Zoek Audio </td><td><input type='text' style='width:80%' size=12></td><td><input style='width:80px' type='submit' value='Search'></td>
</tr>
</table>
</div>

</td>
</tr>
</table>

<?php
echo $htmlaudio;
?>


</td>
</tr>
</table>
<script type='text/javascript'>
_width=800;
_height=600;
clipName="";

function refreshClipName(){}

</script>
