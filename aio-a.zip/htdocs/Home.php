<!--
	Title: Web Based Video Maker / Editor 
	Description: General Purpose Graphics / Animation & Movie Editing
	Author:Ridouan Ben Massoud
	Domain:ogena.net & e-rogen.eu
	Date: 20-01-2015
	File: Home.php (Center Page)
-->
<script type='text/javascript'>
var xmlhttd = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
var xmlhtte = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
var xmlhtit = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
var xmlhttedn = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
var syncTitle=false;
<?php

@file_get_contents("http://".getenv("HTTP_HOST")."/scripts/php/temp.php");

?>

function triggertit() {
        if ((xmlhtit.readyState == 4) && (xmlhtit.status == 200)) {
		pg= document.getElementById('totalRecorderTime');
		
		xmq=xmlhtit.responseText;
		
		
		pg.innerHTML=xmq;
		
        }
}


function getdatit(dest) {
        try {
                xmlhtit = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
                } catch (e) {
        }
        xmlhtit.onreadystatechange = triggertit;
        xmlhtit.open("GET", dest);
        xmlhtit.send(null);
}



function syncTitles(){
	if(syncTitle==true){
	er= document.getElementById('previ');
	er.innerHTML='';
	
	getdatit('/scripts/sync/mptitle?p='+Math.random());

		
	}
	
	setTimeout('syncTitles()', 5000);
	
}

function fix(ob){
	
	src = obj.src;
	obj.src=src.replace("100.jpg", '5.jpg');
	
}


function openAnimation(){
//v=document.getElementById('video');
//v.innerHTML="<iframe src='/watch.php"+document.getElementById('searchQ').value+"' style='width:300px;height:180px;border:0'></iframe>";
window.location.href='/index.php?p=form';
return true;

}


function openAnimationSmart(){


        var he= document.getElementById('help');
        he.style.display="none";


search=document.getElementById('searchQ').value;
andd=search.split(" and ");
if(andd.length>2){

	images="";
	for(i=0;i<(andd.length-1);i++){
	images=images+","+andd[i];
	}
	stripped=images.replace('pictures', '');
        strippe=stripped.replace('picture', '');
        stripp=strippe.replace('images', '')
        strip=stripp.replace('image', '');
	stri=strip.replace('of', '');
	str=stri.replace('like', '');
	st=str.replace('by', '');
	s=st.replace('photos', '');
	_s=s.replace('photo', '');


	pps=_s.split(',');

	p="";
	for(j=1;j<pps.length;j++){
		piop=pps[j];
	p=p+piop.replace(";", "")+";";
	}
sss=p.substring(0, (p.length-1));
	query="?p="+sss;	


	




	music=andd[(andd.length-1)];

	stripped=music.replace('song', '');
	strippe=stripped.replace('by', '');
	stripp=strippe.replace('music', '')
	strip=stripp.replace('sound', '');
	
	query=query+"&sound="+strip;
	//alert(query);
	quer= query.replace('?p=;  ', '?p=');
	que = quer.replace(';&sound= ', '&sound=');

	watch=que.replace('; ', ';');	
	vi = document.getElementById('video');
	thesento=watch.replace(' ', '%20');
		thesent = thesento.replace(';&', '');
	vi.innerHTML="<iframe src='http://<?php echo getenv("HTTP_HOST"); ?>/watch.php"+thesent+"&window="+Math.random()+"' width='250' height='140' style='border:0' scrolling=no scrollbars=no >IFRAMES NOT SUPPORTED</iframe>";
	syncTitle=true;
	titleAnimation();

}





}





function getdatd(dest) {
        try {
                xmlhttd = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
                } catch (e) {
        }
        xmlhttd.onreadystatechange = trigger;
        xmlhttd.open("GET", dest);
        xmlhttd.send(null);
        
	return true;
}

function trigger() {
        if ((xmlhttd.readyState == 4) && (xmlhttd.status == 200)) {
	dd=document.getElementById('vidss');
	dd.innerHTML=xmlhttd.responseText;
        }
}


function getdate(dest) {
        try {
                xmlhtte = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
                } catch (e) {
        }
        xmlhtte.onreadystatechange = triggere;
        xmlhtte.open("GET", dest);
        xmlhtte.send(null);
}

function triggere() {
        if ((xmlhtte.readyState == 4) && (xmlhtte.status == 200)) {
	window.location.href='index.php';

        }
}




function getdatedn(dest) {
        try {
                xmlhttedn = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
                } catch (e) {
        }
        xmlhttedn.onreadystatechange = triggeredn;
        xmlhttedn.open("GET", dest);
        xmlhttedn.send(null);
}

function triggeredn() {
        if ((xmlhttedn.readyState == 4) && (xmlhttedn.status == 200)) {
	//window.location.href='index.php';
	ttd=xmlhttedn.responseText;
	theD =ttd.split('[download]');
	lasty=theD[(theD.length-1)];
	fb=lasty.split('%');
	lasty0=fb[(fb.length-2)];	
	if(parseFloat(lasty0)<100){
	document.title=lasty0 + '% Downloaded' ; 
	}
else{
//document.title=lasty+' OK!!!! '+lasty0;
}






	

        }
}



function isOkYD(){
getdatedn('data[<?php echo $_SERVER['REMOTE_ADDR']; ?>]/statusdl.html');
setTimeout('isOkYD()', 3000);
}



function down(v){
getdate('scripts/phpstudio/youdown.php?save=<?php echo "data[".$_SERVER['REMOTE_ADDR']."]/myMedia/Video".rand(1000,9000).".mp4"; ?>&v='+v+'&pp='+Math.random());
rebuil =true;
document.title='Downloading...';
aantals();
status();
isOkYD();
}

function  searchYouTube(){

        var he= document.getElementById('help');
        he.style.display="none";


s=document.getElementById('searchQ').value;
getdatd('modules/SearchYouTube.php?p='+s+'&rr='+Math.random());

}
</script>

<table style="width:100%;border-spacing: 0px;"><tr><td>
<?php
$refresh=false;

@unlink("data[".$_SERVER['REMOTE_ADDR']."]/ytst.html");

@mkdir("data[".$_SERVER['REMOTE_ADDR']."]");
@mkdir("data[".$_SERVER['REMOTE_ADDR']."]/temp");
$dataDir = "data[".$_SERVER['REMOTE_ADDR']."]/myMedia";  
@mkdir($_SERVER['DOCUMENT_ROOT']."/temp");
@mkdir($_SERVER['DOCUMENT_ROOT']."/uploads");
$dataDirt = "data[".$_SERVER['REMOTE_ADDR']."]/myMediaTbn";
$dataDirta = "data[".$_SERVER['REMOTE_ADDR']."]/myMediaAudio";
exec("java -cp . Signature 1800 1400 40 images/bg.jpg ".rand(200, 253). " ".rand(200, 255)." ".rand(200, 255));

$_SESSION['webm']="";
$_SESSION['wav']="";


if($_GET['copyAnim']!=""){
	@copy($_GET['copyAnim'], $dataDir."/Animation.".rand(100000, 300000).".avi");
	
}

@mkdir($_SERVER['DOCUMENT_ROOT']."/".$dataDir );
@mkdir($_SERVER['DOCUMENT_ROOT']."/".$dataDirt );
@mkdir($_SERVER['DOCUMENT_ROOT']."/".$dataDirta );


@mkdir($_SERVER['DOCUMENT_ROOT']."/".$dataDirt."/temp" );
@mkdir($_SERVER['DOCUMENT_ROOT']."/text/".$dataDirt."/temp" );
@mkdir($_SERVER['DOCUMENT_ROOT']."/".$dataDirt."/frames" );
@mkdir($_SERVER['DOCUMENT_ROOT']."/".$dataDirt."/collect" );

@unlink("data[".$_SERVER['REMOTE_ADDR']."]/status.html");
@unlink("data[".$_SERVER['REMOTE_ADDR']."]/statusdl.html");


@exec("echo 0 > data[".$_SERVER['REMOTE_ADDR']."]/status.html");

@unlink("data[".$_SERVER['REMOTE_ADDR']."]/temp/status.html");
@exec("echo 0 > data[".$_SERVER['REMOTE_ADDR']."]/temp/status.html");


@unlink("data[".$_SERVER['REMOTE_ADDR']."]/nrOfFramesz.html");
@exec("echo 1 > data[".$_SERVER['REMOTE_ADDR']."]/nrOfFramesz.html");

exec("echo 20 > data[".$_SERVER['REMOTE_ADDR']."]/mfps.txt");
exec("echo 20 > data[".$_SERVER['REMOTE_ADDR']."]/frameCount.html");


$frameRate=21;
@copy('scripts/phpstudio/saveDownloadClip.php', 'data['.$_SERVER['REMOTE_ADDR'].']/saveDownloadClip.php');

$files = scanDir($dataDir);
$html="<h4>Click on Video for Preview</h4>";
$ii=0;
for($i=0;$i<count($files);$i++){

if($files[$i]=="." || $files[$i]==".." ){
}
else{

	@mkdir($dataDirt."/".$files[$i] );
	$nFil = $files[$i];
	$ii++;
	if($ii%5==1){
		$html.= "<br>";
	}
		
	session_name('ss');
	session_start();
	$na = $_SESSION['a'.$i];
	@mkdir($dataDirt."/temp");
	$tot=0;
	if(file_exists($dataDirt."/".$files[$i]."1.jpg")){
			$ff=scandir($dataDirt."/temp/");
			for($h=0;$h<count($ff);$h++){
				if($ff[$h]=="." || $ff[$h]==".."){
				}
				else{
				
				}
			}		
		}
		else{
$refresh=true;

		//exec("ffmpeg.exe -i  ".$dataDir."/".$files[$i]."  2>&1   | find \"tbr\"  > _rawDuration_");
//		exec("ffmpeg -i \"".$dataDir."/".$files[$i]. "\" -r 25 -preset ultrafast -vcodec copy -acodec copy \"".$dataDir."/".$files[$i]."\"" );
		//unlink($dataDir."/".$files[$i]);
		//exec("ffmpeg -i \"".$dataDir."/".$files[$i].".avi\" -preset ultrafast -acodec copy -vcodec copy -r 25 \"".$dataDir."/".$files[$i]."\"");
		unlink($dataDir."/".$files[$i].".avi");	
			$ff=scandir($dataDirt."/temp/");
			for($h=0;$h<count($ff);$h++){
				if($ff[$h]=="." || $ff[$h]==".."){
			}
			else{
			
			}
		}

		$ff=scandir($dataDirt."/temp/");
		for($h=0;$h<count($ff);$h++){
			if($ff[$h]=="." || $ff[$h]==".."){
			}
			else{
				@unlink($dataDirt."/temp/".$ff[$h]);
			}
		}
		
		
		if(file_exists("c:/windows")){
			@unlink("_rawDuration_");
			exec("ffmpeg.exe -i  ".$dataDir."/".$files[$i]."  2>&1   | find \"tbr\"  > _rawDuration_");
			$fc="";
			
			$handle = fopen("_rawDuration_", "r");
			if ($handle) {
					while (($line = fgets($handle)) !== false) {
						$fc.=$line;
					}
				} 
			else {
			
			}
			fclose($handle);
			$ff = explode(",", $fc);
			
			
	
			$fff= explode(" ", $ff[5]);
	$fffz= explode(" ", $ff[4]);
		$fpzz = (int)str_replace(" ", "", $fffz[1]);
	
			
			$fpss = (int)str_replace(" ", "", $fff[1]);
			@unlink("data[".$_SERVER['REMOTE_ADDR']."]/nrOfFramesz.html");			


			@unlink("_rawDuration");
			exec("ffmpeg.exe -i  ".$dataDir."/".$files[$i]."  2>&1   | find \"Duration\"  > _rawDuration");
			
					$fc="";
			
			$handle = fopen("_rawDuration", "r");
			if ($handle) {
					while (($line = fgets($handle)) !== false) {
						$fc.=$line;
					}
				} 
			else {
			
			}
			fclose($handle);

			$gf=explode(",", $fc);
			$fi=explode(":", $gf[0]);
			$hr= $fi[1]*60*60;
			$mi= $fi[2]*60;
			$se = $fi[3]+1;
			$tot=$hr+$mi+$se;
		@unlink("data[".$_SERVER['REMOTE_ADDR']."]/frameCount.html" );
		exec("echo ".ceil($fpzz*$tot)." > data[".$_SERVER['REMOTE_ADDR']."]/frameCount.html ");

			exec("echo ".ceil($fpzz*$tot)." > data[".$_SERVER['REMOTE_ADDR']."]/nrOfFramesz.html");
			exec("echo ".($fpss*$tot)." > data[".$_SERVER['REMOTE_ADDR']."]/lengthSeconds.txt");	
		}
		
		else{
		@unlink("_rawDuration_");

		
		exec("ffmpeg -i  ".$dataDir."/".$files[$i]."  2>&1   | grep tbr   > _rawDuration_");
		$fc="";
		
		$handle = fopen("_rawDuration_", "r");
		if ($handle) {
				while (($line = fgets($handle)) !== false) {
					$fc.=$line;
				}
			} 
		else {
		
		}
		fclose($handle);
		$ff = explode(",", $fc);
		$fff= explode(" ", $ff[5]);
		$fpss = (int)str_replace(" ", "", $fff[1]);

		$fffz= explode(" ", $ff[4]);
		$fpzz = (int)str_replace(" ", "", $fffz[1]);

		@unlink("data[".$_SERVER['REMOTE_ADDR']."]/nrOfFramesz.html");			

		@unlink("_rawDuration");
		exec("ffmpeg -i  ".$dataDir."/".$files[$i]."  2>&1   | grep Duration  > _rawDuration");
		
		$fc="";
		
		$handle = fopen("_rawDuration", "r");
		if ($handle) {
				while (($line = fgets($handle)) !== false) {
					$fc.=$line;
				}
			} 
		else {
		
		}
		fclose($handle);



		$gf=explode(",", $fc);
		$fi=explode(":", $gf[0]);
		$hr= $fi[1]*60*60;
		$mi= $fi[2]*60;
		$se = $fi[3]+1;	
		
		@unlink("data[".$_SERVER['REMOTE_ADDR']."]/nrOfFramesz.html" );
		$tot=$hr+$mi+$se;
		@unlink("data[".$_SERVER['REMOTE_ADDR']."]/frameCount.html" );
		exec("echo ".ceil($fpzz*$tot)." > data[".$_SERVER['REMOTE_ADDR']."]/frameCount.html ");
		exec("echo ".ceil($fpss*$tot)." > data[".$_SERVER['REMOTE_ADDR']."]/nrOfFramesz.html");
		exec("echo ".($fpss*$tot)." > data[".$_SERVER['REMOTE_ADDR']."]/lengthSeconds.txt");
		}
		
		$vq="";
		
$resize="";
$d=@file_get_contents("http://".getenv( 'HTTP_HOST')."/settings[".$_SERVER['REMOTE_ADDR']."]/videoQuality.html"); if($d=="") {  $qua=5; } else { $qua= $d;} 
$dh=@file_get_contents("http://".getenv( 'HTTP_HOST')."/settings[".$_SERVER['REMOTE_ADDR']."]/heightDownload.html");
$dw=@file_get_contents("http://".getenv( 'HTTP_HOST')."/settings[".$_SERVER['REMOTE_ADDR']."]/widthDownload.html"); if($dw=="") {  $resize=""; } else { $resize= " -vf scale=".$dw.":".$dh;} 

		
		exec("ffmpeg  -t 0:0:5  -i ".$dataDir."/".$files[$i] . " ".$resize." -vf fps=25   -preset ultrafast  -qscale:v ".$qua."  ".$dataDirt."/".$files[$i]."%d.jpg 2> data[".$_SERVER['REMOTE_ADDR']."]/temp/status.htmll");
		unlink($dataDirt."/".$files[$i].".avi");
		$ff=scandir($dataDirt."/temp/");
		for($h=0;$h<0/(count($ff));$h++){
			if($ff[$h]=="." || $ff[$h]==".."){
			}
			else{
				copy($dataDirt."/temp/".$ff[$h]  , $dataDirt."/".$files[$i]."/".$ff[$h]);
				if($h==10){
					 list($width, $height)=getimagesize("http://".getenv("HTTP_HOST")."/".$dataDirt."/temp/".$ff[$h]);
					@unlink($dataDirt."/width.txt" );
					$f=@fopen( $dataDirt."/width.txt", "w" );
					@fwrite($f, $width);
					@fclose($f);	
					@unlink($dataDirt."/height.txt" );
					$f=@fopen( $dataDirt."/height.txt", "w" );
					@fwrite($f, $height);
					@fclose($f);
					}
				$tot=$tot+1;
			}
		}
		$nrOfFrames= ceil($fpss*$tot);
		$width=800;
		$height=600;
		if(file_exists("c:/windows")){	
		exec("ffmpeg.exe -i  ".$dataDir."/".$files[$i]."  2>&1   | find \"Duration\"  > _rawDuration");
		$fc="";
		$handle = fopen("_rawDuration", "r");
		if ($handle) {
				while (($line = fgets($handle)) !== false) {
					$fc.=$line;
				}
			} 
		else {
		
		}
		fclose($handle);

                $gf=explode(",", $fc);
                $fi=explode(":", $gf[0]);
                $hr= $fi[1]*60*60;
                $mi= $fi[2]*60;
                $se = $fi[3]+1;
                $tot=$hr+$mi+$se;
				
				$datard= file_get_contents("http://".getenv("HTTP_HOST")."/_rawduration_");
				$nrOfFramesr = explode(",", $datard);
				$theFD = $nrOfFramesr[4];
				$the=explode("tbr",$theFD);
				$nrOfFramesd=0+str_replace(" ", "", $the[0]);
				$nrOfFrames =$nrOfFramesd*$tot;
		
				
				
				
		}
		else{
				exec("ffmpeg -i  ".$dataDir."/".$files[$i]."  2>&1   | grep Duration | cut -d ' ' -f 4 | sed s/,// > _rawDuration.txt");
				$fc=file_get_contents("http://".getenv("HTTP_HOST")."/_rawDuration.txt");
		
                $fi=explode(":", $fc);
                $hr= $fi[0]*60*60;
                $mi= $fi[1]*60;
                $se1 = explode('.',$fi[2]);
				$se=0+$se1[0];
                
				$tot=$hr+$mi+$se;
		}
				//exec("ffmpeg -i ".$dataDir."/".$files[$i]." ". $dataDirt."/".$files[$i]."1.jpg.mp3");
		@copy(  $dataDirt."/".$files[$i]."1.jpg.mp3", "data[".$_SERVER['REMOTE_ADDR']."]/myMediaAudio/".$files[$i].".mp3" );
		//exec("ffmpeg -i ".$dataDir."/".$files[$i]." ". $dataDirt."/".$files[$i]."1.jpg.mp3");
		@copy(  $dataDirt."/".$files[$i]."1.jpg.mp3", "data[".$_SERVER['REMOTE_ADDR']."]/myMediaAudio/".$files[$i].".mp3" );
		exec("echo ".round($nrOfFrames/$tot)." > ".$dataDirt."/".$files[$i]."1.jpg.txt");
		exec("echo ".round($tot/1)." > ".$dataDirt."/".$files[$i]."1.jpg.html");
		$lenghts[]=array(ceil($dataDirt."/".$files[$i]."1.jpg.txt", ($nrOfFrames/$tot)-1));
		
		}
		
		
		$handle= fopen($dataDirt."/".$files[$i]."1.jpg.html", "r");
		$fc="";
		
				if ($handle) {
				while (($line = fgets($handle)) !== false) {
					$fc.=$line;
				}
			} 
		else {
		
		}
		fclose($handle);

		$handlet= fopen($dataDirt."/".$files[$i]."1.jpg.txt", "r");

        $fct="";

        if ($handlet) {
           while (($line = fgets($handlet)) !== false) {
                       $fct.=$line;
          }
        }
        else {

        }
        fclose($handlet);

		$html.="<a href='#' onclick=playItem('".$dataDir."/".$files[$i]."')> <img draggable='true' onerror='fix(this)'  onmouseover=drag('".$dataDirt."/".$files[$i].$rnd."1.jpg','".floor($fc)."*".floor($fct)."') ondragstart=drag('".$dataDirt."/".$files[$i].$rnd."1.jpg','".floor($fc)."*".floor($fct)."')  src='".$dataDirt."/".$files[$i]."100.jpg' width=75></a><a href='#' onclick=addItem('".$dataDirt."/".$files[$i].$rnd."1.jpg','".floor($fc)."*".floor($fct)."')>Add</a>&nbsp;&nbsp;" ;
		}		
}
$wwww = file_get_contents("http://".getenv("HTTP_HOST")."/".$dataDirt."/width.txt");
if($wwww==""){
$wwww=800;
}
$hhhh =file_get_contents("http://".getenv("HTTP_HOST")."/".$dataDirt."/height.txt");

if($hhhh==""){
$hhhh=600;
}

echo "<script type='text/javascript'>var _width=".$wwww.";   var _height=".$hhhh.";  </script>";
if($does==true){	
}

include('scripts/phpstudio/workerScripts.php');

echo "<script type='text/javascript'>activeAndReady();
theFrameTt = 'frameCount';
aantals();
stat();
</script>";
?>

<form action="/index.php" method="POST" enctype="multipart/form-data">

<table style="border:0;width:90%;  border-spacing: 0px;"  >
<tr>
<td   style="background-color:#fafafa;border-width:1px;	   border-right-style:dotted;text-align:center;vertical-align:top">
<img alt='folders cgaplay' src='/pictures/icons/folder.gif' height='20'><br>
<a href='#' onclick="showFiles()">My Media</a>

<br>
<img src='/pictures/icons/folder2.gif' alt='project management cga movie studio' height='20'><br>
<a onclick="newProject(0);" href='#'>Clear All Up</a>

<br>
<img src='/pictures/icons/mmedia.gif' alt='Create / Clear Project CGAPLAY'  height='20'><br>
<a onclick="newProject(1);" href='#'>New / Restart</a>

</td>
<td>
<div id="right">
<table style='width:100%;border-spacing:4px; ' >

<tr><td>Upload </td><td>

   

<input type='file' name="userfile" id="userfile"></td><td><input type='submit' value='Add'  style='width:80px'></td></tr>




<tr><td id='queri'> Query </td><td><input type='text' style='width:95%;font-size:9px;height:14px' id='searchQ' size=12></td><td>
<table style='cursor:alias;border-radius:6px;width:80px;color:white;background-color:#000000;height:20px;  border-spacing: 0px;'    onclick="searchYouTube()" ><tr>
<td style='text-align:center'>Search </td></tr></table>

</td>
</tr>


<tr><td>  </td><td></td><td>
<table style='cursor:alias;border-radius:6px;width:80px;color:black;background-color:white;height:20px'    onclick="openAnimationSmart()" ><tr>
<td style='text-align:center'>Slideshow... </td></tr></table>

</td>
</tr>





<tr><td>  </td><td></td><td>
<table style='cursor:alias;border-radius:6px;width:80px;color:white;background-color:ORANGE;height:20px'    onclick="openAnimation()" ><tr>
<td style='text-align:center'>Animate... </td></tr></table>

</td>
</tr>



<tr><td>  </td><td></td><td>
<table style='cursor:alias;border-radius:6px;width:80px;color:white;background-color:yellow;height:20px'    onclick="openScreenCapture()" ><tr>
<td style='text-align:center;color:#4040EE'><b>Record PC</b></td></tr></table>

</td>
</tr>




<tr><td>  </td><td></td><td><table style='cursor:alias;border-radius:6px;width:80px;color:white;background-color:#c11010;height:20px'    onclick="openRecord()" ><tr>
<td style='text-align:center'>Take Photo</td></tr></table></td>
</tr>

<tr><td>  </td><td></td><td><table style='cursor:alias;border-radius:6px;width:80px;color:white;background-color:green;height:20px'    onclick="openRecordV()" >
<tr><td style='text-align:center'>Take Video</td></tr></table></td>
</tr>


<tr><td>  </td><td style='text-align:right'><span id='testFunc'></span> </td><td>
<table style='cursor:alias;border-radius:6px;width:80px;color:white;background-color:blue;height:20px'    onclick="testFunction()" ><tr>
<td style='text-align:center'>Tips &amp; Howto</td></tr></table>

</td>
</tr>

</table>


</div>

<br/>

<div id='vidss'></div>

</td>
</tr>
</table>
</form>
</td>
</tr>
</table>








<div id='canvaso'>
</div>






<div id=ifr style='visibility:hidden;width:1px;height:1px'>
</div>
<?php

exec("echo 0 > data[".$_SERVER['REMOTE_ADDR']."]/lengthSeconds.txt");
if($refresh==true){
echo "<script type='text/javascript'> window.location=href='index.php'; </script>";


}

?>

<div id='help' style='display:none;position:absolute;left:100px;top:76px;width:350px'>
<h2><span style='color:gray'>  Add Media</span></h2>
Upload images or video's from you PC or smart phone and press on Add to the right to upload to the current project. 
When you press on home afterwards and click on 'My Media' on the left, your upload or media file is ready to be processed.

<h2><span style='color:black'> Search</span></h2>
When type a query a web search is performed and the first three hits are displayed as video seach on youtube. 
After pressing on Search you can click on the image and the youtube  video is previewed (embedded from youtube) 
When you instead press on 'add' the video  will be downloaded and copied to your project and will be ready for usage. 
Note that some video's are regional bound and  not 100% always  available, next to that youtube-dl has to up to date.

<h2><span style='color:white'>  Slideshow ..</span></h2>
When typing in a query use this following format:
<b><i> ([Descripton search Image] and | , )+  [Descripton search Image] sound | music [Descripton use audio youtube video's Audio]</i></b><br>
Having saying that an animion or slide show will be recorded/rendered and in realtime displayed.  
When finished you can download it as will be displayed, or you can choose to add it to your project with the link 'use in studio'

<h2><span style='color:orange'>  Animate .. </span></h2>
This option is a module to manually  build an animation using your personal images or images  searched for of your interest. 
In that module you can add next to it options for audio.

<h2><span style='color:yellow'>  Record PC </span></h2>
When you wish you record your computer screen a exutable file will be downloaded and needs to run. 
As specified in your settings, your desktop will be recorded for your set duration. Click on  the main page and 'My Media' to work with it.

<h2><span style='color:red'>  Take  Photo </span></h2>
When you have a webcam you can take a snapshot picture from your webcam or smartphone to use in the current project.  
On that page you only have to press on Capture while on your right a preview is displayed.

<h2><span style='color:green'>  Take Video </span></h2>
When using a webcam or phone camera you can use  the video after pressing on  Start and Stop on that page.




</div>


<script type='text/javascript'>
function testFunction(){

	var he= document.getElementById('help');
	he.style.display="";
}
</script>
